Reflection v58 refinements

- Added Nokia N73-inspired Blue-Green dark theme and additional themes (Midnight Blue, Fresh Mint, Soft Coral, Graphite).
- Removed Coach, Timeline, Challenges and Achievements from the navigation drawer.
- Moved Settings directly below Insights in the drawer. Pomodoro remains available lower in the drawer.
- Removed the giant central plus from bottom navigation and added a Create habit button in My habits.
- Added more built-in habit templates.

Build using the existing GitHub Actions workflow. build.yml was not intentionally changed. Build and test before replacing your current APK.
