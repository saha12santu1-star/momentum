package com.momentum.app

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "reading_goals")
data class ReadingGoal(
    @PrimaryKey val habitId: Long,
    val totalPages: Int
)

@Entity(tableName = "reading_logs", primaryKeys = ["habitId", "date"])
data class ReadingLog(
    val habitId: Long,
    val date: String,
    val pagesRead: Int
)

@Dao
interface ReadingDao {
    @Query("SELECT * FROM reading_goals")
    fun goals(): Flow<List<ReadingGoal>>

    @Query("SELECT * FROM reading_logs ORDER BY date DESC")
    fun logs(): Flow<List<ReadingLog>>

    @Query("SELECT * FROM reading_goals")
    suspend fun goalsOnce(): List<ReadingGoal>

    @Query("SELECT * FROM reading_logs ORDER BY date DESC")
    suspend fun logsOnce(): List<ReadingLog>

    @Query("SELECT * FROM reading_goals WHERE habitId=:habitId LIMIT 1")
    suspend fun goal(habitId: Long): ReadingGoal?

    @Query("SELECT * FROM reading_logs WHERE habitId=:habitId AND date=:date LIMIT 1")
    suspend fun logForDate(habitId: Long, date: String): ReadingLog?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGoal(goal: ReadingGoal)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLog(log: ReadingLog)

    @Query("DELETE FROM reading_goals WHERE habitId=:habitId")
    suspend fun deleteGoal(habitId: Long)

    @Query("DELETE FROM reading_logs WHERE habitId=:habitId")
    suspend fun deleteLogs(habitId: Long)
}
