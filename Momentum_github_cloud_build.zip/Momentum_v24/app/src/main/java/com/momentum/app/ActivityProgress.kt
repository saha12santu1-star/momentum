package com.momentum.app

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "activity_progress", primaryKeys = ["habitId", "date"])
data class ActivityProgress(
    val habitId: Long,
    val date: String,
    val amount: Int
)

@Dao
interface ActivityProgressDao {
    @Query("SELECT * FROM activity_progress ORDER BY date DESC")
    fun logs(): Flow<List<ActivityProgress>>

    @Query("SELECT * FROM activity_progress ORDER BY date DESC")
    suspend fun logsOnce(): List<ActivityProgress>

    @Query("SELECT * FROM activity_progress WHERE habitId=:habitId AND date=:date LIMIT 1")
    suspend fun logForDate(habitId: Long, date: String): ActivityProgress?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(log: ActivityProgress)

    @Query("DELETE FROM activity_progress WHERE habitId=:habitId")
    suspend fun deleteLogs(habitId: Long)
}
