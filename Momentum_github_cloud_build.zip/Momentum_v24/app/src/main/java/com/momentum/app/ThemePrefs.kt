package com.momentum.app

import android.content.Context

object ThemePrefs {
    private const val PREFS = "momentum_preferences"
    private const val KEY_THEME = "theme_key"

    fun get(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_THEME, "sage") ?: "sage"

    fun set(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_THEME, key).apply()
    }
}
