package com.momentum.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object JsonBackup {
    suspend fun create(db: MomentumDatabase): String {
        val habits=db.dao().allHabitsOnce()
        val logs=db.dao().allLogsOnce()
        val readingGoals=db.reading().goalsOnce()
        val readingLogs=db.reading().logsOnce()
        val activityLogs=db.activity().logsOnce()
        val root=JSONObject()
        root.put("format","momentum-json")
        root.put("version",3)
        root.put("habits",JSONArray().apply {
            habits.forEach { h->put(JSONObject()
                .put("id",h.id).put("name",h.name).put("description",h.description)
                .put("category",h.category).put("frequency",h.frequency)
                .put("difficulty",h.difficulty).put("startDate",h.startDate).put("reminderMinutes", h.reminderMinutes).put("archived", h.archived).put("iconKey", h.iconKey).put("progressType", h.progressType)) }
        })
        root.put("logs",JSONArray().apply {
            logs.forEach { l->put(JSONObject().put("habitId",l.habitId)
                .put("date",l.date).put("completed",l.completed)) }
        })
        root.put("readingGoals",JSONArray().apply {
            readingGoals.forEach { g -> put(JSONObject().put("habitId",g.habitId).put("totalPages",g.totalPages)) }
        })
        root.put("readingLogs",JSONArray().apply {
            readingLogs.forEach { l -> put(JSONObject().put("habitId",l.habitId).put("date",l.date).put("pagesRead",l.pagesRead)) }
        })
        root.put("activityLogs",JSONArray().apply {
            activityLogs.forEach { l -> put(JSONObject().put("habitId",l.habitId).put("date",l.date).put("amount",l.amount)) }
        })
        return root.toString(2)
    }
}
