package com.momentum.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import kotlinx.coroutines.launch

private const val CHANNEL_ID = "habit_reminders_v2"
private const val ACTION_REMINDER = "com.momentum.app.ACTION_HABIT_REMINDER"
private const val ACTION_TEST = "com.momentum.app.ACTION_TEST_NOTIFICATION"
private const val EXTRA_HABIT_ID = "habitId"
private const val EXTRA_HABIT_NAME = "habitName"
private const val EXTRA_REMINDER_MINUTES = "reminderMinutes"

private fun notificationManager(context: Context): NotificationManager =
    context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

private fun ensureChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        notificationManager(context).createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Habit reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Reminders for your Momentum habits"
                enableVibration(true)
            }
        )
    }
}

private fun canPostNotifications(context: Context): Boolean =
    Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(context, "android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED

private fun reminderPendingIntent(context: Context, habitId: Long, habitName: String, reminderMinutes: Int): PendingIntent {
    val intent = Intent(context, HabitReminderReceiver::class.java).apply {
        action = ACTION_REMINDER
        putExtra(EXTRA_HABIT_ID, habitId)
        putExtra(EXTRA_HABIT_NAME, habitName)
        putExtra(EXTRA_REMINDER_MINUTES, reminderMinutes)
    }
    return PendingIntent.getBroadcast(
        context, habitId.toInt(), intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

private fun nextTriggerMillis(reminderMinutes: Int): Long {
    val now = LocalDateTime.now()
    val safe = reminderMinutes.coerceIn(0, 1439)
    val targetTime = LocalTime.of(safe / 60, safe % 60)
    var next = LocalDateTime.of(LocalDate.now(), targetTime)
    if (!next.isAfter(now)) next = next.plusDays(1)
    return next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
}

object ReminderScheduler {
    fun schedule(context: Context, habitId: Long, habitName: String, delayMinutes: Long, reminderMinutes: Int? = null) {
        val mins = reminderMinutes ?: return
        if (!canPostNotifications(context)) return
        ensureChannel(context)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = reminderPendingIntent(context, habitId, habitName, mins)
        val triggerAt = nextTriggerMillis(mins)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        } catch (_: SecurityException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        }
    }

    fun cancel(context: Context, habitId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(reminderPendingIntent(context, habitId, "Habit", 0))
    }

    fun rescheduleAll(context: Context) {
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            MomentumDatabase.get(context).dao().activeOnce()
                .filter { it.reminderMinutes != null }
                .forEach { ReminderPlanner.schedule(context, it) }
        }
    }
}

object NotificationDiagnostics {
    fun postTest(context: Context) {
        if (!canPostNotifications(context)) return
        ensureChannel(context)
        val intent = Intent(context, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            context, 9001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.momentum.app.R.drawable.ic_stat_momentum)
            .setContentTitle("Momentum notifications are working")
            .setContentText("This is a test notification from Momentum.")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .build()
        notificationManager(context).notify(9001, notification)
    }
}

class HabitReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_TEST) {
            NotificationDiagnostics.postTest(context)
            return
        }
        if (intent.action != ACTION_REMINDER) return

        val habitId = intent.getLongExtra(EXTRA_HABIT_ID, -1L)
        val habitName = intent.getStringExtra(EXTRA_HABIT_NAME) ?: "Habit"
        val reminderMinutes = intent.getIntExtra(EXTRA_REMINDER_MINUTES, -1)

        if (canPostNotifications(context)) {
            ensureChannel(context)
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(com.momentum.app.R.drawable.ic_stat_momentum)
                .setContentTitle("Momentum")
                .setContentText("Time for: $habitName")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .build()
            notificationManager(context).notify((habitId xor (habitId ushr 32)).toInt(), notification)
        }

        if (habitId >= 0 && reminderMinutes in 0..1439) {
            ReminderScheduler.schedule(context, habitId, habitName, 1, reminderMinutes)
        }
    }
}

class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val allowed = intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_TIME_CHANGED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            intent.action == AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED
        if (!allowed) return
        ReminderScheduler.rescheduleAll(context)
    }
}
