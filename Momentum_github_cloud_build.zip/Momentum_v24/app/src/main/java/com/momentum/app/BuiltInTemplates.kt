package com.momentum.app

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.ui.graphics.vector.ImageVector


data class BuiltInHabitTemplate(
    val name: String,
    val description: String,
    val category: String,
    val difficulty: String,
    val frequency: String,
    val iconKey: String,
    val progressType: String = "standard"
)

val BuiltInHabitTemplates = listOf(
    BuiltInHabitTemplate("Reading", "Read a few pages or a chapter.", "Learning", "Easy", "Daily", "book", "pages"),
    BuiltInHabitTemplate("Study", "Study and track the pages you read in your book or study material.", "Learning", "Moderate", "Daily", "study", "pages"),
    BuiltInHabitTemplate("Exercise", "Move your body in a way that feels sustainable.", "Health", "Moderate", "Daily", "exercise", "minutes"),
    BuiltInHabitTemplate("Walk", "Take a simple walk and get some movement in.", "Health", "Easy", "Daily", "walk", "steps"),
    BuiltInHabitTemplate("Meditation", "Take a few quiet minutes to reset.", "Mindful", "Easy", "Daily", "meditation"),
    BuiltInHabitTemplate("Sleep routine", "Create a consistent wind-down routine.", "Wellbeing", "Moderate", "Daily", "sleep"),
    BuiltInHabitTemplate("Water", "Remember to drink water regularly.", "Wellbeing", "Easy", "Daily", "water"),
    BuiltInHabitTemplate("Screen Time", "Create a healthier relationship with your screen time.", "Digital Wellbeing", "Easy", "Daily", "screen")
)

fun habitIcon(key: String): ImageVector = when (key) {
    "study" -> Icons.Default.EditNote
    "exercise" -> Icons.Default.FitnessCenter
    "walk" -> Icons.Default.DirectionsWalk
    "meditation" -> Icons.Default.SelfImprovement
    "sleep" -> Icons.Default.Bedtime
    "water" -> Icons.Default.WaterDrop
    "screen" -> Icons.Default.PhoneAndroid
    else -> Icons.Default.MenuBook
}
