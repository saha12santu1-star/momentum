package com.momentum.app

import androidx.room.Entity
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName="app_settings")
data class AppSetting(@androidx.room.PrimaryKey val key:String, val value:String)

@Entity(tableName="habit_templates")
data class HabitTemplate(
    @androidx.room.PrimaryKey val id:String,
    val name:String,
    val description:String,
    val category:String,
    val frequency:String,
    val difficulty:String
)

@Dao
interface SettingsDao {
    @Query("SELECT * FROM app_settings WHERE `key`=:key LIMIT 1")
    fun observe(key:String): Flow<AppSetting?>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun set(item:AppSetting)
    @Query("SELECT * FROM app_settings") suspend fun all():List<AppSetting>
}
