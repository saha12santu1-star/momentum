package com.momentum.app

import org.json.JSONObject

object JsonRestore {
    suspend fun restore(db: MomentumDatabase, json: String): Int {
        val root = JSONObject(json)
        require(root.optString("format") == "momentum-json") { "Not a Momentum backup" }
        val habits = mutableListOf<Habit>()
        val logs = mutableListOf<HabitLog>()
        val ja = root.optJSONArray("habits") ?: org.json.JSONArray()
        for (i in 0 until ja.length()) {
            val o = ja.getJSONObject(i)
            habits += Habit(
                id=o.optLong("id",0), name=o.optString("name"),
                description=o.optString("description"), category=o.optString("category","General"),
                frequency=o.optString("frequency","Daily"),
                reminderMinutes=if(o.has("reminderMinutes") && !o.isNull("reminderMinutes")) o.optInt("reminderMinutes") else null,
                difficulty=o.optString("difficulty","Easy"), startDate=o.optString("startDate"),
                archived=o.optBoolean("archived",false),
                iconKey=o.optString("iconKey","book"),
                progressType=o.optString("progressType","standard")
            )
        }
        val jl = root.optJSONArray("logs") ?: org.json.JSONArray()
        for (i in 0 until jl.length()) {
            val o=jl.getJSONObject(i)
            logs += HabitLog(o.optLong("habitId"),o.optString("date"),o.optBoolean("completed",true))
        }
        db.dao().insertAll(habits)
        db.dao().logAll(logs)
        val rg = root.optJSONArray("readingGoals") ?: org.json.JSONArray()
        for (i in 0 until rg.length()) {
            val o=rg.getJSONObject(i)
            db.reading().upsertGoal(ReadingGoal(o.optLong("habitId"), o.optInt("totalPages")))
        }
        val rl = root.optJSONArray("readingLogs") ?: org.json.JSONArray()
        for (i in 0 until rl.length()) {
            val o=rl.getJSONObject(i)
            db.reading().upsertLog(ReadingLog(o.optLong("habitId"), o.optString("date"), o.optInt("pagesRead")))
        }
        val al = root.optJSONArray("activityLogs") ?: org.json.JSONArray()
        for (i in 0 until al.length()) {
            val o=al.getJSONObject(i)
            db.activity().upsert(ActivityProgress(o.optLong("habitId"), o.optString("date"), o.optInt("amount")))
        }
        return habits.size + logs.size + rg.length() + rl.length() + al.length()
    }
}
