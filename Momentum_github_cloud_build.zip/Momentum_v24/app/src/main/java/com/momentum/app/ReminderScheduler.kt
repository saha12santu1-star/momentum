package com.momentum.app

import android.content.Context
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime

object ReminderTimes {
    fun nextDelayMinutes(minutesOfDay: Int): Long {
        val now = LocalDateTime.now()
        val safe = minutesOfDay.coerceIn(0, 1439)
        val target = LocalTime.of(safe / 60, safe % 60)
        var next = LocalDateTime.of(now.toLocalDate(), target)
        if (!next.isAfter(now)) next = next.plusDays(1)
        return Duration.between(now, next).toMinutes().coerceAtLeast(1)
    }
}

object ReminderPlanner {
    fun schedule(context: Context, habit: Habit) {
        val mins = habit.reminderMinutes ?: return
        ReminderScheduler.cancel(context, habit.id)
        ReminderScheduler.schedule(context, habit.id, habit.name, ReminderTimes.nextDelayMinutes(mins), mins)
    }
    fun cancel(context: Context, habitId: Long) = ReminderScheduler.cancel(context, habitId)
}
