package com.momentum.app

import android.content.Context
import java.time.LocalDate

object VacationPrefs {
    private const val PREFS = "momentum_vacation"
    private const val START = "start"
    private const val END = "end"

    fun getStart(context: Context): String? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(START, null)
    fun getEnd(context: Context): String? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(END, null)

    fun setRange(context: Context, start: String?, end: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(START, start)
            .putString(END, end)
            .apply()
    }

    fun clear(context: Context) = setRange(context, null, null)

    fun isVacation(context: Context, date: LocalDate): Boolean {
        val start = runCatching { getStart(context)?.let(LocalDate::parse) }.getOrNull() ?: return false
        val end = runCatching { getEnd(context)?.let(LocalDate::parse) }.getOrNull() ?: return false
        return !date.isBefore(start) && !date.isAfter(end)
    }

    fun isVacation(date: LocalDate): Boolean {
        // Used by calculations that run from the app process. The settings are also
        // mirrored here after Settings changes.
        val start = cachedStart ?: return false
        val end = cachedEnd ?: return false
        return !date.isBefore(start) && !date.isAfter(end)
    }

    private var cachedStart: LocalDate? = null
    private var cachedEnd: LocalDate? = null

    fun refresh(context: Context) {
        cachedStart = runCatching { getStart(context)?.let(LocalDate::parse) }.getOrNull()
        cachedEnd = runCatching { getEnd(context)?.let(LocalDate::parse) }.getOrNull()
    }
}
