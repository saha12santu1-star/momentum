package com.momentum.app
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao interface HabitDao {
 @Query("SELECT * FROM habits WHERE archived=0 ORDER BY id DESC") fun active():Flow<List<Habit>>
 @Query("SELECT * FROM habits ORDER BY id DESC") suspend fun allHabitsOnce():List<Habit>
 @Query("SELECT * FROM habits WHERE archived=0 ORDER BY id DESC") suspend fun activeOnce():List<Habit>
 @Query("SELECT * FROM habit_logs ORDER BY date DESC") fun allLogs():Flow<List<HabitLog>>
 @Query("SELECT * FROM habit_logs ORDER BY date DESC") suspend fun allLogsOnce():List<HabitLog>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insert(h:Habit):Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insertAll(h:List<Habit>)
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun logAll(l:List<HabitLog>)
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun log(l:HabitLog)
 @Query("DELETE FROM habit_logs WHERE habitId=:id AND date=:date") suspend fun unlog(id:Long,date:String)
 @Query("DELETE FROM habit_logs WHERE habitId=:id") suspend fun deleteLogs(id:Long)
 @Query("DELETE FROM habits WHERE id=:id") suspend fun deleteHabit(id:Long)
 @Query("UPDATE habits SET archived=1 WHERE id=:id") suspend fun archiveHabit(id:Long)
}
