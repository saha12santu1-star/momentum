package com.momentum.app

import android.content.Context

object AutoLockPrefs {
    private const val PREFS = "momentum_preferences"
    private const val KEY = "auto_lock_minutes"
    fun getMinutes(context: Context): Int = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY, 0)
    fun setMinutes(context: Context, minutes: Int) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY, minutes).apply() }
}
