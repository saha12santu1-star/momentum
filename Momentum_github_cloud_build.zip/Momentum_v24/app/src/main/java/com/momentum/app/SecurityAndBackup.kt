package com.momentum.app

import android.content.Context
import org.json.JSONObject
import java.security.MessageDigest

object PinGate {
    private const val PREFS = "momentum_security"
    private const val KEY_PIN = "pin_hash"

    private fun hash(pin: String): String = MessageDigest.getInstance("SHA-256")
        .digest(pin.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }

    fun isConfigured(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(KEY_PIN)

    fun setPin(context: Context, pin: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_PIN, hash(pin)).apply()
    }

    fun verify(context: Context, pin: String): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PIN, null) == hash(pin)
}


object BackupFormat {
    fun metadata(): JSONObject = JSONObject()
        .put("format", "momentum-json")
        .put("version", 1)
        .put("description", "Local Momentum habit data backup")
}
