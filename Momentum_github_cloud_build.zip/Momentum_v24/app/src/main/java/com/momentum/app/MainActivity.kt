package com.momentum.app

import android.Manifest
import android.app.TimePickerDialog
import android.app.DatePickerDialog
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

data class MomentumThemeOption(
    val key: String,
    val name: String,
    val primary: Color,
    val secondary: Color,
    val pale: Color,
    val background: Color
)

private val MomentumThemeOptions = listOf(
    MomentumThemeOption("sage", "Sage", Color(0xFF4F7F6C), Color(0xFF315A4A), Color(0xFFEAF3EE), Color(0xFFF7F9F7)),
    MomentumThemeOption("ocean", "Ocean", Color(0xFF3F7180), Color(0xFF285361), Color(0xFFE7F1F4), Color(0xFFF4FAFC)),
    MomentumThemeOption("lavender", "Lavender", Color(0xFF75658F), Color(0xFF514366), Color(0xFFF0EBF5), Color(0xFFF9F7FC)),
    MomentumThemeOption("amber", "Amber", Color(0xFF9A6B24), Color(0xFF684712), Color(0xFFF8F0DF), Color(0xFFFCF9F1)),
    MomentumThemeOption("rose", "Rose", Color(0xFF98626E), Color(0xFF693E49), Color(0xFFF6EAED), Color(0xFFFCF7F8)),
    MomentumThemeOption("slate", "Slate", Color(0xFF596A73), Color(0xFF3B4A51), Color(0xFFEAEFF1), Color(0xFFF5F7F8)),
    MomentumThemeOption("dark", "Dark", Color(0xFF9ACBB5), Color(0xFF6FA58B), Color(0xFF24342C), Color(0xFF0B0F0D))
)

private val BaseSage = MomentumThemeOptions.first()

private fun themeOption(key: String): MomentumThemeOption =
    MomentumThemeOptions.firstOrNull { it.key == key } ?: BaseSage

private fun momentumColorScheme(key: String): ColorScheme {
    val t = themeOption(key)
    return if (key == "dark") {
        darkColorScheme(
            primary = Color(0xFF9ED5BC), onPrimary = Color(0xFF102018), secondary = Color(0xFF77B99B),
            onSecondary = Color(0xFF102018), background = Color(0xFF0B0F0D),
            onBackground = Color(0xFFE8F0EB), surface = Color(0xFF141A17),
            onSurface = Color(0xFFE8F0EB), surfaceVariant = Color(0xFF1E2A23),
            onSurfaceVariant = Color(0xFFAAB9B1), outlineVariant = Color(0xFF304038)
        )
    } else {
        lightColorScheme(
            primary = t.primary, onPrimary = Color.White, secondary = t.secondary,
            background = t.background, onBackground = Color(0xFF24332D),
            surface = Color.White, onSurface = Color(0xFF24332D),
            surfaceVariant = t.pale, onSurfaceVariant = Color(0xFF728079),
            outlineVariant = Color(0xFFDDE6E1)
        )
    }
}

private fun progressTitle(type: String): String = when (type) {
    "steps" -> "Track walking progress"
    "minutes" -> "Track exercise time"
    "pages" -> "Track reading progress"
    else -> "Track progress"
}

private fun progressDescription(type: String): String = when (type) {
    "steps" -> "Log your total steps for each day and see weekly, monthly and yearly totals."
    "minutes" -> "Log your total exercise minutes for each day and see weekly, monthly and yearly totals."
    "pages" -> "Log pages read each day and see pages left."
    else -> "Log a daily amount and see your progress over time."
}

private fun progressUnit(type: String): String = when (type) {
    "steps" -> "steps"
    "minutes" -> "min"
    "pages" -> "pages"
    else -> "units"
}

private fun formatReminder(minutes: Int): String {
    val hour24 = (minutes / 60) % 24
    val hour12 = when { hour24 == 0 -> 12; hour24 > 12 -> hour24 - 12; else -> hour24 }
    val suffix = if (hour24 < 12) "AM" else "PM"
    return "$hour12:${"%02d".format(minutes % 60)} $suffix"
}

@Composable private fun sage() = MaterialTheme.colorScheme.primary
@Composable private fun sageDark() = MaterialTheme.colorScheme.secondary
@Composable private fun sagePale() = MaterialTheme.colorScheme.surfaceVariant
@Composable private fun ink() = MaterialTheme.colorScheme.onSurface
@Composable private fun muted() = MaterialTheme.colorScheme.onSurfaceVariant
@Composable private fun page() = MaterialTheme.colorScheme.background
@Composable private fun cardColor() = MaterialTheme.colorScheme.surface
@Composable private fun line() = MaterialTheme.colorScheme.outlineVariant

class MainActivity : ComponentActivity() {
    private var unlocked by mutableStateOf(false)
    private var backgroundAt: Long = 0L

    override fun onStart() {
        VacationPrefs.refresh(this)
        super.onStart()
        if (backgroundAt > 0L && PinGate.isConfigured(this)) {
            val timeout = AutoLockPrefs.getMinutes(this)
            val elapsed = System.currentTimeMillis() - backgroundAt
            if (timeout == 0 || elapsed >= timeout * 60_000L) unlocked = false
        }
    }

    override fun onStop() {
        backgroundAt = System.currentTimeMillis()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (PinGate.isConfigured(this)) {
            ReminderScheduler.rescheduleAll(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        VacationPrefs.refresh(this)
        super.onCreate(savedInstanceState)
        val db = MomentumDatabase.get(this)
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            db.dao().activeOnce().filter { it.reminderMinutes != null }.forEach { ReminderPlanner.schedule(this@MainActivity, it) }
        }
        setContent {
            var pinConfigured by remember { mutableStateOf(PinGate.isConfigured(this@MainActivity)) }
            var themeKey by remember { mutableStateOf(ThemePrefs.get(this@MainActivity)) }
            MaterialTheme(colorScheme = momentumColorScheme(themeKey), typography = Typography()) {
                when {
                    !pinConfigured -> PinSetupScreen {
                        PinGate.setPin(this@MainActivity, it)
                        pinConfigured = true
                        unlocked = true
                    }
                    !unlocked -> PinLockScreen { unlocked = true }
                    else -> MomentumApp(db, onThemeChange = {
                        themeKey = it
                        ThemePrefs.set(this@MainActivity, it)
                    })
                }
            }
        }
    }
}

@Composable
fun PinSetupScreen(onDone: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().background(page()).padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        LogoMark(76)
        Spacer(Modifier.height(18.dp))
        Text("Welcome to Momentum", color = ink(), fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("A calmer way to build your rhythm.", color = muted(), modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(24.dp))
        PinField(pin, "Create 4-digit PIN") { if (it.length <= 4 && it.all(Char::isDigit)) { pin = it; error = "" } }
        Spacer(Modifier.height(10.dp))
        PinField(confirm, "Confirm PIN") { if (it.length <= 4 && it.all(Char::isDigit)) { confirm = it; error = "" } }
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                error = when {
                    pin.length != 4 -> "PIN must contain exactly 4 digits"
                    pin != confirm -> "PINs do not match"
                    else -> ""
                }
                if (error.isEmpty()) {
                    onDone(pin)
                }
            },
            enabled = pin.length == 4 && confirm.length == 4,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Continue") }
    }
}

@Composable
fun PinLockScreen(onUnlock: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().background(page()).padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        LogoMark(76)
        Spacer(Modifier.height(18.dp))
        Text("Momentum", color = ink(), fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Enter your PIN to continue.", color = muted(), modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(24.dp))
        PinField(pin, "4-digit PIN") { if (it.length <= 4 && it.all(Char::isDigit)) { pin = it; error = "" } }
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            if (PinGate.verify(ctx, pin)) { error = ""; onUnlock() } else error = "Incorrect PIN"
        }, enabled = pin.length == 4, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("Unlock") }
    }
}

@Composable
fun PinField(value: String, label: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = ink(),
            unfocusedTextColor = ink(),
            focusedBorderColor = sage(),
            unfocusedBorderColor = line(),
            focusedLabelColor = sage(),
            unfocusedLabelColor = muted(),
            cursorColor = sage()
        )
    )
}

@Composable
fun LogoMark(size: Int = 42) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(size / 3f)).background(sage()),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Default.Eco,
            contentDescription = "Momentum logo",
            tint = Color.White,
            modifier = Modifier.size((size * 0.62f).dp)
        )
    }
}

enum class Screen(val title: String) { TODAY("Today"), HABITS("My habits"), CALENDAR("Calendar"), INSIGHTS("Insights") }

@Composable
fun MomentumApp(db: MomentumDatabase, onThemeChange: (String) -> Unit) {
    var screen by remember { mutableStateOf(Screen.TODAY) }
    var detail by remember { mutableStateOf<String?>(null) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val drawerScope = rememberCoroutineScope()
    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            DrawerContent(
                selected = screen,
                onSelect = {
                    screen = it
                    detail = null
                    drawerScope.launch { drawerState.close() }
                },
                onMore = {
                    detail = it
                    drawerScope.launch { drawerState.close() }
                }
            )
        }
    ) {
        Scaffold(
            containerColor = page(),
            topBar = { TopBar(onMenu = { drawerScope.launch { drawerState.open() } }) },
            bottomBar = {
                Surface(color = cardColor(), tonalElevation = 0.dp, shadowElevation = 2.dp) {
                    Row(Modifier.fillMaxWidth().height(82.dp), verticalAlignment = Alignment.CenterVertically) {
                        BottomNavItem("Today", Icons.Default.WbSunny, screen == Screen.TODAY && detail == null, Modifier.weight(1f)) { screen = Screen.TODAY; detail = null }
                        BottomNavItem("My habits", Icons.Default.Eco, screen == Screen.HABITS && detail == null, Modifier.weight(1f)) { screen = Screen.HABITS; detail = null }
                        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                            FloatingActionButton(
                                onClick = { screen = Screen.HABITS; detail = "add" },
                                containerColor = sage(),
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                                shape = CircleShape,
                                modifier = Modifier.size(56.dp)
                            ) { Icon(Icons.Default.Add, "Add habit") }
                        }
                        BottomNavItem("Calendar", Icons.Default.CalendarMonth, screen == Screen.CALENDAR && detail == null, Modifier.weight(1f)) { screen = Screen.CALENDAR; detail = null }
                        BottomNavItem("Insights", Icons.Default.ShowChart, screen == Screen.INSIGHTS && detail == null, Modifier.weight(1f)) { screen = Screen.INSIGHTS; detail = null }
                    }
                }
            }
        ) { pad ->
            when {
                detail == "add" -> AddHabitScreen(db, Modifier.padding(pad), onBack = { detail = null })
                detail?.startsWith("edit:") == true -> {
                    val id = detail!!.substringAfter(":").toLongOrNull()
                    EditHabitScreen(db, id, Modifier.padding(pad), onBack = { detail = null })
                }
                detail == "coach" -> CoachScreen(db, Modifier.padding(pad))
                detail == "timeline" -> TimelineScreen(db, Modifier.padding(pad))
                detail == "challenges" -> ChallengesScreen(db, Modifier.padding(pad))
                detail == "achievements" -> AchievementsScreen(db, Modifier.padding(pad))
                detail == "settings" -> SettingsScreen(db, Modifier.padding(pad), onThemeChange)
                else -> when (screen) {
                    Screen.TODAY -> TodayScreen(db, Modifier.padding(pad), onEdit = { detail = "edit:$it" })
                    Screen.HABITS -> HabitsScreen(db, Modifier.padding(pad), onEdit = { detail = "edit:$it" })
                    Screen.CALENDAR -> CalendarScreen(db, Modifier.padding(pad))
                    Screen.INSIGHTS -> InsightsScreen(db, Modifier.padding(pad))
                }
            }
        }
    }
}

@Composable
private fun BottomNavItem(label: String, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxHeight().clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.clip(RoundedCornerShape(22.dp)).background(if (selected) sagePale() else Color.Transparent).padding(horizontal = 20.dp, vertical = 5.dp)) {
                Icon(icon, contentDescription = label, tint = if (selected) sageDark() else muted())
            }
            Text(label, color = if (selected) ink() else muted(), fontSize = 11.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
fun TopBar(onMenu: () -> Unit) {
    Surface(color = page(), border = BorderStroke(1.dp, line())) {
        Row(Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "Menu") }
            Spacer(Modifier.weight(1f))
            LogoMark(34); Spacer(Modifier.width(8.dp)); Text("Momentum", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.width(48.dp))
        }
    }
}

@Composable
fun DrawerContent(selected: Screen, onSelect: (Screen) -> Unit, onMore: (String) -> Unit) {
    ModalDrawerSheet(drawerContainerColor = cardColor(), modifier = Modifier.width(310.dp)) {
        Column(Modifier.fillMaxHeight().padding(22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { LogoMark(58); Spacer(Modifier.width(14.dp)); Column { Text("Momentum", fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("YOUR DAILY PRACTICE", fontSize = 11.sp, color = muted(), letterSpacing = 2.sp) } }
            Spacer(Modifier.height(28.dp)); Text("YOUR SPACE", color = muted(), fontSize = 12.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            listOf(Screen.TODAY, Screen.HABITS, Screen.CALENDAR, Screen.INSIGHTS).forEach { s ->
                DrawerItem(s.title, selected == s, { onSelect(s) }, if (s == Screen.TODAY) Icons.Default.WbSunny else if (s == Screen.HABITS) Icons.Default.Eco else if (s == Screen.CALENDAR) Icons.Default.CalendarMonth else Icons.Default.ShowChart)
            }
            Spacer(Modifier.weight(1f))
            Card(colors = CardDefaults.cardColors(sagePale()), shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, line())) {
                Column(Modifier.padding(20.dp)) { Text("A GENTLE REMINDER", color = sage(), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp); Spacer(Modifier.height(12.dp)); Text("Small steps count, especially the small ones.", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = ink()) }
            }
            Spacer(Modifier.height(16.dp))
            listOf("Coach" to "coach", "Timeline" to "timeline", "Challenges" to "challenges", "Achievements" to "achievements", "Settings" to "settings").forEach { (label, key) -> TextButton(onClick = { onMore(key) }, modifier = Modifier.fillMaxWidth()) { Text(label, modifier = Modifier.fillMaxWidth()) } }
        }
    }
}

@Composable fun DrawerItem(label: String, selected: Boolean, onClick: () -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (selected) sagePale() else Color.Transparent).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = if (selected) sage() else muted()); Spacer(Modifier.width(14.dp)); Text(label, fontSize = 17.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, color = if (selected) sageDark() else ink()); if (selected) { Spacer(Modifier.weight(1f)); Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF76A889))) } }
}

@Composable
fun TodayScreen(db: MomentumDatabase, m: Modifier, onEdit: (Long) -> Unit) {
    val habits by db.dao().active().collectAsState(emptyList())
    val logs by db.dao().allLogs().collectAsState(emptyList())
    val readingGoals by db.reading().goals().collectAsState(emptyList())
    val readingLogs by db.reading().logs().collectAsState(emptyList())
    val activityLogs by db.activity().logs().collectAsState(emptyList())
    val scope = rememberCoroutineScope(); val today = LocalDate.now()
    val done = logs.filter { it.completed }.map { "${it.habitId}|${it.date}" }.toSet()
    val vacationToday = VacationPrefs.isVacation(today)
    val scheduledToday = if (vacationToday) 0 else habits.size
    val checked = habits.count { "${it.id}|$today" in done }
    val pct = if (scheduledToday == 0) 100 else checked * 100 / scheduledToday
    LazyColumn(m.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Spacer(Modifier.height(22.dp)); Eyebrow(today.format(DateTimeFormatter.ofPattern("EEEE, MMMM d", Locale.ENGLISH)).uppercase()); Text("A day, at your pace.", fontSize = 34.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)); Text("Show up for what matters. The rest can wait.", color = muted(), fontSize = 17.sp, modifier = Modifier.padding(top = 8.dp)); Spacer(Modifier.height(22.dp)) }
        item { RhythmCard(checked, scheduledToday, pct, habits.maxOfOrNull { currentStreak(it, done) } ?: 0); Spacer(Modifier.height(26.dp)); Eyebrow("YOUR CHECK-IN"); Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = 6.dp)) { Text("Today's habits", fontSize = 27.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text(if (vacationToday) "Vacation day" else "$checked / ${habits.size} complete", color = muted(), fontSize = 13.sp) }; Spacer(Modifier.height(12.dp)) }
        if (habits.isEmpty()) item { EmptyCard("Nothing scheduled yet", "Start with one small habit.") }
        items(habits) { h ->
            val isDone = "${h.id}|$today" in done
            HabitCheckCard(h, isDone, currentStreak(h, done), onToggle = { scope.launch { if (isDone) db.dao().unlog(h.id, today.toString()) else db.dao().log(HabitLog(h.id, today.toString(), true)); db.extended().addEvent(TimelineEvent(date = today.toString(), title = if (isDone) "Check-in removed" else "Check-in saved", detail = h.name)) } }, onEdit = { onEdit(h.id) })
            Spacer(Modifier.height(10.dp))
        }
        if (habits.any { it.progressType == "pages" }) {
            item { Spacer(Modifier.height(8.dp)); Eyebrow("READING PROGRESS") }
            habits.filter { it.progressType == "pages" }.forEach { h ->
                val goal = readingGoals.firstOrNull { it.habitId == h.id }
                val history = readingLogs.filter { it.habitId == h.id }.sortedByDescending { it.date }
                if (goal != null) {
                    item {
                        ReadingProgressCard(
                            habit = h, goal = goal, history = history,
                            onAddPages = { pages ->
                                scope.launch {
                                    val current = db.reading().logForDate(h.id, today.toString())?.pagesRead ?: 0
                                    val total = history.sumOf { it.pagesRead }
                                    val remaining = (goal.totalPages - total).coerceAtLeast(0)
                                    val add = pages.coerceAtMost(remaining)
                                    if (add > 0) {
                                        db.reading().upsertLog(ReadingLog(h.id, today.toString(), current + add))
                                        db.dao().log(HabitLog(h.id, today.toString(), true))
                                        db.extended().addEvent(TimelineEvent(date = today.toString(), title = "Reading progress", detail = "${h.name}: +$add pages"))
                                    }
                                }
                            }
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                }
            }
        }
        if (habits.any { it.progressType == "steps" || it.progressType == "minutes" }) {
            item { Spacer(Modifier.height(8.dp)); Eyebrow("MOVEMENT PROGRESS") }
            habits.filter { it.progressType == "steps" || it.progressType == "minutes" }.forEach { h ->
                item {
                    val history = activityLogs.filter { it.habitId == h.id }.sortedByDescending { it.date }
                    ActivityProgressCard(
                        habit = h,
                        history = history,
                        onSaveToday = { amount ->
                            scope.launch {
                                if (amount >= 0) {
                                    db.activity().upsert(ActivityProgress(h.id, today.toString(), amount))
                                    if (amount > 0) db.dao().log(HabitLog(h.id, today.toString(), true))
                                    db.extended().addEvent(TimelineEvent(date = today.toString(), title = if (h.progressType == "steps") "Walking progress" else "Exercise time", detail = "${h.name}: $amount ${progressUnit(h.progressType)}"))
                                }
                            }
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)); CoachCard(checked, habits.size) }
    }
}

@Composable fun RhythmCard(checked: Int, total: Int, pct: Int, streak: Int) {
    Card(colors = CardDefaults.cardColors(sagePale()), shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, line())) {
        Row(Modifier.fillMaxWidth().padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Eyebrow("TODAY'S RHYTHM"); Spacer(Modifier.height(10.dp)); Text(if (total > 0 && checked == total) "Beautifully done." else "Keep going gently.", fontSize = 25.sp, fontWeight = FontWeight.Medium, color = sageDark()); Text("$checked of $total practices checked in today", color = muted(), modifier = Modifier.padding(top = 8.dp)); HorizontalDivider(Modifier.padding(vertical = 18.dp), color = line()); Text("⚡  Best current streak   $streak day${if (streak == 1) "" else "s"}", color = muted()) }
            Spacer(Modifier.width(18.dp)); Box(Modifier.size(92.dp).clip(CircleShape).background(Color.Transparent).padding(8.dp), contentAlignment = Alignment.Center) { Box(Modifier.fillMaxSize().clip(CircleShape).background(sage()), contentAlignment = Alignment.Center) { Box(Modifier.size(68.dp).clip(CircleShape).background(sagePale()), contentAlignment = Alignment.Center) { Text("$pct%", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = sageDark()) } } }
        }
    }
}

@Composable fun HabitCheckCard(h: Habit, done: Boolean, streak: Int, onToggle: () -> Unit, onEdit: () -> Unit) {
    Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, line())) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(sagePale()), contentAlignment = Alignment.Center) { Icon(habitIcon(h.iconKey), null, tint = sage()) }
            Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(h.name, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text("${streak} scheduled check-in streak", color = muted(), fontSize = 12.sp); Text(if (done) "Check-in saved. Small wins count." else "Ready when you are.", color = muted(), fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp)) }
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Edit") }
            FilledIconButton(onClick = onToggle, shape = CircleShape, colors = IconButtonDefaults.filledIconButtonColors(containerColor = if (done) sage() else sagePale(), contentColor = if (done) Color(0xFF102018) else sage())) { Icon(if (done) Icons.Default.Check else Icons.Default.Add, "Check in") }
        }
    }
}

@Composable fun CoachCard(checked: Int, total: Int) { Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, line())) { Column(Modifier.padding(22.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Eco, null, tint = sage()); Spacer(Modifier.width(8.dp)); Eyebrow("ADAPTIVE COACH"); Spacer(Modifier.weight(1f)); Surface(color = sagePale(), shape = RoundedCornerShape(20.dp)) { Text("LEARNING YOUR RHYTHM", color = sage(), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp)) } }; Spacer(Modifier.height(16.dp)); Text("We're learning what works for you", fontSize = 22.sp, fontWeight = FontWeight.Bold); Text(if (total == 0) "Start small. Every check-in helps make future suggestions more useful." else "$checked of $total scheduled check-ins completed today. Keep returning before changing your plan.", color = muted(), modifier = Modifier.padding(top = 10.dp)) } } }

@Composable
fun HabitsScreen(db: MomentumDatabase, m: Modifier, onEdit: (Long) -> Unit) {
    val habits by db.dao().active().collectAsState(emptyList()); var query by remember { mutableStateOf("") }; val scope = rememberCoroutineScope()
    val shown = habits.filter { it.name.contains(query, true) || it.category.contains(query, true) }
    LazyColumn(m.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Spacer(Modifier.height(22.dp)); Eyebrow("YOUR PRACTICE"); Row(verticalAlignment = Alignment.Top) { Column(Modifier.weight(1f)) { Text("Habits, made yours.", fontSize = 34.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)); Text("${habits.size} active habit${if (habits.size == 1) "" else "s"} · Built at your own pace", color = muted(), fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp)) }; Spacer(Modifier.width(8.dp)) }; Spacer(Modifier.height(18.dp)); OutlinedTextField(query, { query = it }, placeholder = { Text("Find a habit") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), singleLine = true); Spacer(Modifier.height(18.dp)) }
        if (shown.isEmpty()) item { EmptyCard("No habits found", if (habits.isEmpty()) "Tap + to create your first habit." else "Try another search.") }
        items(shown) { h ->
            HabitRow(h, onEdit, onArchive = { id -> scope.launch { db.dao().archiveHabit(id) } }, onDelete = { id -> scope.launch { db.dao().deleteLogs(id); db.reading().deleteGoal(id); db.reading().deleteLogs(id); db.activity().deleteLogs(id); db.dao().deleteHabit(id) } })
        }
    }
}

@Composable
fun HabitRow(h: Habit, onEdit: (Long) -> Unit, onArchive: (Long) -> Unit, onDelete: (Long) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, line()), modifier = Modifier.padding(bottom = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(17.dp)).background(sagePale()), contentAlignment = Alignment.Center) { Icon(habitIcon(h.iconKey), null, tint = sage()) }
            Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f).clickable { onEdit(h.id) }) { Text(h.name, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("${h.category} · ${h.frequency} · ${h.difficulty}", color = muted(), fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp)) }
            IconButton(onClick = { onEdit(h.id) }) { Icon(Icons.Default.Edit, "Edit") }
            Box { IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }; DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) { DropdownMenuItem(text = { Text("Archive") }, onClick = { menu = false; onArchive(h.id) }); DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; confirmDelete = true }) } }
        }
    }
    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text("Delete ${h.name}?") }, text = { Text("This removes the habit and its saved check-ins from this device. Archive is safer if you want to keep history.") }, confirmButton = { Button(onClick = { confirmDelete = false; onDelete(h.id) }) { Text("Delete") } }, dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } })
}

@Composable
fun AddHabitScreen(db: MomentumDatabase, m: Modifier, onBack: () -> Unit) = HabitEditor(db, null, m, onBack)
@Composable
fun EditHabitScreen(db: MomentumDatabase, id: Long?, m: Modifier, onBack: () -> Unit) = HabitEditor(db, id, m, onBack)

@Composable
fun HabitEditor(db: MomentumDatabase, id: Long?, m: Modifier, onBack: () -> Unit) {
    val habits by db.dao().active().collectAsState(emptyList())
    val existing = habits.firstOrNull { it.id == id }
    var name by remember(existing?.id) { mutableStateOf(existing?.name ?: "") }
    var category by remember(existing?.id) { mutableStateOf(existing?.category ?: "Wellbeing") }
    var difficulty by remember(existing?.id) { mutableStateOf(existing?.difficulty ?: "Moderate") }
    var frequency by remember(existing?.id) { mutableStateOf(existing?.frequency ?: "Daily") }
    var description by remember(existing?.id) { mutableStateOf(existing?.description ?: "") }
    var reminder by remember(existing?.id) { mutableStateOf(existing?.reminderMinutes) }
    var iconKey by remember(existing?.id) { mutableStateOf(existing?.iconKey ?: "book") }
    var progressType by remember(existing?.id) { mutableStateOf(existing?.progressType ?: "standard") }
    var totalPages by remember(existing?.id) { mutableStateOf("") }
    LaunchedEffect(existing?.id) { if (existing != null && existing.progressType == "pages") totalPages = db.reading().goal(existing.id)?.totalPages?.toString() ?: "" }
    var selectedDays by remember(existing?.id) { mutableStateOf(setOf(1,2,3,4,5)) }
    var showCategory by remember { mutableStateOf(false) }
    var showFrequency by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    LazyColumn(m.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(6.dp)); Text("All habits") }
            Eyebrow("MAKE A CHANGE")
            Text(if (existing == null) "Start small." else "Shape your routine.", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            Text("Your habit can change as you do.", color = muted(), fontSize = 17.sp, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(20.dp))
        }
        if (existing == null) {
            item {
                Text("BUILT-IN TEMPLATES", color = muted(), fontSize = 11.sp, letterSpacing = 2.2.sp, fontWeight = FontWeight.Bold)
                Text("Start with a ready-made practice", fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                Text("Templates fill the details for you. You can change anything before saving.", color = muted(), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                Spacer(Modifier.height(10.dp))
            }
            items(BuiltInHabitTemplates.chunked(2)) { pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { template ->
                        TemplateCard(template, Modifier.weight(1f)) {
                            name = template.name
                            description = template.description
                            category = template.category
                            difficulty = template.difficulty
                            frequency = template.frequency
                            iconKey = template.iconKey
                            progressType = template.progressType
                            showCategory = false
                            showFrequency = false
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
            }
            item { Spacer(Modifier.height(8.dp)); HorizontalDivider(color = line()); Spacer(Modifier.height(18.dp)) }
        }
        item {
            EditorField("Habit name", "Required", name, { name = it })
            Spacer(Modifier.height(12.dp))
            ExposedField("Category", category, showCategory, { showCategory = !showCategory })
            if (showCategory) ChoiceRow(listOf("Wellbeing","Learning","Health","Mindful","Digital Wellbeing","Other"), category) { category = it; showCategory = false }
            Spacer(Modifier.height(12.dp))
            Text("Difficulty", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            ChoiceCards(listOf("Easy","Moderate","Challenging"), difficulty) { difficulty = it }
            Spacer(Modifier.height(16.dp))
            ExposedField("Frequency", frequency, showFrequency, { showFrequency = !showFrequency })
            if (showFrequency) ChoiceRow(listOf("Daily","Selected days","Weekly"), frequency) { frequency = it; showFrequency = false }
            if (frequency == "Selected days") {
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("S","M","T","W","T","F","S").forEachIndexed { i, d ->
                        val day = i
                        FilterChip(selected = selectedDays.contains(day), onClick = { selectedDays = if (selectedDays.contains(day)) selectedDays - day else selectedDays + day }, label = { Text(d) }, modifier = Modifier.weight(1f))
                    }
                }
                Text("Choose a weekly schedule", color = muted(), fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text("Choose an icon", fontWeight = FontWeight.SemiBold)
            Text("Pick an icon that matches the habit.", color = muted(), fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
            IconPicker(iconKey) { iconKey = it }
            Spacer(Modifier.height(14.dp))
            if (progressType != "standard") {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = sagePale(),
                    border = BorderStroke(1.dp, sage())
                ) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(habitIcon(iconKey), null, tint = sage())
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(progressTitle(progressType), fontWeight = FontWeight.SemiBold)
                            Text(progressDescription(progressType), color = muted(), fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
                        }
                        Switch(checked = true, onCheckedChange = { progressType = "standard" })
                    }
                }
            } else {
                val movementType = if (iconKey == "walk") "steps" else if (iconKey == "exercise") "minutes" else "standard"
                if (movementType != "standard") {
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { progressType = movementType },
                        shape = RoundedCornerShape(18.dp),
                        color = cardColor(),
                        border = BorderStroke(1.dp, line())
                    ) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(habitIcon(iconKey), null, tint = sage())
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(progressTitle(movementType), fontWeight = FontWeight.SemiBold)
                                Text(progressDescription(movementType), color = muted(), fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
                            }
                            Switch(checked = false, onCheckedChange = { progressType = movementType })
                        }
                    }
                }
            }
            if (progressType == "pages") {
                Spacer(Modifier.height(12.dp))
                EditorField("Total pages", "Required for this book", totalPages, { value -> totalPages = value.filter(Char::isDigit) }, "e.g. 1000")
            }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = {
                val initial = reminder ?: 20 * 60
                TimePickerDialog(ctx, { _, h, min -> reminder = h * 60 + min }, initial / 60, initial % 60, false).show()
            }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.NotificationsNone, null); Spacer(Modifier.width(8.dp)); Text(if (reminder == null) "Preferred reminder time" else "Reminder ${formatReminder(reminder!!)}")
            }
            Spacer(Modifier.height(16.dp))
            EditorField("A little more context", "Optional", description, { description = it }, "What would make this feel meaningful?")
            if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp))
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) { Text("Cancel") }
                Button(onClick = {
                    if (name.isBlank()) { error = "Please enter a habit name"; return@Button }
                    if (progressType == "pages" && (totalPages.toIntOrNull() ?: 0) <= 0) { error = "Enter the book's total number of pages"; return@Button }
                    scope.launch {
                        if (existing == null) {
                            val h = Habit(name = name.trim(), description = description.trim(), category = category, frequency = frequency, reminderMinutes = reminder, difficulty = difficulty, startDate = LocalDate.now().toString(), iconKey = iconKey, progressType = progressType)
                            val newId = db.dao().insert(h)
                            if (progressType == "pages") db.reading().upsertGoal(ReadingGoal(newId, totalPages.toInt()))
                            db.extended().addEvent(TimelineEvent(date = LocalDate.now().toString(), title = "Habit created", detail = name.trim()))
                            if (reminder != null) ReminderPlanner.schedule(ctx, h.copy(id = newId))
                        } else {
                            db.dao().insert(existing.copy(name = name.trim(), description = description.trim(), category = category, frequency = frequency, reminderMinutes = reminder, difficulty = difficulty, iconKey = iconKey, progressType = progressType))
                            if (reminder != null) ReminderPlanner.schedule(ctx, existing.copy(name = name.trim(), reminderMinutes = reminder)) else ReminderPlanner.cancel(ctx, existing.id)
                            if (progressType == "pages") db.reading().upsertGoal(ReadingGoal(existing.id, totalPages.toInt()))
                            db.extended().addEvent(TimelineEvent(date = LocalDate.now().toString(), title = "Habit updated", detail = name.trim()))
                        }
                        onBack()
                    }
                }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.Check, null); Spacer(Modifier.width(6.dp)); Text(if (existing == null) "Save habit" else "Save changes") }
            }
        }
    }
}

@Composable
fun TemplateCard(template: BuiltInHabitTemplate, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(cardColor()),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, line())
    ) {
        Column(Modifier.padding(14.dp)) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(sagePale()), contentAlignment = Alignment.Center) {
                Icon(habitIcon(template.iconKey), null, tint = sage())
            }
            Spacer(Modifier.height(9.dp))
            Text(template.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(template.category, color = muted(), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
fun IconPicker(selected: String, onSelect: (String) -> Unit) {
    val options = listOf(
        "book" to Icons.Default.MenuBook, "study" to Icons.Default.EditNote,
        "exercise" to Icons.Default.FitnessCenter, "walk" to Icons.Default.DirectionsWalk,
        "meditation" to Icons.Default.SelfImprovement, "sleep" to Icons.Default.Bedtime,
        "water" to Icons.Default.WaterDrop, "screen" to Icons.Default.PhoneAndroid
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (key, icon) ->
                    val chosen = key == selected
                    Surface(
                        modifier = Modifier.weight(1f).height(54.dp).clickable { onSelect(key) },
                        shape = RoundedCornerShape(14.dp),
                        color = if (chosen) sagePale() else cardColor(),
                        border = BorderStroke(1.dp, if (chosen) sage() else line())
                    ) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(icon, key, tint = if (chosen) sage() else muted()) } }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable fun EditorField(title: String, hint: String, value: String, onChange: (String) -> Unit, placeholder: String = "") { Column { Text(title, fontWeight = FontWeight.SemiBold); Text(hint, color = muted(), fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp)); Spacer(Modifier.height(6.dp)); OutlinedTextField(value, onChange, placeholder = { if (placeholder.isNotEmpty()) Text(placeholder) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), minLines = if (placeholder.isNotEmpty()) 3 else 1) } }
@Composable fun ExposedField(title: String, value: String, open: Boolean, onClick: () -> Unit) { OutlinedButton(onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(16.dp)) { Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) { Text(title, color = muted(), fontSize = 12.sp); Text(value, color = ink(), fontSize = 16.sp) }; Icon(if (open) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null) } }
@Composable fun ChoiceRow(options: List<String>, selected: String, choose: (String) -> Unit) { Column(Modifier.padding(top = 6.dp)) { options.forEach { TextButton(onClick = { choose(it) }, modifier = Modifier.fillMaxWidth()) { Text(it, modifier = Modifier.fillMaxWidth(), color = if (it == selected) sage() else ink()) } } } }
@Composable fun ChoiceCards(options: List<String>, selected: String, choose: (String) -> Unit) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { options.forEach { o -> OutlinedButton(onClick = { choose(o) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (o == selected) sagePale() else cardColor()), border = BorderStroke(1.dp, if (o == selected) sage() else line()), shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(10.dp)) { Text(o, fontSize = 12.sp, color = if (o == selected) sageDark() else ink()) } } } }

@Composable
fun CalendarScreen(db: MomentumDatabase, m: Modifier) {
    val habits by db.dao().active().collectAsState(emptyList()); val logs by db.dao().allLogs().collectAsState(emptyList()); var month by remember { mutableStateOf(YearMonth.now()) }; var selected by remember { mutableStateOf(LocalDate.now()) }
    val done = logs.filter { it.completed }.map { "${it.habitId}|${it.date}" }.toSet(); val days = month.lengthOfMonth(); val first = month.atDay(1).dayOfWeek.value % 7
    LazyColumn(m.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Spacer(Modifier.height(22.dp)); Eyebrow("YOUR MONTH, IN VIEW"); Text("A softer kind of progress.", fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)); Text("Each mark is a moment you showed up.", color = muted(), fontSize = 17.sp, modifier = Modifier.padding(top = 7.dp)); Spacer(Modifier.height(20.dp)); Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, line())) { Column(Modifier.padding(18.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Default.ChevronLeft, null) }; Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy")), fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); IconButton(onClick = { month = month.plusMonths(1) }) { Icon(Icons.Default.ChevronRight, null) } }; Row(Modifier.fillMaxWidth()) { listOf("S","M","T","W","T","F","S").forEach { Text(it, modifier = Modifier.weight(1f), color = muted(), fontSize = 12.sp) } }; Spacer(Modifier.height(10.dp)); for (week in 0 until ((first + days + 6) / 7)) { Row(Modifier.fillMaxWidth()) { for (col in 0..6) { val n = week * 7 + col - first + 1; Box(Modifier.weight(1f).aspectRatio(1f).padding(3.dp).clip(RoundedCornerShape(12.dp)).background(if (n in 1..days && n == selected.dayOfMonth && month == YearMonth.from(selected)) sage() else Color.Transparent).clickable(enabled = n in 1..days) { selected = month.atDay(n) }, contentAlignment = Alignment.Center) { if (n in 1..days) { val d = month.atDay(n); val count = habits.count { "${it.id}|$d" in done }; Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(n.toString(), color = if (d == selected) Color.White else if (d.isAfter(LocalDate.now())) Color(0xFFBBC4C0) else ink()); if (count > 0) Box(Modifier.size(6.dp).clip(CircleShape).background(if (d == selected) Color.White else sage())) } } } } } }; HorizontalDivider(Modifier.padding(vertical = 14.dp), color = line()); Text("●  Completed     ▪  Missed     ◇  Streak break", color = muted(), fontSize = 11.sp); Text("Future dates stay open — they are never marked missed.", color = muted(), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)) } } }
        item { Spacer(Modifier.height(18.dp)); Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, line())) { Column(Modifier.padding(20.dp)) { Eyebrow("DAY IN FOCUS"); Text(selected.format(DateTimeFormatter.ofPattern("EEEE, MMMM d")), fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)); val count = habits.count { "${it.id}|$selected" in done }; Text("$count of ${habits.size} scheduled habit${if (habits.size == 1) "" else "s"} complete", color = muted(), modifier = Modifier.padding(top = 5.dp)); habits.forEach { h -> Row(Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(16.dp)).background(if ("${h.id}|$selected" in done) sagePale() else cardColor()).padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(habitIcon(h.iconKey), null, tint = sage()); Spacer(Modifier.width(10.dp)); Text(h.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold); if ("${h.id}|$selected" in done) Icon(Icons.Default.CheckCircle, null, tint = sage()) } } } } }
        item { HabitActivityHeatmap(habits, logs) }
    }
}

@Composable
fun InsightsScreen(db: MomentumDatabase, m: Modifier) {
    val habits by db.dao().active().collectAsState(emptyList()); val logs by db.dao().allLogs().collectAsState(emptyList()); val today = LocalDate.now(); val done = logs.filter { it.completed }.map { "${it.habitId}|${it.date}" }.toSet()
    val activityLogs by db.activity().logs().collectAsState(emptyList()); val readingLogs by db.reading().logs().collectAsState(emptyList()); val readingGoals by db.reading().goals().collectAsState(emptyList()); val last7 = (0..6).map { today.minusDays(it.toLong()) }; val scheduled = habits.sumOf { h -> last7.count { d -> !d.isBefore(LocalDate.parse(h.startDate)) && !VacationPrefs.isVacation(d) } }; val completed = last7.sumOf { d -> habits.count { h -> "${h.id}|$d" in done } }; val pct = if (scheduled == 0) null else completed * 100 / scheduled
    LazyColumn(m.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Spacer(Modifier.height(22.dp)); Eyebrow("YOUR PROGRESS, FROM REAL ACTIVITY"); Text("Notice how far you've come.", fontSize = 31.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)); Text("Every check-in is a small piece of evidence about what works for you.", color = muted(), fontSize = 17.sp, modifier = Modifier.padding(top = 7.dp)); Spacer(Modifier.height(20.dp)); CoachCard(completed, scheduled); Spacer(Modifier.height(12.dp)); StatCard("CONSISTENCY", pct?.let { "$it%" } ?: "—", if (scheduled == 0) "No scheduled sessions yet" else "$completed of $scheduled scheduled check-ins"); StatCard("TOTAL CHECK-INS", logs.count { it.completed }.toString(), "All-time saved locally"); Eyebrow("A WEEK IN SMALL WINS"); Spacer(Modifier.height(8.dp)) }
        item { Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, line())) { Row(Modifier.fillMaxWidth().height(150.dp).padding(18.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) { (6 downTo 0).forEach { i -> val d = today.minusDays(i.toLong()); val c = habits.count { "${it.id}|$d" in done }; Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) { Box(Modifier.width(26.dp).height((18 + c * 25).coerceAtMost(90).dp).clip(RoundedCornerShape(7.dp)).background(if (c > 0) sage() else sagePale())); Text(d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).take(1), color = muted(), fontSize = 11.sp, modifier = Modifier.padding(top = 7.dp)) } } } } }
        item { Spacer(Modifier.height(20.dp)); Eyebrow("YOUR STEADY STEPS"); habits.forEach { h -> StatCard(h.name, currentStreak(h, done).toString() + " day", "Current streak") }; Spacer(Modifier.height(10.dp)); Eyebrow("NOTICE YOUR NATURAL RHYTHM"); Spacer(Modifier.height(8.dp)); Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, line())) { Column(Modifier.padding(20.dp)) { Text("Weekly consistency rate", fontSize = 19.sp, fontWeight = FontWeight.Bold); (4 downTo 1).forEach { w -> val end = today.minusDays(((w - 1) * 7).toLong()); val start = end.minusDays(6); val sch = habits.sumOf { h -> (0..6).count { d -> val date = start.plusDays(d.toLong()); !date.isBefore(LocalDate.parse(h.startDate)) && !VacationPrefs.isVacation(date) } }; val com = habits.sumOf { h -> (0..6).count { d -> "${h.id}|${start.plusDays(d.toLong())}" in done } }; val p = if (sch == 0) 0 else com * 100 / sch; Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) { Text("$w wk", color = muted(), modifier = Modifier.width(42.dp)); LinearProgressIndicator(progress = { p / 100f }, modifier = Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(5.dp)), color = sage(), trackColor = sagePale()); Text("$p%", modifier = Modifier.width(42.dp), color = muted(), fontSize = 12.sp) } } } } }
        item {
            Spacer(Modifier.height(20.dp))
            Eyebrow("EVERY HABIT, IN VIEW")
            Text("Your progress by habit", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
            Text("Every habit gets its own history here — check-ins, steps, minutes or pages.", color = muted(), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(10.dp))
        }
        items(habits) { h ->
            val weekStart = today.minusDays(6)
            val monthStart = today.withDayOfMonth(1)
            val yearStart = today.withDayOfYear(1)
            val activityHistory = activityLogs.filter { it.habitId == h.id }
            val readingHistory = readingLogs.filter { it.habitId == h.id }
            fun progressTotal(start: LocalDate): Int = when (h.progressType) {
                "steps", "minutes" -> activityHistory.filter { log ->
                    val d = LocalDate.parse(log.date)
                    !d.isBefore(start) && !d.isAfter(today) && !d.isBefore(LocalDate.parse(h.startDate))
                }.sumOf { it.amount }
                "pages" -> readingHistory.filter { log ->
                    val d = LocalDate.parse(log.date)
                    !d.isBefore(start) && !d.isAfter(today) && !d.isBefore(LocalDate.parse(h.startDate))
                }.sumOf { it.pagesRead }
                else -> (0..((today.toEpochDay() - start.toEpochDay()).toInt())).count { offset ->
                    val d = start.plusDays(offset.toLong())
                    !d.isBefore(LocalDate.parse(h.startDate)) && "${h.id}|$d" in done
                }
            }
            val unit = if (h.progressType == "standard") "check-ins" else progressUnit(h.progressType)
            val goal = readingGoals.firstOrNull { it.habitId == h.id }
            Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, line()), modifier = Modifier.padding(bottom = 10.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(sagePale()), contentAlignment = Alignment.Center) { Icon(habitIcon(h.iconKey), null, tint = sage()) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) { Text(h.name, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text("${currentStreak(h, done)} day streak", color = muted(), fontSize = 12.sp) }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        ActivityTotal("Today", progressTotal(today), unit, Modifier.weight(1f))
                        ActivityTotal("7 days", progressTotal(weekStart), unit, Modifier.weight(1f))
                        ActivityTotal("This month", progressTotal(monthStart), unit, Modifier.weight(1f))
                        ActivityTotal("This year", progressTotal(yearStart), unit, Modifier.weight(1f))
                    }
                    if (goal != null) {
                        val totalRead = readingHistory.sumOf { it.pagesRead }.coerceAtMost(goal.totalPages)
                        val remaining = (goal.totalPages - totalRead).coerceAtLeast(0)
                        val pctGoal = if (goal.totalPages > 0) totalRead * 100 / goal.totalPages else 0
                        Text("$totalRead / ${goal.totalPages} pages · $pctGoal% · $remaining left", color = muted(), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                    }
                }
            }
        }

    }
}

@Composable
fun ActivityProgressCard(habit: Habit, history: List<ActivityProgress>, onSaveToday: (Int) -> Unit) {
    var showDialog by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }
    val today = LocalDate.now()
    val todayValue = history.firstOrNull { it.date == today.toString() }?.amount ?: 0
    val weekStart = today.minusDays(6)
    val monthStart = today.withDayOfMonth(1)
    val yearStart = today.withDayOfYear(1)
    fun totalFrom(start: LocalDate): Int = history.filter {
        val d = LocalDate.parse(it.date)
        !d.isBefore(start) && !d.isAfter(today) && !d.isBefore(LocalDate.parse(habit.startDate))
    }.sumOf { it.amount }
    val week = totalFrom(weekStart)
    val month = totalFrom(monthStart)
    val year = totalFrom(yearStart)
    val unit = progressUnit(habit.progressType)
    Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, line())) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(sagePale()), contentAlignment = Alignment.Center) { Icon(habitIcon(habit.iconKey), null, tint = sage()) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(habit.name, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text(if (habit.progressType == "steps") "Steps walked" else "Exercise time", color = muted(), fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                }
                Text("$todayValue $unit", color = sage(), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActivityTotal("Today", todayValue, unit, Modifier.weight(1f))
                ActivityTotal("7 days", week, unit, Modifier.weight(1f))
                ActivityTotal("This month", month, unit, Modifier.weight(1f))
                ActivityTotal("This year", year, unit, Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Button(onClick = { amount = todayValue.toString(); showDialog = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Edit, null); Spacer(Modifier.width(6.dp)); Text(if (todayValue == 0) "Log today's $unit" else "Update today's $unit")
            }
            if (history.isNotEmpty()) {
                Spacer(Modifier.height(14.dp)); Text("RECENT ACTIVITY", color = muted(), fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                history.take(5).forEach { log ->
                    Row(Modifier.fillMaxWidth().padding(top = 7.dp)) { Text(log.date, color = muted(), fontSize = 12.sp, modifier = Modifier.weight(1f)); Text("${log.amount} $unit", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
        }
    }
    if (showDialog) AlertDialog(
        onDismissRequest = { showDialog = false },
        title = { Text(if (habit.progressType == "steps") "How many steps did you walk today?" else "How many minutes did you exercise today?") },
        text = { Column { Text("Enter today's total. You can update it later.", color = muted()); Spacer(Modifier.height(10.dp)); OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text(if (habit.progressType == "steps") "Steps" else "Minutes") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth()) } },
        confirmButton = { Button(onClick = { val n = amount.toIntOrNull(); if (n != null) { onSaveToday(n.coerceAtLeast(0)); showDialog = false } }) { Text("Save") } },
        dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancel") } }
    )
}

@Composable
private fun ActivityTotal(label: String, value: Int, unit: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = sagePale(), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(10.dp)) { Text(label, color = muted(), fontSize = 10.sp); Text(value.toString(), fontSize = 17.sp, fontWeight = FontWeight.Bold, color = sageDark()); Text(unit, color = muted(), fontSize = 10.sp) }
    }
}

@Composable
fun ReadingProgressCard(habit: Habit, goal: ReadingGoal, history: List<ReadingLog>, onAddPages: (Int) -> Unit) {
    var showDialog by remember { mutableStateOf(false) }
    var pages by remember { mutableStateOf("") }
    val totalRead = history.sumOf { it.pagesRead }.coerceAtMost(goal.totalPages)
    val left = (goal.totalPages - totalRead).coerceAtLeast(0)
    val pct = if (goal.totalPages <= 0) 0f else totalRead.toFloat() / goal.totalPages.toFloat()
    val todayPages = history.firstOrNull { it.date == LocalDate.now().toString() }?.pagesRead ?: 0
    Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, line())) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(sagePale()), contentAlignment = Alignment.Center) { Icon(Icons.Default.MenuBook, null, tint = sage()) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(habit.name, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text(if (left == 0) "Book finished" else "$left pages left", color = muted(), fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                }
                Text("${(pct * 100).toInt()}%", color = sage(), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(14.dp))
            LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(8.dp)), color = sage(), trackColor = sagePale())
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("$totalRead / ${goal.totalPages} pages", fontWeight = FontWeight.SemiBold)
                    Text("Today: $todayPages pages", color = muted(), fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
                Spacer(Modifier.weight(1f))
                if (left > 0) Button(onClick = { pages = ""; showDialog = true }, shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Log pages") }
            }
            if (history.isNotEmpty()) {
                Spacer(Modifier.height(14.dp)); Text("RECENT READING", color = muted(), fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                history.take(5).forEach { log ->
                    Row(Modifier.fillMaxWidth().padding(top = 7.dp)) { Text(log.date, color = muted(), fontSize = 12.sp, modifier = Modifier.weight(1f)); Text("+${log.pagesRead} pages", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
        }
    }
    if (showDialog) AlertDialog(
        onDismissRequest = { showDialog = false },
        title = { Text("How many pages did you read today?") },
        text = { Column { Text("You have $left pages left.", color = muted()); Spacer(Modifier.height(10.dp)); OutlinedTextField(value = pages, onValueChange = { pages = it.filter(Char::isDigit) }, label = { Text("Pages read") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth()) } },
        confirmButton = { Button(onClick = { val n = pages.toIntOrNull() ?: 0; if (n in 1..left) { onAddPages(n); showDialog = false } }) { Text("Save") } },
        dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancel") } }
    )
}

@Composable fun StatCard(label: String, value: String, detail: String) { Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, line()), modifier = Modifier.padding(bottom = 10.dp)) { Column(Modifier.padding(20.dp)) { Eyebrow(label); Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)); Text(detail, color = muted(), fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp)) } } }

@Composable fun CoachScreen(db: MomentumDatabase, m: Modifier) { val habits by db.dao().active().collectAsState(emptyList()); val logs by db.dao().allLogs().collectAsState(emptyList()); val done = logs.filter { it.completed }.map { "${it.habitId}|${it.date}" }.toSet(); LazyColumn(m.fillMaxSize().padding(20.dp)) { item { PageTitle("Coach", "Personal feedback from your real check-ins.") }; habits.forEach { h -> item { StatCard(h.name, "${currentStreak(h, done)} day", if (currentStreak(h, done) > 0) "Keep the rhythm going." else "Try making the next check-in easier.") } } } }
@Composable fun TimelineScreen(db: MomentumDatabase, m: Modifier) { val events by db.extended().timeline().collectAsState(emptyList()); LazyColumn(m.fillMaxSize().padding(20.dp)) { item { PageTitle("Timeline", "Your habit journey, newest first.") }; if (events.isEmpty()) item { EmptyCard("No events yet", "Your real activity will appear here.") }; items(events) { e -> StatCard(e.title, e.date, e.detail) } } }
@Composable fun ChallengesScreen(db: MomentumDatabase, m: Modifier) { val logs by db.dao().allLogs().collectAsState(emptyList()); val total = logs.count { it.completed }; LazyColumn(m.fillMaxSize().padding(20.dp)) { item { PageTitle("Challenges", "Small challenges, meaningful progress.") }; item { StatCard("7-day streak", if (total >= 7) "Unlocked" else "$total / 7", "Based on real check-ins") }; item { StatCard("20 check-ins", if (total >= 20) "Unlocked" else "$total / 20", "Keep building gently") } } }
@Composable fun AchievementsScreen(db: MomentumDatabase, m: Modifier) { val logs by db.dao().allLogs().collectAsState(emptyList()); val total = logs.count { it.completed }; LazyColumn(m.fillMaxSize().padding(20.dp)) { item { PageTitle("Achievements", "Milestones earned from real activity.") }; item { StatCard("First step", if (total >= 1) "Unlocked" else "Locked", "First saved check-in") }; item { StatCard("Week warrior", if (total >= 7) "Unlocked" else "Locked", "Seven saved check-ins") }; item { StatCard("Momentum builder", if (total >= 20) "Unlocked" else "Locked", "Twenty saved check-ins") } } }

@Composable
fun SettingsScreen(db: MomentumDatabase, m: Modifier, onThemeChange: (String) -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? ComponentActivity
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf<String?>(null) }
    var changePin by remember { mutableStateOf(false) }
    var oldPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var selectedTheme by remember { mutableStateOf(ThemePrefs.get(ctx)) }

    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch { runCatching { val json = JsonBackup.create(db); ctx.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) } }.onSuccess { message = "Backup exported successfully." }.onFailure { message = "Export failed: ${it.message}" } }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { runCatching { val json = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Could not read file"); JsonRestore.restore(db, json) }.onSuccess { message = "Restore complete: $it records processed." }.onFailure { message = "Restore failed: ${it.message}" } }
    }

    LazyColumn(m.fillMaxSize().padding(20.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { PageTitle("Settings", "Keep Momentum private, local and yours.") }
        item { StatCard("OFFLINE-FIRST", "Local device", "Normal tracking works without internet.") }
        item { StatCard("APP LOCK", "4-digit PIN", "Your existing PIN protection stays enabled.") }
        item {
            Spacer(Modifier.height(4.dp))
            Text("APPEARANCE", color = muted(), fontSize = 11.sp, letterSpacing = 2.2.sp, fontWeight = FontWeight.Bold)
            Text("Theme color", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 7.dp))
            Text("Choose a Material 3-inspired accent for the whole app.", color = muted(), fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
            Spacer(Modifier.height(10.dp))
            ThemePicker(selectedTheme) { key ->
                selectedTheme = key
                ThemePrefs.set(ctx, key)
                onThemeChange(key)
            }
            Spacer(Modifier.height(18.dp))
        }
        item {
            Spacer(Modifier.height(6.dp))
            Text("PRIVACY", color = muted(), fontSize = 11.sp, letterSpacing = 2.2.sp, fontWeight = FontWeight.Bold)
            Text("Auto-lock", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 7.dp))
            Text("Lock Momentum again after it leaves the foreground.", color = muted(), fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
            Spacer(Modifier.height(10.dp))
            var autoLock by remember { mutableStateOf(AutoLockPrefs.getMinutes(ctx)) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf(0, 1, 5, 15).forEach { minutes ->
                    OutlinedButton(
                        onClick = { autoLock = minutes; AutoLockPrefs.setMinutes(ctx, minutes) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = if (autoLock == minutes) sagePale() else cardColor()),
                        border = BorderStroke(1.dp, if (autoLock == minutes) sage() else line()),
                        shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(vertical = 11.dp, horizontal = 4.dp)
                    ) { Text(if (minutes == 0) "Now" else "$minutes min", fontSize = 11.sp, color = if (autoLock == minutes) sageDark() else ink()) }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
        item {
            Spacer(Modifier.height(4.dp))
            Text("VACATION / SKIP MODE", color = muted(), fontSize = 11.sp, letterSpacing = 2.2.sp, fontWeight = FontWeight.Bold)
            Text("Protect your progress while away", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 7.dp))
            Text("Vacation dates are excused: they do not count as missed, reduce consistency, or break streaks.", color = muted(), fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
            Spacer(Modifier.height(10.dp))
            var vacStart by remember { mutableStateOf(VacationPrefs.getStart(ctx) ?: "") }
            var vacEnd by remember { mutableStateOf(VacationPrefs.getEnd(ctx) ?: "") }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val initial = runCatching { LocalDate.parse(vacStart) }.getOrDefault(LocalDate.now())
                    DatePickerDialog(ctx, { _, y, mo, d -> vacStart = LocalDate.of(y, mo + 1, d).toString(); VacationPrefs.setRange(ctx, vacStart, vacEnd.ifBlank { vacStart }); VacationPrefs.refresh(ctx) }, initial.year, initial.monthValue - 1, initial.dayOfMonth).show()
                }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text(if (vacStart.isBlank()) "Start date" else vacStart, fontSize = 12.sp) }
                OutlinedButton(onClick = {
                    val initial = runCatching { LocalDate.parse(vacEnd) }.getOrDefault(runCatching { LocalDate.parse(vacStart) }.getOrDefault(LocalDate.now()))
                    DatePickerDialog(ctx, { _, y, mo, d -> vacEnd = LocalDate.of(y, mo + 1, d).toString(); VacationPrefs.setRange(ctx, vacStart.ifBlank { vacEnd }, vacEnd); VacationPrefs.refresh(ctx) }, initial.year, initial.monthValue - 1, initial.dayOfMonth).show()
                }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text(if (vacEnd.isBlank()) "End date" else vacEnd, fontSize = 12.sp) }
            }
            Spacer(Modifier.height(8.dp))
            if (vacStart.isNotBlank() || vacEnd.isNotBlank()) {
                OutlinedButton(onClick = { vacStart = ""; vacEnd = ""; VacationPrefs.clear(ctx); VacationPrefs.refresh(ctx) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Clear vacation mode") }
            }
            Spacer(Modifier.height(14.dp))
        }
        item { Button(onClick = { changePin = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("Change PIN") } }
        item {
            Spacer(Modifier.height(8.dp))
            val notificationsAllowed = android.os.Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            val exactAllowed = android.os.Build.VERSION.SDK_INT < 31 || (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
            Text("NOTIFICATIONS", color = muted(), fontSize = 11.sp, letterSpacing = 2.2.sp, fontWeight = FontWeight.Bold)
            Text("Reliable habit reminders", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 7.dp))
            Text(if (notificationsAllowed) "Notifications are allowed." else "Notifications are currently blocked. Enable them to receive reminders.", color = muted(), fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
            Spacer(Modifier.height(9.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    if (android.os.Build.VERSION.SDK_INT >= 33 && activity != null) activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
                }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text(if (notificationsAllowed) "Notifications on" else "Enable") }
                OutlinedButton(onClick = { NotificationDiagnostics.postTest(ctx) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("Test now") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply { putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName) }
                ctx.startActivity(i)
            }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Notification settings") }
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
                    ctx.startActivity(i)
                }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text(if (exactAllowed) "Exact reminders enabled" else "Allow exact reminders") }
            }
            Spacer(Modifier.height(12.dp))
        }
        item { Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = { export.launch("momentum-backup-${LocalDate.now()}.json") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("Export backup") } }
        item { Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = { import.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("Import / restore backup") } }
        message?.let { item { Spacer(Modifier.height(10.dp)); Text(it, color = sage()) } }
    }

    if (changePin) AlertDialog(
        onDismissRequest = { changePin = false },
        title = { Text("Change PIN") },
        text = { Column { PinField(oldPin, "Current PIN") { if (it.length <= 4 && it.all(Char::isDigit)) oldPin = it }; Spacer(Modifier.height(8.dp)); PinField(newPin, "New 4-digit PIN") { if (it.length <= 4 && it.all(Char::isDigit)) newPin = it }; Spacer(Modifier.height(8.dp)); PinField(confirm, "Confirm new PIN") { if (it.length <= 4 && it.all(Char::isDigit)) confirm = it } } },
        confirmButton = { Button(onClick = { when { !PinGate.verify(ctx, oldPin) -> message = "Current PIN is incorrect."; newPin.length != 4 -> message = "New PIN must contain 4 digits."; newPin != confirm -> message = "PINs do not match."; else -> { PinGate.setPin(ctx, newPin); message = "PIN changed successfully."; changePin = false; oldPin = ""; newPin = ""; confirm = "" } } }) { Text("Save") } },
        dismissButton = { TextButton(onClick = { changePin = false }) { Text("Cancel") } }
    )
}

@Composable
fun ThemePicker(selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        MomentumThemeOptions.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { theme ->
                    val chosen = theme.key == selected
                    Surface(
                        modifier = Modifier.weight(1f).height(66.dp).clickable { onSelect(theme.key) },
                        shape = RoundedCornerShape(18.dp),
                        color = if (chosen) theme.pale else cardColor(),
                        border = BorderStroke(1.dp, if (chosen) theme.primary else line())
                    ) {
                        Row(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(34.dp).clip(CircleShape).background(theme.primary), contentAlignment = Alignment.Center) {
                                if (chosen) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column { Text(theme.name, fontWeight = if (chosen) FontWeight.Bold else FontWeight.SemiBold); Text(if (chosen) "Selected" else "Tap to use", color = muted(), fontSize = 11.sp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun PageTitle(title: String, subtitle: String) { Spacer(Modifier.height(22.dp)); Text(title, fontSize = 32.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = muted(), fontSize = 16.sp, modifier = Modifier.padding(top = 6.dp)); Spacer(Modifier.height(20.dp)) }
@Composable fun Eyebrow(text: String) { Text(text, color = muted(), fontSize = 11.sp, letterSpacing = 2.2.sp, fontWeight = FontWeight.Bold) }
@Composable fun EmptyCard(title: String, detail: String) { Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, line()), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp)) { Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(detail, color = muted(), modifier = Modifier.padding(top = 6.dp)) } } }


private fun heatmapScheduled(h: Habit, date: LocalDate): Boolean {
    val start = runCatching { LocalDate.parse(h.startDate) }.getOrNull() ?: return false
    if (date.isBefore(start)) return false
    return when (h.frequency) {
        "Weekly" -> date.dayOfWeek == start.dayOfWeek
        else -> true
    }
}

@Composable
fun HabitActivityHeatmap(habits: List<Habit>, logs: List<HabitLog>) {
    if (habits.isEmpty()) return
    var selectedHabitId by remember(habits.firstOrNull()?.id) { mutableStateOf(habits.firstOrNull()?.id ?: 0L) }
    var mode by remember { mutableStateOf("Month") }
    var year by remember { mutableStateOf(LocalDate.now().year) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    val habit = habits.firstOrNull { it.id == selectedHabitId } ?: habits.first()
    val done = logs.filter { it.completed && it.habitId == habit.id }.map { it.date }.toSet()
    Card(colors = CardDefaults.cardColors(cardColor()), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, line()), modifier = Modifier.padding(top = 18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Eyebrow("ACTIVITY")
            Text("Your habit activity", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
            Text("Green = done · black = missed · tan = vacation · grey = not scheduled or future", color = muted(), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(12.dp))
            if (habits.size > 1) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    habits.forEach { h ->
                        FilterChip(selected = h.id == selectedHabitId, onClick = { selectedHabitId = h.id }, label = { Text(h.name, maxLines = 1) })
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Month", "Year").forEach { item ->
                    OutlinedButton(onClick = { mode = item }, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (mode == item) sagePale() else cardColor()), border = BorderStroke(1.dp, if (mode == item) sage() else line()), shape = RoundedCornerShape(14.dp)) { Text(item, color = if (mode == item) sageDark() else ink()) }
                }
            }
            Spacer(Modifier.height(10.dp))
            if (mode == "Month") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Default.ChevronLeft, null) }
                    Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy")), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClick = { month = month.plusMonths(1) }) { Icon(Icons.Default.ChevronRight, null) }
                }
                MonthActivityGrid(habit, month, done)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { year-- }) { Icon(Icons.Default.ChevronLeft, null) }
                    Text(year.toString(), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClick = { year++ }) { Icon(Icons.Default.ChevronRight, null) }
                }
                YearActivityGrid(habit, year, done)
            }
        }
    }
}

@Composable
private fun MonthActivityGrid(habit: Habit, month: YearMonth, done: Set<String>) {
    val first = month.atDay(1).dayOfWeek.value % 7
    val days = month.lengthOfMonth()
    val today = LocalDate.now()
    Row(Modifier.fillMaxWidth()) { listOf("S","M","T","W","T","F","S").forEach { Text(it, modifier = Modifier.weight(1f), color = muted(), fontSize = 10.sp) } }
    Spacer(Modifier.height(6.dp))
    for (week in 0 until ((first + days + 6) / 7)) {
        Row(Modifier.fillMaxWidth()) {
            for (col in 0..6) {
                val n = week * 7 + col - first + 1
                Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp)) {
                    if (n in 1..days) {
                        val d = month.atDay(n)
                        val fill = when {
                            d.isAfter(today) || !heatmapScheduled(habit, d) -> line()
                            VacationPrefs.isVacation(d) -> Color(0xFFD8C29A)
                            done.contains(d.toString()) -> sage()
                            else -> Color(0xFF161A18)
                        }
                        Box(Modifier.fillMaxSize().clip(RoundedCornerShape(5.dp)).background(fill), contentAlignment = Alignment.Center) {
                            Text(n.toString(), fontSize = 9.sp, color = if (fill == Color(0xFF161A18) || fill == sage()) Color.White else if (d.isAfter(today)) muted() else ink())
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun YearActivityGrid(habit: Habit, year: Int, done: Set<String>) {
    val today = LocalDate.now()
    val start = LocalDate.of(year, 1, 1)
    val end = LocalDate.of(year, 12, 31)
    val totalDays = start.lengthOfYear()
    val first = start.dayOfWeek.value % 7
    val rows = 7
    val cols = ((first + totalDays + 6) / 7)
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        Column {
            Row(Modifier.padding(bottom = 4.dp)) {
                for (c in 0 until cols) {
                    val d = start.plusDays((c * 7L - first).coerceAtLeast(0))
                    Text(if (d.dayOfMonth <= 7) d.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).take(1) else "", modifier = Modifier.width(10.dp), fontSize = 8.sp, color = muted())
                }
            }
            for (r in 0 until rows) {
                Row {
                    for (c in 0 until cols) {
                        val offset = c * 7L + r - first
                        val d = if (offset in 0 until totalDays) start.plusDays(offset) else null
                        val fill = when {
                            d == null || d.isAfter(today) || !heatmapScheduled(habit, d) -> line()
                            VacationPrefs.isVacation(d) -> Color(0xFFD8C29A)
                            done.contains(d.toString()) -> sage()
                            else -> Color(0xFF161A18)
                        }
                        Box(Modifier.size(9.dp).padding(1.dp).clip(RoundedCornerShape(2.dp)).background(fill))
                    }
                }
            }
        }
    }
    Text("Jan", color = muted(), fontSize = 9.sp, modifier = Modifier.padding(top = 5.dp))
}

fun currentStreak(h: Habit, done: Set<String>): Int { var d = LocalDate.now(); var n = 0; val start = runCatching { LocalDate.parse(h.startDate) }.getOrDefault(d); while (!d.isBefore(start)) { if (VacationPrefs.isVacation(d)) { d = d.minusDays(1); continue }; if ("${h.id}|$d" in done) { n++; d = d.minusDays(1) } else break }; return n }
