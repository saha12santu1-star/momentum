package com.momentum.app

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="habits")
data class Habit(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val name:String,
    val description:String="",
    val category:String="General",
    val frequency:String="Daily",
    val reminderMinutes:Int?=null,
    val difficulty:String="Easy",
    val startDate:String,
    val archived:Boolean=false,
    val iconKey:String="book",
    val progressType:String="standard"
)

@Entity(tableName="habit_logs",primaryKeys=["habitId","date"])
data class HabitLog(val habitId:Long,val date:String,val completed:Boolean=true)
