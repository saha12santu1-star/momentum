Momentum v2.1
Notification reliability update.
- New notification channel to avoid stale channel settings from earlier builds.
- Test notification button in Settings.
- Notification settings shortcut.
- Exact alarm permission shortcut/status.
- Reschedule reminders when app resumes, after reboot/time changes/package update/exact-alarm permission changes.
- Reliable next-trigger calculation using local date/time.
- Dedicated notification icon.
