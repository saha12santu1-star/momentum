Momentum v15

Adds optional Reading Progress tracking. Reading habits can store a total page count and daily page logs, showing pages read, pages left, percentage progress, and recent daily reading history. Progress is stored locally and included in JSON backup/restore.
