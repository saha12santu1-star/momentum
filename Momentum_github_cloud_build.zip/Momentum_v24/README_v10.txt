Momentum v1.0 checked build package.

Key fixes:
- 4-digit PIN only; no biometric code or permission.
- Fixed Kotlin visibility error by making Screen accessible to DrawerContent.
- Room PrimaryKey is already correct in Habit.kt.
- App launcher icon is included.
- Offline-first Room database retained.
- Build memory increased to reduce D8 Java heap failures.
- Workflow no longer applies a duplicate PrimaryKey patch.


Momentum v14 adds built-in habit templates, per-habit icon selection, and persistent Material 3-inspired theme colors.
