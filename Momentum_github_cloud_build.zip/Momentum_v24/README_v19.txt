Momentum v1.8
- Study template now enables reading/page tracking and appears in Insights as Reading Overview.
- Vacation/Skip Mode in Settings excuses a date range from missed/consistency/streak calculations.
- Existing v17 activity heatmaps, dark theme, auto-lock, walking/exercise trackers and 12-hour reminders retained.
