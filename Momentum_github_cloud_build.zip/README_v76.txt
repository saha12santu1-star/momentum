Reflection v76 — Compact note attachments and folder management

Version: 3.24 (versionCode 54)

Changes from v75:
- Removed the numbered-list, bullet-list, and quote toolbar buttons because they were not reliably usable. Other formatting controls remain.
- Replaced large attachment cards in the note editor with compact, single-line rows and type icons: music, video, image, EPUB/book, PDF, and other document.
- The folder field can be collapsed after setting a folder; the editor then shows a compact folder label with Change and Remove actions.
- Added a Move action on each note card so an individual note can be moved to an existing folder, a new folder, or no folder.
- Preserved PDF/EPUB reading capability from within a note; this is reading, not annotation.
- Note text and folder names are included in the existing JSON backup used by Google Drive sync. Attachment binary files remain excluded from the JSON/Google Drive backup to avoid oversized database/cloud backups; Markdown export includes attachments in its separate attachments folder.
- Existing habit backup logic and Google Drive connection code were not intentionally changed in this version.

Validation:
- ZIP integrity is checked after packaging.
- Android compilation and device testing were not available in this environment. Run GitHub Actions before installing.
