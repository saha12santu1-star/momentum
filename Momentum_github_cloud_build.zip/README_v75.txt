Reflection v75 — Notes formatting and portable attachment export

Version: 3.23 (versionCode 53)

Changes from v74:
- Made list toolbar labels explicit: numbered list, bullet list, and quote.
- Added automatic continuation when pressing Enter inside a numbered list, bullet list, or quote. Numbered lists increment (1., 2., 3.); bullets and quotes continue on the next line.
- Markdown notes export now copies attached PDFs, EPUBs, images, and other stored reader files into an attachments/ directory beside the .md files, then adds relative Markdown links (and image embeds for image attachments) to each note's export.
- Does not change or delete local attachments or existing habit/Google Drive backup data.

Notes:
- The Markdown backup is portable: keep the .md files and the accompanying attachments/ folder together.
- Full Android compilation and device testing have not been performed in this environment. Run the repository's GitHub Actions build before installing.
