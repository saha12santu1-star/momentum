Reflection v45 — Google Drive authorization diagnostic build

This build keeps the existing Reflection app and Google Drive sync design intact.

Diagnostic change:
- Reports the exact Android activity result code after Google account selection.
- Reports whether Google returned an Intent and which extra keys were present (names only; no token values).
- If Google Play services rejects the authorization result, reports the API status code/message.
- Successful authorization behavior is unchanged.
- No Google OAuth client secret is bundled in the APK.

The GitHub workflow can continue using the outer ZIP as Momentum_github_cloud_build.zip.
It automatically extracts the *_build_ready.zip inside it.
