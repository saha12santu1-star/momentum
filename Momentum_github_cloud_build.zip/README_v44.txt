Reflection v44 — Google Drive authorization diagnostic build

This build keeps the existing Reflection app and Google Drive sync design intact.

Change in this version:
- Google Drive authorization now uses the Activity-level authorization result path.
- The app shows a clear message if Google returns an error, cancellation, no token, or another authorization step.
- Successful authorization marks Google Drive connected and refreshes the screen.
- No Google OAuth client secret is bundled in the APK.

The GitHub workflow can continue using this outer ZIP as Momentum_github_cloud_build.zip.
It automatically extracts the *_build_ready.zip inside it.
