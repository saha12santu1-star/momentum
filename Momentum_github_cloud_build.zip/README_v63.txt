Reflection v63 — Custom Actions + Glass UI

Based on the uploaded Reflection v62 source ZIP.

Changes:
- Added nested custom actions for every main habit.
- Actions support Yes/No or numeric tracking, custom units, optional numeric targets, required/optional status, ordering, editing and removal.
- Added daily action records with per-date history and numeric target progress.
- Main-habit completion is derived from required actions when the habit has required actions; optional actions do not block completion.
- Added action history to the merged Insights/Calendar experience and per-action totals to Insights.
- Added Room migration 8 -> 9 for habit_actions and habit_action_logs.
- Extended JSON backup/restore and therefore the existing Google Drive sync payload to preserve action definitions and logs.
- Added translucent surfaces, soft mint/secondary glow blooms, and glass-inspired navigation/card styling. This is a Compose translucent/gradient treatment, not a true OS-level backdrop blur.
- Kept Today as the place to create and check in habits, Insights as the combined Progress/Calendar destination, and Pomodoro as a separate destination.
- System theme follows Android light/dark mode by default, with existing manual theme overrides preserved.

Build notes:
- This ZIP contains source code, not a compiled APK.
- The environment used to prepare this ZIP did not have Gradle or the Android SDK installed, so a full Android compile could not be run here.
- Build using the existing GitHub Actions workflow in your repository or Android Studio with the Android SDK and Gradle dependencies configured.
- Before installing on your primary device, make a local JSON backup and test migration, action history, restore, and Google Drive sync on a test installation.
