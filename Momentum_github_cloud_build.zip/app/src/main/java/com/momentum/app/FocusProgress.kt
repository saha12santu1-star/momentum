package com.momentum.app

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "focus_sessions")
data class FocusSession(
    @androidx.room.PrimaryKey(autoGenerate = true) val id: Long = 0,
    val habitId: Long? = null,
    val date: String,
    val minutes: Int,
    val completed: Boolean = true
)

@Dao
interface FocusDao {
    @Query("SELECT * FROM focus_sessions ORDER BY id DESC")
    fun sessions(): Flow<List<FocusSession>>

    @Query("SELECT * FROM focus_sessions ORDER BY id DESC")
    suspend fun sessionsOnce(): List<FocusSession>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun add(session: FocusSession)

    @Query("DELETE FROM focus_sessions")
    suspend fun clearAll()
}
