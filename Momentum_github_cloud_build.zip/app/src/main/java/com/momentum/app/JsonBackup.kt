package com.momentum.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.flow.first

object JsonBackup {
    suspend fun create(context: Context, db: MomentumDatabase): String {
        val habits = db.dao().allHabitsOnce()
        val logs = db.dao().allLogsOnce()
        val habitActions = db.actions().allActionsOnce()
        val habitActionLogs = db.actions().allLogsOnce()
        val readingGoals = db.reading().goalsOnce()
        val readingLogs = db.reading().logsOnce()
        val activityLogs = db.activity().logsOnce()
        val focusSessions = db.focus().sessionsOnce()
        val timeline = db.extended().timelineOnce()
        val challenges = db.extended().challengesOnce()
        val achievements = db.extended().achievementsOnce()
        val appSettings = db.settings().all()
        val templates = db.settings().templatesOnce()
        val notes = db.notes().allOnce()
        val noteFolders = db.notes().observeFolders().first()
        val readerDocuments = db.notes().allDocumentsOnce()

        val root = JSONObject()
            .put("format", "momentum-json")
            .put("version", 12)
            .put("createdAt", java.time.LocalDateTime.now().toString())
            .put("databaseVersion", 12)

        root.put("habits", JSONArray().apply { habits.forEach { h -> put(JSONObject()
            .put("id", h.id).put("name", h.name).put("description", h.description)
            .put("category", h.category).put("frequency", h.frequency)
            .put("difficulty", h.difficulty).put("startDate", h.startDate)
            .put("reminderMinutes", h.reminderMinutes).put("archived", h.archived)
            .put("iconKey", h.iconKey).put("progressType", h.progressType)
            .put("goalDays", h.goalDays)) } })
        root.put("logs", JSONArray().apply { logs.forEach { l -> put(JSONObject()
            .put("habitId", l.habitId).put("date", l.date).put("completed", l.completed)) } })
        root.put("habitActions", JSONArray().apply { habitActions.forEach { a -> put(JSONObject()
            .put("id", a.id).put("habitId", a.habitId).put("name", a.name)
            .put("trackingType", a.trackingType).put("unit", a.unit).put("target", a.target)
            .put("iconKey", a.iconKey).put("sortOrder", a.sortOrder).put("required", a.required)
            .put("archived", a.archived)) } })
        root.put("habitActionLogs", JSONArray().apply { habitActionLogs.forEach { l -> put(JSONObject()
            .put("actionId", l.actionId).put("date", l.date).put("completed", l.completed)
            .put("amount", l.amount)) } })
        root.put("readingGoals", JSONArray().apply { readingGoals.forEach { g -> put(JSONObject()
            .put("habitId", g.habitId).put("totalPages", g.totalPages)) } })
        root.put("readingLogs", JSONArray().apply { readingLogs.forEach { l -> put(JSONObject()
            .put("habitId", l.habitId).put("date", l.date).put("pagesRead", l.pagesRead)) } })
        root.put("activityLogs", JSONArray().apply { activityLogs.forEach { l -> put(JSONObject()
            .put("habitId", l.habitId).put("date", l.date).put("amount", l.amount)) } })
        root.put("focusSessions", JSONArray().apply { focusSessions.forEach { s -> put(JSONObject()
            .put("id", s.id).put("habitId", s.habitId).put("date", s.date).put("minutes", s.minutes).put("completed", s.completed)) } })
        root.put("timeline", JSONArray().apply { timeline.forEach { e -> put(JSONObject()
            .put("id", e.id).put("date", e.date).put("title", e.title).put("detail", e.detail)) } })
        root.put("challenges", JSONArray().apply { challenges.forEach { c -> put(JSONObject()
            .put("challengeId", c.challengeId).put("progress", c.progress).put("target", c.target)) } })
        root.put("achievements", JSONArray().apply { achievements.forEach { a -> put(JSONObject()
            .put("id", a.id).put("title", a.title).put("unlocked", a.unlocked).put("unlockedDate", a.unlockedDate)) } })
        root.put("appSettings", JSONArray().apply { appSettings.forEach { s -> put(JSONObject()
            .put("key", s.key).put("value", s.value)) } })
        root.put("habitTemplates", JSONArray().apply { templates.forEach { t -> put(JSONObject()
            .put("id", t.id).put("name", t.name).put("description", t.description)
            .put("category", t.category).put("frequency", t.frequency).put("difficulty", t.difficulty)) } })
        root.put("notes", JSONArray().apply { notes.forEach { n -> put(JSONObject()
            .put("id", n.id).put("title", n.title).put("markdown", n.markdown)
            .put("createdAt", n.createdAt).put("updatedAt", n.updatedAt).put("folder", n.folder)) } })
        root.put("noteFolders", JSONArray().apply { noteFolders.forEach { f -> put(JSONObject().put("name", f.name).put("createdAt", f.createdAt)) } })
        // Reader files are embedded in the normal backup so the library can be restored
        // and synced to another tablet. Imported files are capped at 40 MB each.
        root.put("readerDocuments", JSONArray().apply { readerDocuments.forEach { d -> put(JSONObject()
            .put("id", d.id).put("fileName", d.fileName).put("mimeType", d.mimeType)
            .put("contentBase64", android.util.Base64.encodeToString(d.content, android.util.Base64.NO_WRAP))
            .put("addedAt", d.addedAt).put("lastPosition", d.lastPosition)) } })

        // Portable settings. The PIN and Android storage URI are intentionally not
        // exported: both are device-specific security/access credentials.
        root.put("settings", JSONObject()
            .put("theme", ThemePrefs.get(context))
            .put("autoLockMinutes", AutoLockPrefs.getMinutes(context))
            .put("vacationStart", VacationPrefs.getStart(context))
            .put("vacationEnd", VacationPrefs.getEnd(context))
            .put("autoBackupFrequency", AutoBackupPrefs.frequency(context))
            .put("autoBackupLast", AutoBackupPrefs.lastBackup(context))
        )
        root.put("counts", JSONObject()
            .put("habits", habits.size).put("logs", logs.size).put("habitActions", habitActions.size).put("habitActionLogs", habitActionLogs.size)
            .put("readingLogs", readingLogs.size).put("activityLogs", activityLogs.size).put("focusSessions", focusSessions.size)
            .put("timeline", timeline.size).put("challenges", challenges.size)
            .put("achievements", achievements.size).put("notes", notes.size).put("readerDocuments", readerDocuments.size))

        return root.toString(2)
    }
}
