package com.momentum.app

import androidx.room.Entity
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "timeline_events")
data class TimelineEvent(
    @androidx.room.PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val title: String,
    val detail: String = ""
)

@Entity(tableName = "challenge_progress")
data class ChallengeProgress(
    @androidx.room.PrimaryKey val challengeId: String,
    val progress: Int = 0,
    val target: Int
)

@Entity(tableName = "achievements")
data class Achievement(
    @androidx.room.PrimaryKey val id: String,
    val title: String,
    val unlocked: Boolean = false,
    val unlockedDate: String? = null
)

@Dao
interface ExtendedDao {
    @Query("SELECT * FROM timeline_events ORDER BY date DESC, id DESC")
    fun timeline(): Flow<List<TimelineEvent>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addEvent(event: TimelineEvent)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addEvents(items: List<TimelineEvent>)
    @Query("SELECT * FROM challenge_progress")
    fun challenges(): Flow<List<ChallengeProgress>>
    @Query("SELECT * FROM challenge_progress") suspend fun challengesOnce(): List<ChallengeProgress>
    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun saveChallenge(item: ChallengeProgress)
    @Query("SELECT * FROM achievements ORDER BY id")
    fun achievements(): Flow<List<Achievement>>
    @Query("SELECT * FROM timeline_events ORDER BY date DESC, id DESC") suspend fun timelineOnce(): List<TimelineEvent>
    @Query("SELECT * FROM achievements ORDER BY id") suspend fun achievementsOnce(): List<Achievement>
    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun saveAchievement(item: Achievement)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveAchievements(items: List<Achievement>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveChallenges(items: List<ChallengeProgress>)
    @Query("DELETE FROM timeline_events") suspend fun clearTimeline()
    @Query("DELETE FROM challenge_progress") suspend fun clearChallenges()
    @Query("DELETE FROM achievements") suspend fun clearAchievements()
}
