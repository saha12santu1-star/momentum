package com.momentum.app

import android.content.Context
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.Index
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.ColumnInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val markdown: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val folder: String = ""
)

@Entity(tableName = "note_folders")
data class NoteFolder(@androidx.room.PrimaryKey val name: String, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "reader_documents", indices = [Index(value = ["noteId"])])
data class ReaderDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val mimeType: String,
    @ColumnInfo(typeAffinity = androidx.room.ColumnInfo.BLOB) val content: ByteArray,
    val addedAt: Long = System.currentTimeMillis(),
    val lastPosition: Int = 0,
    val noteId: Long? = null,
    val filePath: String? = null
)

data class ReaderDocumentSummary(
    val id: Long,
    val fileName: String,
    val mimeType: String,
    val addedAt: Long,
    val lastPosition: Int,
    val noteId: Long?,
    val filePath: String?
)

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC") fun observeAll(): kotlinx.coroutines.flow.Flow<List<Note>>
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC") suspend fun allOnce(): List<Note>
    @Query("SELECT * FROM notes WHERE id=:id LIMIT 1") suspend fun get(id: Long): Note?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(note: Note): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(notes: List<Note>)
    @Query("DELETE FROM notes WHERE id=:id") suspend fun delete(id: Long)
    @Query("DELETE FROM notes") suspend fun clearAll()
    @Query("SELECT * FROM note_folders ORDER BY name COLLATE NOCASE") fun observeFolders(): kotlinx.coroutines.flow.Flow<List<NoteFolder>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertFolder(folder: NoteFolder)
    @Query("DELETE FROM note_folders") suspend fun clearFolders()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertFolders(folders: List<NoteFolder>)
    @Query("SELECT id, fileName, mimeType, addedAt, lastPosition, noteId, filePath FROM reader_documents ORDER BY addedAt DESC") fun observeDocuments(): kotlinx.coroutines.flow.Flow<List<ReaderDocumentSummary>>
    @Query("SELECT id, fileName, mimeType, addedAt, lastPosition, noteId, filePath FROM reader_documents ORDER BY addedAt DESC") suspend fun allDocumentsOnce(): List<ReaderDocumentSummary>
    @Query("SELECT id, fileName, mimeType, addedAt, lastPosition, noteId, filePath FROM reader_documents WHERE noteId=:noteId ORDER BY addedAt DESC") fun observeDocumentsForNote(noteId: Long): kotlinx.coroutines.flow.Flow<List<ReaderDocumentSummary>>
    @Query("SELECT id, fileName, mimeType, addedAt, lastPosition, noteId, filePath FROM reader_documents WHERE id=:id LIMIT 1") suspend fun getDocumentSummary(id: Long): ReaderDocumentSummary?
    @Query("UPDATE reader_documents SET lastPosition=:position WHERE id=:id") suspend fun updateDocumentPosition(id: Long, position: Int)
    @Query("UPDATE reader_documents SET noteId=:noteId WHERE id=:id") suspend fun updateDocumentNote(id: Long, noteId: Long)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertDocument(document: ReaderDocument): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertDocuments(documents: List<ReaderDocument>)
    @Query("DELETE FROM reader_documents WHERE id=:id") suspend fun deleteDocument(id: Long)
    @Query("DELETE FROM reader_documents") suspend fun clearDocuments()
}

object NotesBackupPrefs {
    private const val PREFS = "reflection_notes_backup"
    private const val TREE = "tree_uri"
    private const val LAST_BACKUP = "last_backup_at"
    fun tree(context: Context): String? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(TREE, null)
    fun setTree(context: Context, uri: String?) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(TREE, uri).apply()
    fun lastBackup(context: Context): Long = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(LAST_BACKUP, 0L)
    fun setLastBackup(context: Context, time: Long) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(LAST_BACKUP, time).apply()
}

object MarkdownNotesBackup {
    private val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US)
    private fun safeName(value: String): String = value.trim().ifBlank { "Untitled note" }
        .replace(Regex("[^A-Za-z0-9._ -]"), "_").replace(Regex("\\s+"), " ").take(70)

    suspend fun backupToTree(context: Context, db: MomentumDatabase, treeUri: String): Int = withContext(Dispatchers.IO) {
        val tree = DocumentFile.fromTreeUri(context, Uri.parse(treeUri)) ?: error("Notes backup folder is unavailable")
        require(tree.canWrite()) { "Notes backup folder is not writable" }
        val notes = db.notes().allOnce()
        val documents = db.notes().allDocumentsOnce()
        val batch = tree.createDirectory("Reflection-Notes-${stamp.format(Date())}") ?: error("Could not create notes backup folder")
        val attachmentDir = if (documents.any { it.noteId != null && it.filePath != null }) {
            batch.createDirectory("attachments") ?: error("Could not create attachments folder")
        } else null
        notes.forEach { note ->
            val noteAttachments = documents.filter { it.noteId == note.id && !it.filePath.isNullOrBlank() }
            val attachmentLinks = mutableListOf<Pair<String, String>>()
            noteAttachments.forEach { doc ->
                val source = java.io.File(doc.filePath!!)
                if (source.isFile) {
                    val safeFile = "note${note.id}-doc${doc.id}-${doc.fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100)}"
                    val destination = attachmentDir?.createFile(doc.mimeType.ifBlank { "application/octet-stream" }, safeFile)
                        ?: error("Could not create attachment export for ${doc.fileName}")
                    source.inputStream().buffered().use { input ->
                        context.contentResolver.openOutputStream(destination.uri, "wt")?.buffered()?.use { output -> input.copyTo(output) }
                            ?: error("Could not write attachment ${doc.fileName}")
                    }
                    attachmentLinks += safeFile to doc.fileName
                }
            }
            val filename = "${safeName(note.title)}-${note.id}.md"
            val file = batch.createFile("text/markdown", filename) ?: error("Could not create $filename")
            val content = buildString {
                append("---\n")
                append("title: \"").append(note.title.replace("\\", "\\\\").replace("\"", "\\\"")).append("\"\n")
                append("note_id: ").append(note.id).append("\n")
                append("created_at: ").append(note.createdAt).append("\n")
                append("updated_at: ").append(note.updatedAt).append("\n")
                append("folder: ").append(note.folder.replace("\n", " ")).append("\n")
                append("---\n\n")
                append(note.markdown)
                if (!note.markdown.endsWith("\n")) append('\n')
                if (attachmentLinks.isNotEmpty()) {
                    append("\n## Attachments\n\n")
                    attachmentLinks.forEach { (storedName, originalName) ->
                        val relative = "attachments/$storedName"
                        val image = originalName.substringAfterLast('.', "").lowercase() in setOf("png", "jpg", "jpeg", "gif", "webp", "bmp", "svg")
                        if (image) append("![${originalName.replace("]", "\\]")}]($relative)\n\n")
                        else append("- [${originalName.replace("]", "\\]")}]($relative)\n")
                    }
                }
            }
            context.contentResolver.openOutputStream(file.uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                ?: error("Could not write $filename")
        }
        notes.size
    }

    suspend fun restoreFromTree(context: Context, db: MomentumDatabase, treeUri: String): Int = withContext(Dispatchers.IO) {
        val tree = DocumentFile.fromTreeUri(context, Uri.parse(treeUri)) ?: error("Notes backup folder is unavailable")
        val directFiles = tree.listFiles().filter { it.isFile && it.name?.endsWith(".md", true) == true }
        val latestBackupFolder = tree.listFiles()
            .filter { it.isDirectory && it.name?.startsWith("Reflection-Notes-") == true }
            .maxByOrNull { it.name ?: "" }
        val files = if (directFiles.isNotEmpty()) directFiles else latestBackupFolder?.listFiles()
            ?.filter { it.isFile && it.name?.endsWith(".md", true) == true }.orEmpty()
        require(files.isNotEmpty()) { "No .md note files found in the selected folder. Choose a Reflection-Notes backup folder." }
        var restored = 0
        files.forEach { file ->
            val raw = context.contentResolver.openInputStream(file.uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: return@forEach
            val parsed = parseMarkdownFile(raw, file.name ?: "Imported note.md")
            db.notes().upsert(parsed)
            restored++
        }
        restored
    }

    private fun parseMarkdownFile(raw: String, filename: String): Note {
        var title = filename.removeSuffix(".md")
        var body = raw
        var id = 0L
        var created = System.currentTimeMillis()
        var updated = created
        var folder = ""
        if (raw.startsWith("---\n")) {
            val end = raw.indexOf("\n---", 4)
            if (end >= 0) {
                val header = raw.substring(4, end)
                Regex("(?m)^title:\\s*\\\"?(.*?)\\\"?$").find(header)?.let { title = it.groupValues[1].replace("\\\"", "\"") }
                Regex("(?m)^note_id:\\s*(\\d+)").find(header)?.let { id = it.groupValues[1].toLongOrNull() ?: 0L }
                Regex("(?m)^created_at:\\s*(\\d+)").find(header)?.let { created = it.groupValues[1].toLongOrNull() ?: created }
                Regex("(?m)^updated_at:\\s*(\\d+)").find(header)?.let { updated = it.groupValues[1].toLongOrNull() ?: updated }
                Regex("(?m)^folder:\\s*(.*)$").find(header)?.let { folder = it.groupValues[1].trim() }
                body = raw.substring(end + 4).trimStart('\n')
            }
        }
        return Note(id = id, title = title, markdown = body, createdAt = created, updatedAt = updated, folder = folder)
    }
}

private fun markdownToRichText(markdown: String): AnnotatedString {
    val token = Regex("\\*\\*.+?\\*\\*|~~.+?~~|<u>.+?</u>|(?<!\\*)\\*[^*\\n]+?\\*(?!\\*)", setOf(RegexOption.DOT_MATCHES_ALL))
    return buildAnnotatedString {
        var cursor = 0
        token.findAll(markdown).forEach { match ->
            append(markdown.substring(cursor, match.range.first))
            val raw = match.value
            val content: String
            val style: SpanStyle
            when {
                raw.startsWith("**") -> { content = raw.substring(2, raw.length - 2); style = SpanStyle(fontWeight = FontWeight.Bold) }
                raw.startsWith("~~") -> { content = raw.substring(2, raw.length - 2); style = SpanStyle(textDecoration = TextDecoration.LineThrough) }
                raw.startsWith("<u>") -> { content = raw.substring(3, raw.length - 4); style = SpanStyle(textDecoration = TextDecoration.Underline) }
                else -> { content = raw.substring(1, raw.length - 1); style = SpanStyle(fontStyle = FontStyle.Italic) }
            }
            withStyle(style) { append(content) }
            cursor = match.range.last + 1
        }
        append(markdown.substring(cursor))
    }
}

private fun richTextToMarkdown(value: AnnotatedString): String {
    val spans = value.spanStyles
    val out = StringBuilder()
    var previous = emptyList<String>()
    for (i in value.text.indices) {
        val active = spans.filter { i >= it.start && i < it.end }.flatMap { range ->
            val st = range.item
            buildList {
                if (st.fontWeight != null && st.fontWeight!!.weight >= FontWeight.SemiBold.weight) add("**")
                if (st.fontStyle == FontStyle.Italic) add("*")
                if (st.textDecoration?.contains(TextDecoration.Underline) == true) add("<u>")
                if (st.textDecoration?.contains(TextDecoration.LineThrough) == true) add("~~")
            }
        }.distinct().sortedBy { listOf("**", "*", "<u>", "~~").indexOf(it) }
        if (active != previous) {
            previous.asReversed().forEach { out.append(if (it == "<u>") "</u>" else it) }
            active.forEach { out.append(it) }
            previous = active
        }
        out.append(value.text[i])
    }
    previous.asReversed().forEach { out.append(if (it == "<u>") "</u>" else it) }
    return out.toString()
}

private fun applyStyle(value: TextFieldValue, style: SpanStyle): TextFieldValue {
    val start = value.selection.min
    val end = value.selection.max
    if (start == end) return value
    val builder = AnnotatedString.Builder(value.annotatedString)
    builder.addStyle(style, start, end)
    return value.copy(annotatedString = builder.toAnnotatedString())
}

@Composable
private fun FormatButton(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 3.dp)) {
        Text(label, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

@Composable
fun NotesScreen(db: MomentumDatabase, modifier: Modifier, onEdit: (Long) -> Unit, onRead: (Long) -> Unit) {
    val notes by db.notes().observeAll().collectAsState(emptyList())
    val savedFolders by db.notes().observeFolders().collectAsState(emptyList())
    val allDocuments by db.notes().observeDocuments().collectAsState(emptyList())
    val scope = rememberCoroutineScope()
    var legacyDocument by remember { mutableStateOf<ReaderDocumentSummary?>(null) }
    var query by remember { mutableStateOf("") }
    var activeFolder by remember { mutableStateOf("") }
    var showFolderDialog by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf("") }
    val folders = (savedFolders.map { it.name } + notes.map { it.folder.trim() }).filter { it.isNotBlank() }.distinct().sorted()
    val filtered = notes.filter { (activeFolder.isBlank() || it.folder == activeFolder) && (it.title.contains(query, true) || it.markdown.contains(query, true)) }
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Notes", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Text("Thoughts, quotes and reading annotations", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalButton(onClick = { scope.launch { val now = System.currentTimeMillis(); val id = db.notes().upsert(Note(title = "", folder = activeFolder, createdAt = now, updatedAt = now)); onEdit(id) } }, shape = RoundedCornerShape(18.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("New note") }
            }
        }
        item {
            Text("Attach PDFs, EPUBs, images or text files from inside any note. Attachments stay with their note and are included in the full Reflection backup.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (allDocuments.any { it.noteId == null }) item {
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Older imports", fontWeight = FontWeight.SemiBold)
                    Text("Move previously imported files into a note so they stay together.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    allDocuments.filter { it.noteId == null }.forEach { doc ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(doc.fileName, Modifier.weight(1f), maxLines = 2, fontSize = 13.sp)
                            TextButton(onClick = { legacyDocument = doc }) { Text("Move to note") }
                        }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                var expanded by remember { mutableStateOf(false) }
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text(if (activeFolder.isBlank()) "All folders" else activeFolder, maxLines = 1); Spacer(Modifier.width(5.dp)); Text("▾") }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        DropdownMenuItem(text = { Text("All folders") }, onClick = { activeFolder = ""; expanded = false })
                        folders.forEach { folder -> DropdownMenuItem(text = { Text(folder) }, onClick = { activeFolder = folder; expanded = false }) }
                    }
                }
                OutlinedButton(onClick = { newFolder = ""; showFolderDialog = true }, shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Add, null); Text("Folder") }
            }
        }
        item { OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search notes") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(18.dp)) }
        if (filtered.isEmpty()) item {
            Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f)) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (query.isBlank()) "A place for your thoughts" else "No matching notes", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Text(if (query.isBlank()) "Create a folder or save an idea, annotation, or quote." else "Try another search term.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
            }
        }
        items(filtered, key = { it.id }) { note ->
            Surface(modifier = Modifier.fillMaxWidth().clickable { onEdit(note.id) }, shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f), tonalElevation = 0.dp, shadowElevation = 1.dp) {
                Column(Modifier.padding(16.dp)) {
                    Text(note.title.ifBlank { "Untitled note" }, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    if (note.folder.isNotBlank()) Text("▣  ${note.folder}", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
                    Text(note.markdown.lineSequence().filter { it.isNotBlank() && !it.startsWith("---") && !it.startsWith("title:") && !it.startsWith("note_id:") }.joinToString(" ").take(160).ifBlank { "No text yet" }, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, maxLines = 3)
                    Spacer(Modifier.height(8.dp))
                    Text(java.text.SimpleDateFormat("dd MMM yyyy · h:mm a", Locale.getDefault()).format(Date(note.updatedAt)), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                }
            }
        }
    }
    legacyDocument?.let { doc ->
        AlertDialog(onDismissRequest = { legacyDocument = null }, title = { Text("Move attachment into a note") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(doc.fileName)
                notes.forEach { note -> TextButton(onClick = {
                    scope.launch {
                        withContext(Dispatchers.IO) { db.notes().updateDocumentNote(doc.id, note.id) }
                        legacyDocument = null
                    }
                }) { Text(note.title.ifBlank { "Untitled note" }) } }
            } }, confirmButton = { TextButton(onClick = { legacyDocument = null }) { Text("Cancel") } })
    }
    if (showFolderDialog) AlertDialog(onDismissRequest = { showFolderDialog = false }, title = { Text("Create folder") }, text = { OutlinedTextField(value = newFolder, onValueChange = { newFolder = it }, singleLine = true, label = { Text("Folder name") }) }, confirmButton = { TextButton(onClick = { val name = newFolder.trim(); if (name.isNotBlank()) { scope.launch { db.notes().upsertFolder(NoteFolder(name)) }; activeFolder = name }; showFolderDialog = false }) { Text("Create") } }, dismissButton = { TextButton(onClick = { showFolderDialog = false }) { Text("Cancel") } })
}

@Composable
fun NoteEditorScreen(db: MomentumDatabase, noteId: Long, modifier: Modifier, onBack: () -> Unit, onRead: (Long) -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val attachments by db.notes().observeDocumentsForNote(noteId).collectAsState(emptyList())
    var attachmentError by remember(noteId) { mutableStateOf<String?>(null) }
    val importAttachment = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                val name = DocumentFile.fromSingleUri(context, uri)?.name ?: "Attachment"
                val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                val mime = context.contentResolver.getType(uri) ?: when (ext) {
                    "pdf" -> "application/pdf"; "epub" -> "application/epub+zip"; "txt" -> "text/plain"; "html", "htm" -> "text/html"
                    "png" -> "image/png"; "jpg", "jpeg" -> "image/jpeg"; "webp" -> "image/webp"; "gif" -> "image/gif"; "bmp" -> "image/bmp"
                    else -> "application/octet-stream"
                }
                require(ext in setOf("pdf", "epub", "txt", "html", "htm", "png", "jpg", "jpeg", "webp", "gif", "bmp") || mime == "application/pdf" || mime.contains("epub", true) || mime.startsWith("image/") || mime == "text/plain" || mime == "text/html") {
                    "Supported attachments: PDF, EPUB, TXT, HTML and common image files."
                }
                val bytes = withContext(Dispatchers.IO) {
                    val input = context.contentResolver.openInputStream(uri) ?: error("Could not open the selected file")
                    input.use { stream ->
                        val out = java.io.ByteArrayOutputStream()
                        val buffer = ByteArray(8192)
                        var total = 0
                        while (true) {
                            val count = stream.read(buffer)
                            if (count < 0) break
                            total += count
                            require(total <= 15 * 1024 * 1024) { "Please choose a file smaller than 15 MB to keep sync and backups reliable." }
                            out.write(buffer, 0, count)
                        }
                        out.toByteArray()
                    }
                }
                require(bytes.isNotEmpty()) { "The selected file is empty" }
                if (ext == "pdf" || mime == "application/pdf") require(bytes.size >= 5 && String(bytes, 0, 5, Charsets.US_ASCII) == "%PDF-") { "This file does not appear to be a valid PDF." }
                if (ext == "epub" || mime.contains("epub", true)) require(bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()) { "This file does not appear to be a valid EPUB archive." }
                val existing = withContext(Dispatchers.IO) { db.notes().get(noteId) } ?: error("Save the note before attaching files")
                withContext(Dispatchers.IO) {
                    val dir = java.io.File(context.filesDir, "reader_documents")
                    if (!dir.exists() && !dir.mkdirs()) error("Could not create the local reading library")
                    val stored = java.io.File(dir, "${java.util.UUID.randomUUID()}-${name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                    stored.writeBytes(bytes)
                    try {
                        db.notes().upsertDocument(ReaderDocument(fileName = name, mimeType = mime, content = byteArrayOf(), noteId = existing.id, filePath = stored.absolutePath))
                    } catch (t: Throwable) { stored.delete(); throw t }
                }
            } catch (e: Exception) { attachmentError = e.message ?: "Could not attach this file" }
        }
    }
    var note by remember(noteId) { mutableStateOf<Note?>(null) }
    var title by remember(noteId) { mutableStateOf("") }
    var folder by remember(noteId) { mutableStateOf("") }
    var body by remember(noteId) { mutableStateOf(TextFieldValue("")) }
    var undoStack by remember(noteId) { mutableStateOf(listOf<TextFieldValue>()) }
    var redoStack by remember(noteId) { mutableStateOf(listOf<TextFieldValue>()) }
    var initialized by remember(noteId) { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var typingStyles by remember(noteId) { mutableStateOf(setOf<String>()) }
    LaunchedEffect(noteId) {
        val found = withContext(Dispatchers.IO) { db.notes().get(noteId) }
        if (found != null) { note = found; title = found.title; folder = found.folder; body = TextFieldValue(markdownToRichText(found.markdown)) }
        initialized = true
    }
    LaunchedEffect(title, folder, body.annotatedString, initialized) {
        if (!initialized) return@LaunchedEffect
        delay(550)
        val original = note ?: return@LaunchedEffect
        val updated = original.copy(title = title, folder = folder.trim(), markdown = richTextToMarkdown(body.annotatedString), updatedAt = System.currentTimeMillis())
        withContext(Dispatchers.IO) { db.notes().upsert(updated) }; note = updated
    }
    val saveAndBack = { scope.launch { note?.let { db.notes().upsert(it.copy(title = title, folder = folder.trim(), markdown = richTextToMarkdown(body.annotatedString), updatedAt = System.currentTimeMillis())) }; onBack() } }
    Column(modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { saveAndBack() }) { Icon(Icons.Default.ArrowBack, "Back") }
            BasicTextField(value = title, onValueChange = { title = it }, modifier = Modifier.weight(1f), singleLine = true, textStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground), decorationBox = { inner -> if (title.isBlank()) Text("Title", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 22.sp); inner() })
            IconButton(onClick = { saveAndBack() }) { Icon(Icons.Default.Check, "Done") }
            IconButton(onClick = { showDelete = true }) { Icon(Icons.Default.DeleteOutline, "Delete note") }
            IconButton(onClick = { importAttachment.launch(arrayOf("*/*")) }) { Icon(Icons.Default.Add, "Attach file") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
        OutlinedTextField(value = folder, onValueChange = { folder = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp), singleLine = true, label = { Text("Folder (optional)") }, placeholder = { Text("e.g. Reading, Ideas, Quotes") }, shape = RoundedCornerShape(12.dp))
        if (attachments.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Attachments", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                attachments.forEach { attachment ->
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)) {
                        Row(Modifier.fillMaxWidth().clickable { onRead(attachment.id) }.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (attachment.fileName.endsWith(".pdf", true)) Icons.Default.PictureAsPdf else if (attachment.mimeType.startsWith("image/")) Icons.Default.Image else Icons.Default.MenuBook, null)
                            Spacer(Modifier.width(8.dp))
                            Text(attachment.fileName, Modifier.weight(1f), maxLines = 2, fontSize = 13.sp)
                            IconButton(onClick = { scope.launch(Dispatchers.IO) {
                                attachment.filePath?.let { java.io.File(it).delete() }
                                db.notes().deleteDocument(attachment.id)
                            } }) { Icon(Icons.Default.DeleteOutline, "Remove attachment") }
                        }
                    }
                }
            }
        }
        attachmentError?.let { message ->
            Text(message, Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }
        BasicTextField(value = body, onValueChange = { rawIncoming ->
            undoStack = (undoStack + body).takeLast(60); redoStack = emptyList()
            var incoming = rawIncoming
            if (incoming.text.length > body.text.length && incoming.text.contains('\n')) {
                incoming = continueMarkdownList(incoming, body)
            }
            if (typingStyles.isNotEmpty() && incoming.text.length > body.text.length) {
                var prefix = 0
                while (prefix < body.text.length && prefix < incoming.text.length && body.text[prefix] == incoming.text[prefix]) prefix++
                var suffix = 0
                while (suffix < body.text.length - prefix && suffix < incoming.text.length - prefix && body.text[body.text.length - 1 - suffix] == incoming.text[incoming.text.length - 1 - suffix]) suffix++
                val start = prefix
                val end = incoming.text.length - suffix
                if (end > start) {
                    val builder = AnnotatedString.Builder(incoming.annotatedString)
                    if ("bold" in typingStyles) builder.addStyle(SpanStyle(fontWeight = FontWeight.Bold), start, end)
                    if ("italic" in typingStyles) builder.addStyle(SpanStyle(fontStyle = FontStyle.Italic), start, end)
                    if ("underline" in typingStyles) builder.addStyle(SpanStyle(textDecoration = TextDecoration.Underline), start, end)
                    if ("strike" in typingStyles) builder.addStyle(SpanStyle(textDecoration = TextDecoration.LineThrough), start, end)
                    incoming = incoming.copy(annotatedString = builder.toAnnotatedString())
                }
            }
            body = incoming
        }, modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onBackground, lineHeight = 27.sp), decorationBox = { inner ->
            Box(Modifier.fillMaxSize()) {
                if (body.text.isEmpty()) Text("Write a thought, paste a quote, or annotate something you read…", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), fontSize = 16.sp, lineHeight = 26.sp)
                inner()
            }
        })
        // This toolbar is at the bottom of the editor and is pushed directly above the IME.
        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)).horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            FormatButton("↶") { if (undoStack.isNotEmpty()) { redoStack = (redoStack + body).takeLast(60); body = undoStack.last(); undoStack = undoStack.dropLast(1) } }
            FormatButton("↷") { if (redoStack.isNotEmpty()) { undoStack = (undoStack + body).takeLast(60); body = redoStack.last(); redoStack = redoStack.dropLast(1) } }
            FormatButton("B") { if (body.selection.collapsed) typingStyles = if ("bold" in typingStyles) typingStyles - "bold" else typingStyles + "bold" else { undoStack = (undoStack + body).takeLast(60); redoStack = emptyList(); body = applyStyle(body, SpanStyle(fontWeight = FontWeight.Bold)) } }
            FormatButton("I") { if (body.selection.collapsed) typingStyles = if ("italic" in typingStyles) typingStyles - "italic" else typingStyles + "italic" else { undoStack = (undoStack + body).takeLast(60); redoStack = emptyList(); body = applyStyle(body, SpanStyle(fontStyle = FontStyle.Italic)) } }
            FormatButton("U") { if (body.selection.collapsed) typingStyles = if ("underline" in typingStyles) typingStyles - "underline" else typingStyles + "underline" else { undoStack = (undoStack + body).takeLast(60); redoStack = emptyList(); body = applyStyle(body, SpanStyle(textDecoration = TextDecoration.Underline)) } }
            FormatButton("S̶") { if (body.selection.collapsed) typingStyles = if ("strike" in typingStyles) typingStyles - "strike" else typingStyles + "strike" else { undoStack = (undoStack + body).takeLast(60); redoStack = emptyList(); body = applyStyle(body, SpanStyle(textDecoration = TextDecoration.LineThrough)) } }
            FormatButton("1. List") { undoStack = (undoStack + body).takeLast(60); redoStack = emptyList(); body = applyNumberedList(body) }
            FormatButton("• Bullet") { undoStack = (undoStack + body).takeLast(60); redoStack = emptyList(); body = applyLinePrefix(body, "- ") }
            FormatButton("❝ Quote") { undoStack = (undoStack + body).takeLast(60); redoStack = emptyList(); body = applyLinePrefix(body, "> ") }
            FormatButton("⇥") { body = changeIndent(body, increase = true, before = { undoStack = (undoStack + body).takeLast(60); redoStack = emptyList() }) }
            FormatButton("⇤") { body = changeIndent(body, increase = false, before = { undoStack = (undoStack + body).takeLast(60); redoStack = emptyList() }) }
        }
    }
    if (showDelete) AlertDialog(onDismissRequest = { showDelete = false }, title = { Text("Delete this note?") }, text = { Text("This note will be removed from Reflection. A previously exported Markdown backup is not affected.") }, confirmButton = { TextButton(onClick = { scope.launch { db.notes().delete(noteId); showDelete = false; onBack() } }) { Text("Delete") } }, dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } })
}



private fun continueMarkdownList(incoming: TextFieldValue, previous: TextFieldValue): TextFieldValue {
    // Continue a list only when the user has just inserted a newline at the caret.
    val oldText = previous.text
    val newText = incoming.text
    var commonPrefix = 0
    while (commonPrefix < oldText.length && commonPrefix < newText.length && oldText[commonPrefix] == newText[commonPrefix]) commonPrefix++
    if (commonPrefix >= newText.length || newText[commonPrefix] != '\n') return incoming
    val lineStart = newText.lastIndexOf('\n', commonPrefix - 1).let { if (it < 0) 0 else it + 1 }
    val previousLine = newText.substring(lineStart, commonPrefix)
    val numbered = Regex("^(\\s*)(\\d+)\\.\\s+(.+)$").find(previousLine)
    val bullet = Regex("^(\\s*)([-*+])\\s+(.+)$").find(previousLine)
    val quote = Regex("^(\\s*>\\s?)(.*)$").find(previousLine)
    val prefix = when {
        numbered != null -> numbered.groupValues[1] + (numbered.groupValues[2].toIntOrNull()?.plus(1) ?: 1).toString() + ". "
        bullet != null -> bullet.groupValues[1] + bullet.groupValues[2] + " "
        quote != null && quote.groupValues[2].isNotBlank() -> quote.groupValues[1]
        else -> return incoming
    }
    val caret = incoming.selection.end.coerceIn(0, incoming.annotatedString.length)
    val builder = AnnotatedString.Builder()
    if (caret > 0) builder.append(incoming.annotatedString.subSequence(0, caret))
    builder.append(prefix)
    if (caret < incoming.annotatedString.length) builder.append(incoming.annotatedString.subSequence(caret, incoming.annotatedString.length))
    return incoming.copy(annotatedString = builder.toAnnotatedString(), selection = TextRange(caret + prefix.length))
}

private fun applyNumberedList(value: TextFieldValue): TextFieldValue {
    val text = value.text
    val start = value.selection.min.coerceIn(0, text.length)
    val end = value.selection.max.coerceIn(0, text.length)
    val first = text.lastIndexOf('\n', start - 1).let { if (it < 0) 0 else it + 1 }
    val last = if (start == end) first else text.lastIndexOf('\n', end - 1).let { if (it < 0) 0 else it + 1 }
    val starts = mutableListOf(first)
    var cursor = first
    while (cursor < last) {
        val nl = text.indexOf('\n', cursor)
        if (nl < 0 || nl + 1 > last) break
        cursor = nl + 1
        starts += cursor
    }
    val numberPattern = Regex("^(\\s*)(\\d+\\.\\s+)")
    val allNumbered = starts.all { numberPattern.containsMatchIn(text.substring(it)) }
    data class Edit(val start: Int, val end: Int, val replacement: String)
    val edits = starts.mapIndexedNotNull { index, lineStart ->
        val match = numberPattern.find(text.substring(lineStart))
        if (allNumbered && match != null) {
            val markerStart = lineStart + match.groups[1]!!.value.length
            Edit(markerStart, lineStart + match.value.length, "")
        } else {
            val leading = match?.groups?.get(1)?.value.orEmpty()
            val markerStart = lineStart + leading.length
            val markerEnd = if (match != null) lineStart + match.value.length else markerStart
            Edit(markerStart, markerEnd, "${index + 1}. ")
        }
    }
    val builder = AnnotatedString.Builder()
    var source = 0
    var startDelta = 0
    var endDelta = 0
    edits.forEach { edit ->
        if (edit.start > source) builder.append(value.annotatedString.subSequence(source, edit.start))
        builder.append(edit.replacement)
        val delta = edit.replacement.length - (edit.end - edit.start)
        if (edit.start <= start) startDelta += delta
        if (edit.start < end || start == end) endDelta += delta
        source = edit.end
    }
    if (source < value.annotatedString.length) builder.append(value.annotatedString.subSequence(source, value.annotatedString.length))
    return value.copy(annotatedString = builder.toAnnotatedString(), selection = TextRange((start + startDelta).coerceIn(0, builder.length), (end + endDelta).coerceIn(0, builder.length)))
}

private fun applyLinePrefix(value: TextFieldValue, prefix: String): TextFieldValue {
    val text = value.text
    val start = value.selection.min.coerceIn(0, text.length)
    val end = value.selection.max.coerceIn(0, text.length)
    val first = text.lastIndexOf('\n', start - 1).let { if (it < 0) 0 else it + 1 }
    val last = if (start == end) first else text.lastIndexOf('\n', end - 1).let { if (it < 0) 0 else it + 1 }
    val lineStarts = mutableListOf(first)
    var cursor = first
    while (cursor < last) {
        val nl = text.indexOf('\n', cursor)
        if (nl < 0 || nl + 1 > last) break
        cursor = nl + 1
        lineStarts += cursor
    }
    val builder = AnnotatedString.Builder()
    var source = 0
    var startDelta = 0
    var endDelta = 0
    for (lineStart in lineStarts) {
        val already = text.startsWith(prefix, lineStart)
        val removeLen = if (already) prefix.length else 0
        if (lineStart > source) builder.append(value.annotatedString.subSequence(source, lineStart))
        if (already) {
            source = lineStart + removeLen
            if (lineStart < start) startDelta -= removeLen
            if (lineStart < end) endDelta -= removeLen
        } else {
            builder.append(prefix)
            source = lineStart
            if (lineStart <= start) startDelta += prefix.length
            if (lineStart < end || start == end) endDelta += prefix.length
        }
    }
    if (source < value.annotatedString.length) builder.append(value.annotatedString.subSequence(source, value.annotatedString.length))
    val newStart = (start + startDelta).coerceIn(0, builder.length)
    val newEnd = (end + endDelta).coerceIn(0, builder.length)
    return value.copy(annotatedString = builder.toAnnotatedString(), selection = TextRange(newStart, newEnd))
}

private fun changeIndent(value: TextFieldValue, increase: Boolean, before: () -> Unit): TextFieldValue {
    val text = value.text
    val annotated = value.annotatedString
    val selectionStart = value.selection.min.coerceIn(0, text.length)
    val selectionEnd = value.selection.max.coerceIn(0, text.length)
    val firstLine = text.lastIndexOf('\n', (selectionStart - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
    val lastLine = if (selectionEnd == selectionStart) firstLine else text.lastIndexOf('\n', (selectionEnd - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
    val starts = mutableListOf<Int>()
    var cursor = firstLine
    starts += cursor
    while (cursor < lastLine) {
        val next = text.indexOf('\n', cursor).let { if (it < 0) text.length else it + 1 }
        if (next <= cursor || next > lastLine) break
        starts += next
        cursor = next
    }

    // Build edits against the original text, then rebuild the AnnotatedString in one pass.
    // This avoids unsupported Builder.insert/delete methods and preserves existing span styles.
    data class Edit(val start: Int, val end: Int, val replacement: String)
    val edits = starts.mapNotNull { lineStart ->
        if (increase) Edit(lineStart, lineStart, "    ")
        else {
            val remove = when {
                text.startsWith("    ", lineStart) -> 4
                text.startsWith("\t", lineStart) -> 1
                text.startsWith(" ", lineStart) -> 1
                else -> 0
            }
            if (remove > 0) Edit(lineStart, lineStart + remove, "") else null
        }
    }.sortedBy { it.start }

    if (edits.isEmpty()) return value
    before()
    val builder = AnnotatedString.Builder()
    var sourceCursor = 0
    var startDelta = 0
    var endDelta = 0
    edits.forEach { edit ->
        if (edit.start > sourceCursor) builder.append(annotated.subSequence(sourceCursor, edit.start))
        builder.append(edit.replacement)
        val delta = edit.replacement.length - (edit.end - edit.start)
        if (edit.start <= selectionStart) startDelta += delta
        if (edit.start < selectionEnd || selectionStart == selectionEnd) endDelta += delta
        sourceCursor = edit.end
    }
    if (sourceCursor < annotated.length) builder.append(annotated.subSequence(sourceCursor, annotated.length))
    val adjustedStart = (selectionStart + startDelta).coerceIn(0, builder.length)
    val adjustedEnd = (selectionEnd + endDelta).coerceIn(0, builder.length)
    return value.copy(annotatedString = builder.toAnnotatedString(), selection = TextRange(adjustedStart, adjustedEnd))
}

@Composable
fun ReaderScreen(db: MomentumDatabase, documentId: Long, modifier: Modifier, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var document by remember(documentId) { mutableStateOf<ReaderDocumentSummary?>(null) }
    var documentBytes by remember(documentId) { mutableStateOf<ByteArray?>(null) }
    var loadError by remember(documentId) { mutableStateOf<String?>(null) }
    var pdfPage by remember(documentId) { mutableIntStateOf(0) }
    var pdfPageCount by remember(documentId) { mutableIntStateOf(0) }
    var pdfBitmap by remember(documentId) { mutableStateOf<Bitmap?>(null) }
    var imageBitmap by remember(documentId) { mutableStateOf<Bitmap?>(null) }
    var epubHtml by remember(documentId) { mutableStateOf<String?>(null) }
    var epubChapters by remember(documentId) { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var chapterIndex by remember(documentId) { mutableIntStateOf(0) }
    LaunchedEffect(documentId) {
        try {
            val doc = withContext(Dispatchers.IO) { db.notes().getDocumentSummary(documentId) } ?: error("Document not found")
            val storedPath = doc.filePath ?: error("This attachment was saved by an older version and cannot be read safely. Remove it and re-import the original file.")
            val bytes = withContext(Dispatchers.IO) {
                val stored = java.io.File(storedPath)
                require(stored.isFile && stored.canRead()) { "The local reading file is missing. Please re-import it." }
                stored.readBytes()
            }
            document = doc
            documentBytes = bytes
            if (doc.fileName.endsWith(".pdf", true) || doc.mimeType == "application/pdf") {
                val file = java.io.File(context.cacheDir, "reader-$documentId.pdf")
                withContext(Dispatchers.IO) { file.writeBytes(bytes) }
                val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(pfd)
                pdfPageCount = renderer.pageCount
                pdfPage = doc.lastPosition.coerceIn(0, (renderer.pageCount - 1).coerceAtLeast(0))
                renderer.close(); pfd.close()
            } else if (doc.mimeType.startsWith("image/") || doc.fileName.substringAfterLast('.', "").lowercase() in setOf("png", "jpg", "jpeg", "webp", "gif", "bmp")) {
                imageBitmap = withContext(Dispatchers.IO) { android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }
                require(imageBitmap != null) { "Could not decode this image" }
            } else if (doc.fileName.substringAfterLast('.', "").lowercase(Locale.ROOT) in setOf("txt", "html", "htm") || doc.mimeType == "text/plain" || doc.mimeType == "text/html") {
                val ext = doc.fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                val raw = withContext(Dispatchers.IO) { bytes.toString(Charsets.UTF_8) }
                val safeBody = if (ext == "html" || ext == "htm" || doc.mimeType == "text/html") {
                    raw.replace(Regex("<script\\b[^>]*>.*?</script>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)), "")
                } else raw.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>")
                epubChapters = listOf(doc.fileName to "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'><style>body{font-family:serif;font-size:19px;line-height:1.65;padding:18px;color:#222;background:#fff;overflow-wrap:anywhere}</style></head><body>$safeBody</body></html>")
                chapterIndex = 0
                epubHtml = epubChapters[0].second
            } else {
                val chapters = withContext(Dispatchers.IO) { extractEpubChapters(bytes) }
                require(chapters.isNotEmpty()) { "This EPUB has no readable chapters" }
                epubChapters = chapters
                chapterIndex = doc.lastPosition.coerceIn(0, chapters.lastIndex)
                epubHtml = chapters[chapterIndex].second
            }
        } catch (e: Exception) { loadError = e.message ?: "Could not open this document" }
    }
    LaunchedEffect(documentId, pdfPage, pdfPageCount, documentBytes?.size) {
        val doc = document ?: return@LaunchedEffect
        if (!(doc.fileName.endsWith(".pdf", true) || doc.mimeType == "application/pdf")) return@LaunchedEffect
        if (pdfPage !in 0 until pdfPageCount) return@LaunchedEffect
        try {
            val bytes = documentBytes ?: error("Document content is not available")
            val file = java.io.File(context.cacheDir, "reader-$documentId.pdf")
            val bitmap = withContext(Dispatchers.IO) {
                if (!file.exists() || file.length() != bytes.size.toLong()) file.writeBytes(bytes)
                val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(pfd)
                val page = renderer.openPage(pdfPage)
                val width = 1200
                val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                val image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                image.eraseColor(android.graphics.Color.WHITE)
                page.render(image, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close(); renderer.close(); pfd.close(); image
            }
            pdfBitmap = bitmap
            withContext(Dispatchers.IO) { db.notes().updateDocumentPosition(documentId, pdfPage) }
        } catch (e: Exception) { loadError = e.message ?: "Could not render PDF page" }
    }
    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text(document?.fileName ?: "Opening document…", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 2)
            if (pdfPageCount > 0) Text("${pdfPage + 1}/$pdfPageCount", style = MaterialTheme.typography.labelMedium)
            if (epubChapters.isNotEmpty()) Text("${chapterIndex + 1}/${epubChapters.size}", style = MaterialTheme.typography.labelMedium)
        }
        HorizontalDivider()
        when {
            loadError != null -> Text(loadError.orEmpty(), Modifier.padding(20.dp), color = MaterialTheme.colorScheme.error)
            document == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            document!!.fileName.endsWith(".pdf", true) || document!!.mimeType == "application/pdf" -> {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                    pdfBitmap?.let { androidx.compose.foundation.Image(it.asImageBitmap(), contentDescription = "PDF page ${pdfPage + 1}", modifier = Modifier.fillMaxWidth().padding(8.dp)) }
                }
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { if (pdfPage > 0) pdfPage-- }, enabled = pdfPage > 0) { Text("Previous page") }
                    OutlinedButton(onClick = { if (pdfPage + 1 < pdfPageCount) pdfPage++ }, enabled = pdfPage + 1 < pdfPageCount) { Text("Next page") }
                }
            }
            document!!.mimeType.startsWith("image/") || document!!.fileName.substringAfterLast('.', "").lowercase() in setOf("png", "jpg", "jpeg", "webp", "gif", "bmp") -> {
                Box(Modifier.weight(1f).fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                    imageBitmap?.let { androidx.compose.foundation.Image(it.asImageBitmap(), contentDescription = document?.fileName, modifier = Modifier.fillMaxWidth()) }
                }
            }
            else -> {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { if (chapterIndex > 0) { chapterIndex--; epubHtml = epubChapters[chapterIndex].second; document?.let { doc -> scope.launch(Dispatchers.IO) { db.notes().updateDocumentPosition(doc.id, chapterIndex) } } } }, enabled = chapterIndex > 0) { Text("Previous chapter") }
                    TextButton(onClick = { if (chapterIndex + 1 < epubChapters.size) { chapterIndex++; epubHtml = epubChapters[chapterIndex].second; document?.let { doc -> val position = chapterIndex; scope.launch(Dispatchers.IO) { db.notes().updateDocumentPosition(doc.id, position) } } } }, enabled = chapterIndex + 1 < epubChapters.size) { Text("Next chapter") }
                }
                AndroidView(modifier = Modifier.weight(1f).fillMaxWidth(), factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = false; settings.allowFileAccess = false; webViewClient = WebViewClient(); setBackgroundColor(android.graphics.Color.WHITE) } }, update = { web -> web.loadDataWithBaseURL(null, epubHtml ?: "", "text/html", "UTF-8", null) })
            }
        }
    }
}


private fun extractEpubChapters(bytes: ByteArray): List<Pair<String, String>> {
    val entries = linkedMapOf<String, ByteArray>()
    java.util.zip.ZipInputStream(bytes.inputStream()).use { zip ->
        while (true) {
            val entry = zip.nextEntry ?: break
            if (!entry.isDirectory) entries[entry.name] = zip.readBytes()
            zip.closeEntry()
        }
    }
    val container = entries["META-INF/container.xml"]?.toString(Charsets.UTF_8) ?: error("Invalid EPUB: missing container.xml")
    val opfPath = Regex("full-path=\"([^\"]+\\.opf)\"").find(container)?.groupValues?.get(1) ?: error("Invalid EPUB: package file not found")
    val opf = entries[opfPath]?.toString(Charsets.UTF_8) ?: error("Invalid EPUB: package file missing")
    val base = opfPath.substringBeforeLast('/', "")
    val manifest = Regex("<item\\b([^>]+)>", RegexOption.IGNORE_CASE).findAll(opf).mapNotNull { m ->
        val attrs = m.groupValues[1]
        val id = Regex("id=\"([^\"]+)\"").find(attrs)?.groupValues?.get(1) ?: return@mapNotNull null
        val href = Regex("href=\"([^\"]+)\"").find(attrs)?.groupValues?.get(1) ?: return@mapNotNull null
        val type = Regex("media-type=\"([^\"]+)\"").find(attrs)?.groupValues?.get(1).orEmpty()
        id to Triple(href, type, attrs)
    }.toMap()
    val ids = Regex("<itemref\\b[^>]*idref=\"([^\"]+)\"[^>]*/?>", RegexOption.IGNORE_CASE).findAll(opf).map { it.groupValues[1] }.toList()
    return ids.mapNotNull { id ->
        val item = manifest[id] ?: return@mapNotNull null
        val (href, type, _) = item
        if (!type.contains("xhtml") && !href.endsWith(".html", true) && !href.endsWith(".xhtml", true)) return@mapNotNull null
        val path = if (base.isBlank()) href else "$base/$href"
        var html = entries[path]?.toString(Charsets.UTF_8) ?: return@mapNotNull null
        html = html.replace(Regex("<script\\b[^>]*>.*?</script>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)), "")
        html = html.replace(Regex("<link\\b[^>]*>", RegexOption.IGNORE_CASE), "")
        val title = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1)?.replace(Regex("<[^>]+>"), "")?.trim().orEmpty().ifBlank { "Chapter" }
        var body = Regex("<body\\b[^>]*>(.*?)</body>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1) ?: html
        val imagePattern = Regex("(<img\\b[^>]*?\\bsrc=[\"'])([^\"']+)([\"'])", RegexOption.IGNORE_CASE)
        body = imagePattern.replace(body) { match ->
            val source = match.groupValues[2].substringBefore('#').substringBefore('?')
            val imagePath = try { java.nio.file.Paths.get(base, source).normalize().toString().replace('\\', '/') } catch (_: Exception) { source }
            val imageBytes = entries[imagePath]
            if (imageBytes == null || source.startsWith("http:") || source.startsWith("https:") || source.startsWith("data:")) match.value
            else {
                val ext = imagePath.substringAfterLast('.', "").lowercase()
                val imageMime = when (ext) { "png" -> "image/png"; "gif" -> "image/gif"; "webp" -> "image/webp"; "svg" -> "image/svg+xml"; else -> "image/jpeg" }
                match.groupValues[1] + "data:" + imageMime + ";base64," + android.util.Base64.encodeToString(imageBytes, android.util.Base64.NO_WRAP) + match.groupValues[3]
            }
        }
        val styled = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'><style>body{font-family:serif;font-size:19px;line-height:1.65;padding:18px;color:#222;background:#fff}img{max-width:100%;height:auto}pre{white-space:pre-wrap}a{color:#267b70}</style></head><body>$body</body></html>"
        title to styled
    }
}
