package com.momentum.app

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val markdown: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC") fun observeAll(): kotlinx.coroutines.flow.Flow<List<Note>>
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC") suspend fun allOnce(): List<Note>
    @Query("SELECT * FROM notes WHERE id=:id LIMIT 1") suspend fun get(id: Long): Note?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(note: Note): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(notes: List<Note>)
    @Query("DELETE FROM notes WHERE id=:id") suspend fun delete(id: Long)
    @Query("DELETE FROM notes") suspend fun clearAll()
}

object NotesBackupPrefs {
    private const val PREFS = "reflection_notes_backup"
    private const val TREE = "tree_uri"
    fun tree(context: Context): String? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(TREE, null)
    fun setTree(context: Context, uri: String?) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(TREE, uri).apply()
}

object MarkdownNotesBackup {
    private val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US)
    private fun safeName(value: String): String = value.trim().ifBlank { "Untitled note" }
        .replace(Regex("[^A-Za-z0-9._ -]"), "_").replace(Regex("\\s+"), " ").take(70)

    suspend fun backupToTree(context: Context, db: MomentumDatabase, treeUri: String): Int = withContext(Dispatchers.IO) {
        val tree = DocumentFile.fromTreeUri(context, Uri.parse(treeUri)) ?: error("Notes backup folder is unavailable")
        require(tree.canWrite()) { "Notes backup folder is not writable" }
        val notes = db.notes().allOnce()
        val batch = tree.createDirectory("Reflection-Notes-${stamp.format(Date())}") ?: error("Could not create notes backup folder")
        notes.forEach { note ->
            val filename = "${safeName(note.title)}-${note.id}.md"
            val file = batch.createFile("text/markdown", filename) ?: error("Could not create $filename")
            val content = buildString {
                append("---\n")
                append("title: \"").append(note.title.replace("\\", "\\\\").replace("\"", "\\\"")).append("\"\n")
                append("note_id: ").append(note.id).append("\n")
                append("created_at: ").append(note.createdAt).append("\n")
                append("updated_at: ").append(note.updatedAt).append("\n")
                append("---\n\n")
                append(note.markdown)
                if (!note.markdown.endsWith("\n")) append('\n')
            }
            context.contentResolver.openOutputStream(file.uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                ?: error("Could not write $filename")
        }
        notes.size
    }

    suspend fun restoreFromTree(context: Context, db: MomentumDatabase, treeUri: String): Int = withContext(Dispatchers.IO) {
        val tree = DocumentFile.fromTreeUri(context, Uri.parse(treeUri)) ?: error("Notes backup folder is unavailable")
        val directFiles = tree.listFiles().filter { it.isFile && it.name?.endsWith(".md", true) == true }
        val latestBackupFolder = tree.listFiles()
            .filter { it.isDirectory && it.name?.startsWith("Reflection-Notes-") == true }
            .maxByOrNull { it.name ?: "" }
        val files = if (directFiles.isNotEmpty()) directFiles else latestBackupFolder?.listFiles()
            ?.filter { it.isFile && it.name?.endsWith(".md", true) == true }.orEmpty()
        require(files.isNotEmpty()) { "No .md note files found in the selected folder. Choose a Reflection-Notes backup folder." }
        var restored = 0
        files.forEach { file ->
            val raw = context.contentResolver.openInputStream(file.uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: return@forEach
            val parsed = parseMarkdownFile(raw, file.name ?: "Imported note.md")
            db.notes().upsert(parsed)
            restored++
        }
        restored
    }

    private fun parseMarkdownFile(raw: String, filename: String): Note {
        var title = filename.removeSuffix(".md")
        var body = raw
        var id = 0L
        var created = System.currentTimeMillis()
        var updated = created
        if (raw.startsWith("---\n")) {
            val end = raw.indexOf("\n---", 4)
            if (end >= 0) {
                val header = raw.substring(4, end)
                Regex("(?m)^title:\\s*\\\"?(.*?)\\\"?$").find(header)?.let { title = it.groupValues[1].replace("\\\"", "\"") }
                Regex("(?m)^note_id:\\s*(\\d+)").find(header)?.let { id = it.groupValues[1].toLongOrNull() ?: 0L }
                Regex("(?m)^created_at:\\s*(\\d+)").find(header)?.let { created = it.groupValues[1].toLongOrNull() ?: created }
                Regex("(?m)^updated_at:\\s*(\\d+)").find(header)?.let { updated = it.groupValues[1].toLongOrNull() ?: updated }
                body = raw.substring(end + 4).trimStart('\n')
            }
        }
        return Note(id = id, title = title, markdown = body, createdAt = created, updatedAt = updated)
    }
}

@Composable
private fun MarkdownTool(
    label: String,
    prefix: String,
    suffix: String,
    body: TextFieldValue,
    beforeChange: () -> Unit,
    onChange: (TextFieldValue) -> Unit
) {
    TextButton(onClick = {
        val start = body.selection.min
        val end = body.selection.max
        val selected = body.text.substring(start, end)
        val replacement = prefix + selected + suffix
        val text = body.text.replaceRange(start, end, replacement)
        val selection = if (selected.isEmpty()) TextRange(start + prefix.length) else TextRange(start + replacement.length)
        beforeChange()
        onChange(TextFieldValue(text, selection))
    }, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp)) {
        Text(label, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

@Composable
fun NotesScreen(db: MomentumDatabase, modifier: Modifier, onEdit: (Long) -> Unit) {
    val notes by db.notes().observeAll().collectAsState(emptyList())
    var query by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val filtered = notes.filter { it.title.contains(query, true) || it.markdown.contains(query, true) }
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Notes", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Text("Thoughts, quotes and reading annotations", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalButton(onClick = {
                    scope.launch {
                        val now = System.currentTimeMillis()
                        val id = db.notes().upsert(Note(title = "", markdown = "", createdAt = now, updatedAt = now))
                        onEdit(id)
                    }
                }, shape = RoundedCornerShape(18.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("New note") }
            }
        }
        item {
            OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search notes") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(18.dp))
        }
        if (filtered.isEmpty()) item {
            Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f)) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (query.isBlank()) "A place for your thoughts" else "No matching notes", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Text(if (query.isBlank()) "Save an idea, a website annotation, or a passage from an ebook." else "Try another search term.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
            }
        }
        items(filtered, key = { it.id }) { note ->
            Surface(modifier = Modifier.fillMaxWidth().clickable { onEdit(note.id) }, shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f), tonalElevation = 0.dp, shadowElevation = 1.dp) {
                Column(Modifier.padding(16.dp)) {
                    Text(note.title.ifBlank { "Untitled note" }, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text(note.markdown.lineSequence().filter { it.isNotBlank() && !it.startsWith("---") && !it.startsWith("title:") && !it.startsWith("note_id:") }.joinToString(" ").take(160).ifBlank { "No text yet" }, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, maxLines = 3)
                    Spacer(Modifier.height(8.dp))
                    Text(java.text.SimpleDateFormat("dd MMM yyyy · h:mm a", Locale.getDefault()).format(Date(note.updatedAt)), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun NoteEditorScreen(db: MomentumDatabase, noteId: Long, modifier: Modifier, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var note by remember(noteId) { mutableStateOf<Note?>(null) }
    var title by remember(noteId) { mutableStateOf("") }
    var body by remember(noteId) { mutableStateOf(TextFieldValue("")) }
    var undoStack by remember(noteId) { mutableStateOf(listOf<TextFieldValue>()) }
    var redoStack by remember(noteId) { mutableStateOf(listOf<TextFieldValue>()) }
    var initialized by remember(noteId) { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    val context = LocalContext.current
    LaunchedEffect(noteId) {
        val found = withContext(Dispatchers.IO) { db.notes().get(noteId) }
        if (found != null) {
            note = found; title = found.title; body = TextFieldValue(found.markdown)
        }
        initialized = true
    }
    LaunchedEffect(title, body.text, initialized) {
        if (!initialized) return@LaunchedEffect
        delay(550)
        val original = note ?: return@LaunchedEffect
        val updated = original.copy(title = title, markdown = body.text, updatedAt = System.currentTimeMillis())
        withContext(Dispatchers.IO) { db.notes().upsert(updated) }
        note = updated
    }
    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { scope.launch { note?.let { db.notes().upsert(it.copy(title = title, markdown = body.text, updatedAt = System.currentTimeMillis())) }; onBack() } }) { Icon(Icons.Default.ArrowBack, "Back") }
            BasicTextField(value = title, onValueChange = { title = it }, modifier = Modifier.weight(1f), singleLine = true, textStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground), decorationBox = { inner -> if (title.isBlank()) Text("Title", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 22.sp); inner() })
            IconButton(onClick = { scope.launch { note?.let { db.notes().upsert(it.copy(title = title, markdown = body.text, updatedAt = System.currentTimeMillis())) }; onBack() } }) { Icon(Icons.Default.Check, "Done") }
            IconButton(onClick = { showDelete = true }) { Icon(Icons.Default.DeleteOutline, "Delete note") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface.copy(alpha = 0.68f)).padding(horizontal = 4.dp, vertical = 4.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { if (undoStack.isNotEmpty()) { redoStack = (redoStack + body).takeLast(60); body = undoStack.last(); undoStack = undoStack.dropLast(1) } }, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp)) { Text("↶", fontSize = 20.sp) }
            TextButton(onClick = { if (redoStack.isNotEmpty()) { undoStack = (undoStack + body).takeLast(60); body = redoStack.last(); redoStack = redoStack.dropLast(1) } }, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp)) { Text("↷", fontSize = 20.sp) }
            val beforeToolbarChange: () -> Unit = { undoStack = (undoStack + body).takeLast(60); redoStack = emptyList() }
            val updateBody: (TextFieldValue) -> Unit = { body = it }
            MarkdownTool("B", "**", "**", body, beforeToolbarChange, updateBody)
            MarkdownTool("I", "*", "*", body, beforeToolbarChange, updateBody)
            MarkdownTool("U", "<u>", "</u>", body, beforeToolbarChange, updateBody)
            MarkdownTool("S̶", "~~", "~~", body, beforeToolbarChange, updateBody)
            MarkdownTool("1.", "1. ", "", body, beforeToolbarChange, updateBody)
            MarkdownTool("•", "- ", "", body, beforeToolbarChange, updateBody)
            MarkdownTool("☑", "- [ ] ", "", body, beforeToolbarChange, updateBody)
            MarkdownTool("❝", "> ", "", body, beforeToolbarChange, updateBody)
            MarkdownTool("🔗", "[", "](https://)", body, beforeToolbarChange, updateBody)
        }
        BasicTextField(value = body, onValueChange = { undoStack = (undoStack + body).takeLast(60); redoStack = emptyList(); body = it }, modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp), textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onBackground, lineHeight = 27.sp), decorationBox = { inner ->
            Box(Modifier.fillMaxSize()) {
                if (body.text.isEmpty()) Text("Write a thought, paste a quote, or annotate something you read…\n\nMarkdown formatting is supported for portable exports.", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), fontSize = 16.sp, lineHeight = 26.sp)
                inner()
            }
        })
    }
    if (showDelete) AlertDialog(onDismissRequest = { showDelete = false }, title = { Text("Delete this note?") }, text = { Text("This note will be removed from Reflection. A previously exported Markdown backup is not affected.") }, confirmButton = { TextButton(onClick = { scope.launch { db.notes().delete(noteId); showDelete = false; onBack() } }) { Text("Delete") } }, dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } })
}
