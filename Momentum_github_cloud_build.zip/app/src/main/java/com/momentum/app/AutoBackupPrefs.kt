package com.momentum.app

import android.content.Context

object AutoBackupPrefs {
    private const val PREFS = "momentum_auto_backup"
    private const val KEY_FREQUENCY = "frequency"
    private const val KEY_TREE_URI = "tree_uri"
    private const val KEY_LAST = "last_backup"
    private const val KEY_ERROR = "last_error"

    const val OFF = "Off"
    const val DAILY = "Daily"
    const val WEEKLY = "Weekly"
    const val MONTHLY = "Monthly"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun frequency(context: Context): String = prefs(context).getString(KEY_FREQUENCY, OFF) ?: OFF
    fun setFrequency(context: Context, value: String) = prefs(context).edit().putString(KEY_FREQUENCY, value).apply()
    fun treeUri(context: Context): String? = prefs(context).getString(KEY_TREE_URI, null)
    fun setTreeUri(context: Context, uri: String) = prefs(context).edit().putString(KEY_TREE_URI, uri).apply()
    fun clearTreeUri(context: Context) = prefs(context).edit().remove(KEY_TREE_URI).apply()
    fun lastBackup(context: Context): String? = prefs(context).getString(KEY_LAST, null)
    fun setLastBackup(context: Context, value: String) = prefs(context).edit().putString(KEY_LAST, value).apply()
    fun lastError(context: Context): String? = prefs(context).getString(KEY_ERROR, null)
    fun setLastError(context: Context, value: String) = prefs(context).edit().putString(KEY_ERROR, value).apply()
    fun clearLastError(context: Context) = prefs(context).edit().remove(KEY_ERROR).apply()
}
