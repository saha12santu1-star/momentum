package com.momentum.app

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object AutoBackupScheduler {
    private const val WORK_NAME = "momentum_auto_backup"
    private const val NOW_WORK_NAME = "momentum_auto_backup_now"

    fun schedule(context: Context) {
        cancel(context)
        val frequency = AutoBackupPrefs.frequency(context)
        if (frequency == AutoBackupPrefs.OFF || AutoBackupPrefs.treeUri(context) == null) return

        WorkManager.getInstance(context).enqueueUniqueWork(
            NOW_WORK_NAME, ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<AutoBackupWorker>().build()
        )

        val days = when (frequency) {
            AutoBackupPrefs.DAILY -> 1L
            AutoBackupPrefs.WEEKLY -> 7L
            AutoBackupPrefs.MONTHLY -> 30L
            else -> return
        }
        val request = PeriodicWorkRequestBuilder<AutoBackupWorker>(days, TimeUnit.DAYS)
            .setInitialDelay(days, TimeUnit.DAYS)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    fun backupNow(context: Context) {
        if (AutoBackupPrefs.treeUri(context) == null) return
        WorkManager.getInstance(context).enqueueUniqueWork(
            NOW_WORK_NAME, ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<AutoBackupWorker>().build()
        )
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        WorkManager.getInstance(context).cancelUniqueWork(NOW_WORK_NAME)
    }
}
