package com.momentum.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.common.api.ApiException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object CloudSync {
    private const val SCOPE = "https://www.googleapis.com/auth/drive.appdata"
    private const val FILE_NAME = "reflection-sync.json"
    private const val JSON_MIME = "application/json"
    private const val BASE = "https://www.googleapis.com/drive/v3/files"
    private const val UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"
    const val AUTH_REQUEST_CODE = 9417
    private const val HISTORY_PREFIX = "reflection-history-"
    private const val MAX_HISTORY = 10

    data class CloudBackupInfo(
        val id: String,
        val name: String,
        val modifiedTime: String,
        val sizeBytes: Long,
        val isCurrent: Boolean
    )

    fun requestAuthorization(
        activity: Activity,
        onToken: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val request = AuthorizationRequest.builder()
            .setRequestedScopes(listOf(Scope(SCOPE)))
            .build()
        Identity.getAuthorizationClient(activity).authorize(request)
            .addOnSuccessListener { result ->
                if (result.hasResolution()) {
                    val pending = result.pendingIntent
                    if (pending == null) onError("Google authorization needs to be completed again.")
                    else {
                        try {
                            @Suppress("DEPRECATION")
                            activity.startIntentSenderForResult(
                                pending.intentSender,
                                AUTH_REQUEST_CODE,
                                null, 0, 0, 0, null
                            )
                        } catch (e: android.content.IntentSender.SendIntentException) {
                            onError("Could not open Google authorization: ${e.message ?: e.javaClass.simpleName}")
                        }
                    }
                } else {
                    val token = result.accessToken
                    if (token.isNullOrBlank()) onError("Google did not return a Drive access token.")
                    else onToken(token)
                }
            }
            .addOnFailureListener { e -> onError(e.message ?: "Google authorization failed.") }
    }

    fun tokenFromResult(activity: Activity, data: Intent?): String? {
        if (data == null) return null
        return Identity.getAuthorizationClient(activity).getAuthorizationResultFromIntent(data).accessToken
    }

    fun resultError(activity: Activity, data: Intent?, resultCode: Int): String {
        val resultName = when (resultCode) {
            Activity.RESULT_OK -> "RESULT_OK ($resultCode)"
            Activity.RESULT_CANCELED -> "RESULT_CANCELED ($resultCode)"
            else -> "resultCode=$resultCode"
        }

        if (data == null) {
            return "Google authorization diagnostic: $resultName; data=null.\n" +
                "Google returned no Intent after the account-selection flow."
        }

        val keys = runCatching {
            data.extras?.keySet()?.sorted()?.joinToString(", ") ?: "none"
        }.getOrDefault("unavailable")

        return try {
            val result = Identity.getAuthorizationClient(activity).getAuthorizationResultFromIntent(data)
            val scopes = result.grantedScopes.joinToString(", ").ifBlank { "none" }
            val tokenState = if (result.accessToken.isNullOrBlank()) "no access token" else "access token present"
            "Google authorization diagnostic: $resultName; data present; $tokenState; " +
                "resolution=${result.hasResolution()}; scopes=$scopes; extras=[$keys]"
        } catch (e: Exception) {
            val cause = e.cause
            val detail = when (e) {
                is ApiException -> "status ${e.statusCode}${e.status.statusMessage?.let { ": $it" } ?: ""}"
                else -> e.message ?: cause?.message ?: e.javaClass.simpleName
            }
            "Google authorization diagnostic: $resultName; data present; " +
                "extras=[$keys]; error=$detail"
        }
    }

    suspend fun listCloudBackups(context: Context): List<CloudBackupInfo> = withContext(Dispatchers.IO) {
        val token = authorizeSilently(context)
            ?: throw IllegalStateException("Google Drive is not connected. Connect Google Drive first.")
        listBackups(token)
    }

    suspend fun deleteCloudBackup(context: Context, backupId: String): String = withContext(Dispatchers.IO) {
        val token = authorizeSilently(context)
            ?: throw IllegalStateException("Google Drive is not connected. Connect Google Drive first.")
        val backup = listBackups(token).firstOrNull { it.id == backupId }
            ?: throw IllegalStateException("This backup no longer exists in Google Drive.")
        if (backup.isCurrent || backup.name == FILE_NAME) {
            throw IllegalArgumentException("The current backup is protected. Delete only previous backups.")
        }
        if (!backup.name.startsWith(HISTORY_PREFIX)) {
            throw IllegalArgumentException("This file is not a Reflection history backup.")
        }
        val response = request("DELETE", URL("$BASE/${backup.id}"), token, null, null)
        if (response.code !in 200..299) {
            throw IllegalStateException("Could not delete this backup (${response.code}).")
        }
        "Deleted the selected previous backup from Google Drive."
    }

    suspend fun deleteAllPreviousCloudBackups(context: Context): String = withContext(Dispatchers.IO) {
        val token = authorizeSilently(context)
            ?: throw IllegalStateException("Google Drive is not connected. Connect Google Drive first.")
        val previous = listBackups(token).filter { !it.isCurrent && it.name.startsWith(HISTORY_PREFIX) }
        var deleted = 0
        val failures = mutableListOf<String>()
        for (backup in previous) {
            val response = request("DELETE", URL("$BASE/${backup.id}"), token, null, null)
            if (response.code in 200..299 || response.code == 404) deleted++
            else failures += "${backup.name} (${response.code})"
        }
        if (failures.isNotEmpty()) {
            throw IllegalStateException("Deleted $deleted previous backup(s), but could not delete ${failures.size}: ${failures.take(3).joinToString()}")
        }
        "Deleted $deleted previous backup(s). The current Google Drive backup was kept."
    }

    suspend fun restoreFromCloudBackup(context: Context, db: MomentumDatabase, backupId: String): String = withContext(Dispatchers.IO) {
        val token = authorizeSilently(context)
            ?: throw IllegalStateException("Google Drive is not connected. Connect Google Drive first.")
        val content = downloadFile(token, backupId)
        val restored = JsonRestore.restore(context, db, content)
        val hash = contentHash(content)
        finish(context, hash)
        "Restored $restored records from the selected Google Drive backup."
    }

    suspend fun restoreFromCloud(context: Context, db: MomentumDatabase): String = withContext(Dispatchers.IO) {
        val token = authorizeSilently(context)
            ?: throw IllegalStateException("Google Drive is not connected. Connect Google Drive first.")
        val remote = getRemote(token)
            ?: throw IllegalStateException("No Reflection backup was found in Google Drive.")
        val restored = JsonRestore.restore(context, db, remote.second)
        val hash = contentHash(remote.second)
        finish(context, hash)
        "Restored $restored records from Google Drive."
    }

    data class InitialConnectionInfo(
        val localHasUserData: Boolean,
        val remoteHasUserData: Boolean,
        val remoteExists: Boolean,
        val remoteModifiedTime: String?,
        val remoteSizeBytes: Long
    )

    suspend fun inspectInitialConnection(context: Context, db: MomentumDatabase, token: String): InitialConnectionInfo = withContext(Dispatchers.IO) {
        val local = JsonBackup.create(context, db)
        val remote = getRemote(token)
        val remoteJson = remote?.second
        val current = listBackups(token).firstOrNull { it.isCurrent }
        InitialConnectionInfo(
            localHasUserData = hasUserData(local),
            remoteHasUserData = remoteJson?.let(::hasUserData) == true,
            remoteExists = remoteJson != null,
            remoteModifiedTime = current?.modifiedTime,
            remoteSizeBytes = current?.sizeBytes ?: 0L
        )
    }

    suspend fun acceptInitialCloud(context: Context, db: MomentumDatabase, token: String): String = withContext(Dispatchers.IO) {
        val remote = getRemote(token) ?: throw IllegalStateException("No Reflection backup was found in Google Drive.")
        val restored = JsonRestore.restore(context, db, remote.second)
        finish(context, contentHash(remote.second))
        "Downloaded your Reflection data from Google Drive."
    }

    suspend fun uploadInitialLocal(context: Context, db: MomentumDatabase, token: String): String = withContext(Dispatchers.IO) {
        val local = JsonBackup.create(context, db)
        val remote = getRemote(token)
        if (remote != null) snapshotCurrent(token, remote.second)
        upload(token, local, remote?.first)
        finish(context, contentHash(local))
        "Uploaded this device's Reflection data to Google Drive."
    }

    suspend fun finishInitialConnection(context: Context, db: MomentumDatabase, token: String): String = withContext(Dispatchers.IO) {
        val local = JsonBackup.create(context, db)
        finish(context, contentHash(local))
        "Google Drive connected. Both copies are already synchronized."
    }

    suspend fun sync(context: Context, db: MomentumDatabase): String = withContext(Dispatchers.IO) {
        val token = authorizeSilently(context) ?: throw IllegalStateException("Google Drive is not connected. Open Settings → Cloud sync and connect it first.")
        val local = JsonBackup.create(context, db)
        val localHash = contentHash(local)
        val remote = getRemote(token)
        val remoteJson = remote?.second
        val remoteHash = remoteJson?.let(::contentHash)
        val previousHash = CloudSyncPrefs.lastHash(context)

        val localHasUserData = hasUserData(local)
        val remoteHasUserData = remoteJson?.let(::hasUserData) == true

        when {
            // A newly installed/empty device must NEVER overwrite an existing cloud backup.
            // The cloud copy is the source of truth when this device has no user data yet.
            remoteJson != null && !localHasUserData && remoteHasUserData -> {
                JsonRestore.restore(context, db, remoteJson)
                finish(context, remoteHash!!)
                "Downloaded your Reflection data from Google Drive."
            }
            remoteJson == null -> {
                upload(token, local, null)
                finish(context, localHash)
                "Uploaded local data to Google Drive."
            }
            remoteJson != null && localHasUserData && !remoteHasUserData -> {
                snapshotCurrent(token, remoteJson)
                upload(token, local, remote.first)
                finish(context, localHash)
                "Uploaded your local data to Google Drive."
            }
            previousHash != null && localHash == previousHash && remoteHash != previousHash -> {
                JsonRestore.restore(context, db, remoteJson)
                finish(context, remoteHash!!)
                "Downloaded newer data from Google Drive."
            }
            remoteHash == localHash -> {
                finish(context, localHash)
                "Already synchronized."
            }
            previousHash != null && remoteHash == previousHash && localHash != previousHash -> {
                snapshotCurrent(token, remoteJson)
                upload(token, local, remote.first)
                finish(context, localHash)
                "Uploaded your newer local data to Google Drive."
            }
            else -> {
                // Both sides contain data, but this device has never synchronized with this
                // cloud copy (or both sides changed independently). Never silently overwrite
                // either side. The user can choose Restore from Google Drive or keep this
                // device's data and use Sync now again after making an explicit decision.
                throw IllegalStateException(
                    "Cloud data and this device both contain different Reflection data. " +
                        "Choose Restore from Google Drive to use the cloud copy, or back up this device before replacing the cloud copy."
                )
            }
        }
    }

    private fun hasUserData(json: String): Boolean {
        val counts = JSONObject(json).optJSONObject("counts") ?: return false
        val keys = listOf(
            "habits", "logs", "readingLogs", "activityLogs", "focusSessions",
            "timeline", "challenges", "achievements", "notes", "readerDocuments"
        )
        return keys.any { counts.optInt(it, 0) > 0 }
    }

    private suspend fun authorizeSilently(context: Context): String? {
        if (!CloudSyncPrefs.connected(context)) return null
        val request = AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(SCOPE))).build()
        return runCatching {
            val result = Identity.getAuthorizationClient(context).authorize(request).await()
            if (result.hasResolution()) null else result.accessToken
        }.getOrNull()
    }

    private fun finish(context: Context, hash: String) {
        CloudSyncPrefs.setConnected(context, true)
        CloudSyncPrefs.setLastHash(context, hash)
        CloudSyncPrefs.setLastSync(context, LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, h:mm a")))
        CloudSyncPrefs.setLastError(context, null)
    }

    private fun contentHash(json: String): String {
        val root = JSONObject(json)
        root.remove("createdAt")
        val bytes = root.toString().toByteArray(Charsets.UTF_8)
        return MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    }

    private fun getRemote(token: String): Pair<String, String>? {
        val q = URLEncoder.encode("name='$FILE_NAME'", "UTF-8")
        val url = URL("$BASE?spaces=appDataFolder&q=$q&fields=files(id,name,modifiedTime,size)&pageSize=1")
        val response = request("GET", url, token, null, null)
        if (response.code !in 200..299) throw IllegalStateException("Google Drive lookup failed (${response.code}).")
        val files = JSONObject(response.body).optJSONArray("files")
        if (files == null || files.length() == 0) return null
        val id = files.getJSONObject(0).getString("id")
        val content = downloadFile(token, id)
        return id to content
    }

    private fun listBackups(token: String): List<CloudBackupInfo> {
        val query = "name='$FILE_NAME' or name contains '$HISTORY_PREFIX'"
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = URL("$BASE?spaces=appDataFolder&q=$encoded&fields=files(id,name,modifiedTime,size)&orderBy=modifiedTime%20desc&pageSize=50")
        val response = request("GET", url, token, null, null)
        if (response.code !in 200..299) throw IllegalStateException("Google Drive backup history lookup failed (${response.code}).")
        val files = JSONObject(response.body).optJSONArray("files") ?: return emptyList()
        return buildList {
            for (i in 0 until files.length()) {
                val file = files.getJSONObject(i)
                add(CloudBackupInfo(
                    id = file.getString("id"),
                    name = file.getString("name"),
                    modifiedTime = file.optString("modifiedTime", ""),
                    sizeBytes = file.optString("size", "0").toLongOrNull() ?: 0L,
                    isCurrent = file.getString("name") == FILE_NAME
                ))
            }
        }
    }

    private fun downloadFile(token: String, fileId: String): String {
        val contentUrl = URL("$BASE/$fileId?alt=media")
        val content = request("GET", contentUrl, token, null, null)
        if (content.code !in 200..299) throw IllegalStateException("Google Drive download failed (${content.code}).")
        return content.body
    }

    private fun snapshotCurrent(token: String, currentJson: String) {
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"))
        uploadNew(token, "$HISTORY_PREFIX$stamp.json", currentJson)
        pruneHistory(token)
    }

    private fun pruneHistory(token: String) {
        val backups = listBackups(token).filter { !it.isCurrent }
        backups.drop(MAX_HISTORY).forEach { backup ->
            val response = request("DELETE", URL("$BASE/${backup.id}"), token, null, null)
            if (response.code !in 200..299) return@forEach
        }
    }

    private fun upload(token: String, json: String, fileId: String?) {
        if (fileId == null) {
            uploadNew(token, FILE_NAME, json)
            return
        }
        val bytes = json.toByteArray(Charsets.UTF_8)
        val metadata = "{\"mimeType\":\"$JSON_MIME\"}"
        val session = initiateResumableUpload(token, URL("$UPLOAD/$fileId?uploadType=resumable"), "PATCH", metadata, bytes.size.toLong())
        completeResumableUpload(token, session, bytes)
    }

    private fun uploadNew(token: String, name: String, json: String) {
        val bytes = json.toByteArray(Charsets.UTF_8)
        val metadata = "{\"name\":\"$name\",\"parents\":[\"appDataFolder\"],\"mimeType\":\"$JSON_MIME\"}"
        val session = initiateResumableUpload(token, URL("$UPLOAD?uploadType=resumable&fields=id"), "POST", metadata, bytes.size.toLong())
        completeResumableUpload(token, session, bytes)
    }

    private fun initiateResumableUpload(token: String, url: URL, method: String, metadata: String, totalBytes: Long): URL {
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 30_000
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("X-Upload-Content-Type", JSON_MIME)
            setRequestProperty("X-Upload-Content-Length", totalBytes.toString())
            doOutput = true
        }
        connection.outputStream.use { it.write(metadata.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val location = connection.getHeaderField("Location")
        val errorText = (if (code in 200..299) connection.inputStream else connection.errorStream)
            ?.let { stream -> stream.use { it.readBytes().toString(Charsets.UTF_8) } }.orEmpty()
        connection.disconnect()
        if (code !in 200..299 || location.isNullOrBlank()) {
            throw IllegalStateException("Could not start Google Drive upload ($code): ${errorText.take(300)}")
        }
        return URL(location)
    }

    private fun completeResumableUpload(token: String, sessionUrl: URL, bytes: ByteArray) {
        val connection = (sessionUrl.openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"
            connectTimeout = 30_000
            readTimeout = 300_000
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Content-Type", JSON_MIME)
            setFixedLengthStreamingMode(bytes.size.toLong())
            doOutput = true
        }
        connection.outputStream.use { it.write(bytes) }
        val code = connection.responseCode
        val detail = (if (code in 200..299) connection.inputStream else connection.errorStream)
            ?.let { stream -> stream.use { it.readBytes().toString(Charsets.UTF_8) } }.orEmpty()
        connection.disconnect()
        if (code !in 200..299) throw IllegalStateException("Google Drive upload failed ($code): ${detail.take(300)}")
    }

    private data class Response(val code: Int, val body: String)

    private fun request(method: String, url: URL, token: String, contentType: String?, body: ByteArray?): Response {
        val c = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 300_000
            setRequestProperty("Authorization", "Bearer $token")
            if (contentType != null) setRequestProperty("Content-Type", contentType)
            if (body != null) doOutput = true
        }
        if (body != null) c.outputStream.use { it.write(body) }
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val text = stream?.let { BufferedReader(InputStreamReader(it)).use { r -> r.readText() } } ?: ""
        val code = c.responseCode
        c.disconnect()
        return Response(code, text)
    }
}
