package com.momentum.app

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject

object JsonRestore {
    suspend fun restore(context: Context, db: MomentumDatabase, json: String): Int {
        val root = JSONObject(json)
        require(root.optString("format") == "momentum-json") { "Not a Momentum backup" }

        val habits = mutableListOf<Habit>()
        val logs = mutableListOf<HabitLog>()
        val habitActions = mutableListOf<HabitAction>()
        val habitActionLogs = mutableListOf<HabitActionLog>()
        val readingGoals = mutableListOf<ReadingGoal>()
        val readingLogs = mutableListOf<ReadingLog>()
        val activityLogs = mutableListOf<ActivityProgress>()
        val focusSessions = mutableListOf<FocusSession>()
        val timeline = mutableListOf<TimelineEvent>()
        val challenges = mutableListOf<ChallengeProgress>()
        val achievements = mutableListOf<Achievement>()
        val appSettings = mutableListOf<AppSetting>()
        val templates = mutableListOf<HabitTemplate>()
        val notes = mutableListOf<Note>()
        val noteFolders = mutableListOf<NoteFolder>()
        val readerDocuments = mutableListOf<ReaderDocument>()
        val hasReaderDocuments = root.has("readerDocuments")
        val hasNotes = root.has("notes")

        val ja = root.optJSONArray("habits") ?: JSONArray()
        for (i in 0 until ja.length()) {
            val o = ja.getJSONObject(i)
            habits += Habit(
                id=o.optLong("id",0), name=o.optString("name"), description=o.optString("description"),
                category=o.optString("category","General"), frequency=o.optString("frequency","Daily"),
                reminderMinutes=if(o.has("reminderMinutes") && !o.isNull("reminderMinutes")) o.optInt("reminderMinutes") else null,
                difficulty=o.optString("difficulty","Easy"), startDate=o.optString("startDate"),
                archived=o.optBoolean("archived",false), iconKey=o.optString("iconKey","book"),
                progressType=o.optString("progressType","standard"),
                goalDays=if(o.has("goalDays") && !o.isNull("goalDays")) o.optInt("goalDays") else null
            )
        }
        val jl=root.optJSONArray("logs") ?: JSONArray()
        for(i in 0 until jl.length()){ val o=jl.getJSONObject(i); logs += HabitLog(o.optLong("habitId"),o.optString("date"),o.optBoolean("completed",true)) }
        val jaa=root.optJSONArray("habitActions") ?: JSONArray()
        for(i in 0 until jaa.length()) { val o=jaa.getJSONObject(i); habitActions += HabitAction(
            id=o.optLong("id",0), habitId=o.optLong("habitId"), name=o.optString("name"),
            trackingType=o.optString("trackingType","boolean"), unit=o.optString("unit",""),
            target=if(o.has("target") && !o.isNull("target")) o.optDouble("target") else null,
            iconKey=o.optString("iconKey",""), sortOrder=o.optInt("sortOrder",0),
            required=o.optBoolean("required",true), archived=o.optBoolean("archived",false)) }
        val jaal=root.optJSONArray("habitActionLogs") ?: JSONArray()
        for(i in 0 until jaal.length()) { val o=jaal.getJSONObject(i); habitActionLogs += HabitActionLog(
            actionId=o.optLong("actionId"), date=o.optString("date"), completed=o.optBoolean("completed",false),
            amount=if(o.has("amount") && !o.isNull("amount")) o.optDouble("amount") else null) }
        val rg=root.optJSONArray("readingGoals") ?: JSONArray()
        for(i in 0 until rg.length()){ val o=rg.getJSONObject(i); readingGoals += ReadingGoal(o.optLong("habitId"),o.optInt("totalPages")) }
        val rl=root.optJSONArray("readingLogs") ?: JSONArray()
        for(i in 0 until rl.length()){ val o=rl.getJSONObject(i); readingLogs += ReadingLog(o.optLong("habitId"),o.optString("date"),o.optInt("pagesRead")) }
        val al=root.optJSONArray("activityLogs") ?: JSONArray()
        for(i in 0 until al.length()){ val o=al.getJSONObject(i); activityLogs += ActivityProgress(o.optLong("habitId"),o.optString("date"),o.optInt("amount")) }
        val fs=root.optJSONArray("focusSessions") ?: JSONArray()
        for(i in 0 until fs.length()){ val o=fs.getJSONObject(i); focusSessions += FocusSession(o.optLong("id",0), if(o.has("habitId") && !o.isNull("habitId")) o.optLong("habitId") else null, o.optString("date"), o.optInt("minutes"), o.optBoolean("completed",true)) }
        val te=root.optJSONArray("timeline") ?: JSONArray()
        for(i in 0 until te.length()){ val o=te.getJSONObject(i); timeline += TimelineEvent(o.optLong("id"),o.optString("date"),o.optString("title"),o.optString("detail")) }
        val ch=root.optJSONArray("challenges") ?: JSONArray()
        for(i in 0 until ch.length()){ val o=ch.getJSONObject(i); challenges += ChallengeProgress(o.optString("challengeId"),o.optInt("progress"),o.optInt("target")) }
        val ac=root.optJSONArray("achievements") ?: JSONArray()
        for(i in 0 until ac.length()){ val o=ac.getJSONObject(i); achievements += Achievement(o.optString("id"),o.optString("title"),o.optBoolean("unlocked",false),if(o.has("unlockedDate")&&!o.isNull("unlockedDate")) o.optString("unlockedDate") else null) }
        val aps=root.optJSONArray("appSettings") ?: JSONArray()
        for(i in 0 until aps.length()){ val o=aps.getJSONObject(i); appSettings += AppSetting(o.optString("key"),o.optString("value")) }
        val ht=root.optJSONArray("habitTemplates") ?: JSONArray()
        for(i in 0 until ht.length()){ val o=ht.getJSONObject(i); templates += HabitTemplate(o.optString("id"),o.optString("name"),o.optString("description"),o.optString("category"),o.optString("frequency"),o.optString("difficulty")) }
        val ns=root.optJSONArray("notes") ?: JSONArray()
        for(i in 0 until ns.length()){ val o=ns.getJSONObject(i); notes += Note(o.optLong("id",0),o.optString("title"),o.optString("markdown"),o.optLong("createdAt",System.currentTimeMillis()),o.optLong("updatedAt",System.currentTimeMillis()),o.optString("folder", "")) }
        val nfs=root.optJSONArray("noteFolders") ?: JSONArray()
        for(i in 0 until nfs.length()){ val o=nfs.getJSONObject(i); noteFolders += NoteFolder(o.optString("name"), o.optLong("createdAt", System.currentTimeMillis())) }
        val rd=root.optJSONArray("readerDocuments") ?: JSONArray()
        for(i in 0 until rd.length()) { val o=rd.getJSONObject(i); val encoded=o.optString("contentBase64", ""); if (encoded.isNotBlank()) readerDocuments += ReaderDocument(o.optLong("id", 0), o.optString("fileName", "Imported document"), o.optString("mimeType", "application/octet-stream"), android.util.Base64.decode(encoded, android.util.Base64.DEFAULT), o.optLong("addedAt", System.currentTimeMillis()), o.optInt("lastPosition", 0)) }

        try {
            db.withTransaction {
                // Clear and recreate all Room tables atomically.
                // Use DAO DELETE statements rather than Room clearAllTables(), which
                // performs a WAL checkpoint/VACUUM and must not run inside this transaction.
                db.dao().clearLogs()
                db.dao().clearHabits()
                db.actions().clearLogs()
                db.actions().clearActions()
                db.reading().clearGoals()
                db.reading().clearAllLogs()
                db.activity().clearAll()
                db.focus().clearAll()
                db.extended().clearTimeline()
                db.extended().clearChallenges()
                db.extended().clearAchievements()
                db.settings().clearAppSettings()
                db.settings().clearTemplates()
                if (hasNotes) { db.notes().clearAll(); db.notes().clearFolders() }
                if (hasReaderDocuments) db.notes().clearDocuments()

                if(habits.isNotEmpty()) db.dao().insertAll(habits)
                if(logs.isNotEmpty()) db.dao().logAll(logs)
                if(habitActions.isNotEmpty()) db.actions().saveActions(habitActions)
                if(habitActionLogs.isNotEmpty()) habitActionLogs.forEach { db.actions().saveLog(it) }
                readingGoals.forEach { db.reading().upsertGoal(it) }
                readingLogs.forEach { db.reading().upsertLog(it) }
                activityLogs.forEach { db.activity().upsert(it) }
                focusSessions.forEach { db.focus().add(it) }
                if(timeline.isNotEmpty()) db.extended().addEvents(timeline)
                if(challenges.isNotEmpty()) db.extended().saveChallenges(challenges)
                if(achievements.isNotEmpty()) db.extended().saveAchievements(achievements)
                if(appSettings.isNotEmpty()) db.settings().setAll(appSettings)
                if(templates.isNotEmpty()) db.settings().templatesAll(templates)
                if(hasNotes && notes.isNotEmpty()) db.notes().upsertAll(notes)
                if(hasNotes && noteFolders.isNotEmpty()) db.notes().upsertFolders(noteFolders)
                if(hasReaderDocuments && readerDocuments.isNotEmpty()) db.notes().upsertDocuments(readerDocuments)
            }
        } catch (t: Throwable) {
            val detail = t.message ?: t.cause?.message ?: t.javaClass.simpleName
            throw IllegalStateException("Database restore failed: $detail", t)
        }

        val settings=root.optJSONObject("settings")
        if(settings!=null){
            ThemePrefs.set(context,settings.optString("theme",ThemePrefs.get(context)))
            AutoLockPrefs.setMinutes(context,settings.optInt("autoLockMinutes",AutoLockPrefs.getMinutes(context)))
            val start=if(settings.has("vacationStart")&&!settings.isNull("vacationStart")) settings.optString("vacationStart") else null
            val end=if(settings.has("vacationEnd")&&!settings.isNull("vacationEnd")) settings.optString("vacationEnd") else null
            VacationPrefs.setRange(context,start,end); VacationPrefs.refresh(context)
            // Storage folder permissions belong to this Android installation and are
            // therefore never imported from a backup. Keep the user's current folder.
            val freq=settings.optString("autoBackupFrequency",AutoBackupPrefs.OFF)
            val currentUri=AutoBackupPrefs.treeUri(context)
            val currentTree=currentUri?.let { runCatching { DocumentFile.fromTreeUri(context, android.net.Uri.parse(it)) }.getOrNull() }
            if(currentTree?.canWrite()==true) AutoBackupPrefs.setFrequency(context, freq)
            else AutoBackupPrefs.setFrequency(context, AutoBackupPrefs.OFF)
            settings.optString("autoBackupLast","").takeIf{it.isNotBlank()}?.let{AutoBackupPrefs.setLastBackup(context,it)}
            AutoBackupPrefs.clearLastError(context)
            runCatching { AutoBackupScheduler.schedule(context) }
        }
        // Restoring data must not be reported as a failure merely because an Android
        // reminder/WorkManager reschedule is unavailable on this installation.
        runCatching { ReminderScheduler.rescheduleAll(context) }
        return habits.size+logs.size+habitActions.size+habitActionLogs.size+readingGoals.size+readingLogs.size+activityLogs.size+focusSessions.size+timeline.size+challenges.size+achievements.size+appSettings.size+templates.size+notes.size
    }
}
