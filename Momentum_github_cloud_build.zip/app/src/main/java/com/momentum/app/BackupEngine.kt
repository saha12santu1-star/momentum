package com.momentum.app

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.withContext
import java.nio.charset.StandardCharsets
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object BackupEngine {
    private val stampFormat = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")

    suspend fun writeToTree(context: Context, db: MomentumDatabase): String = withContext(kotlinx.coroutines.Dispatchers.IO) {
        var created: DocumentFile? = null
        try {
            val uriString = AutoBackupPrefs.treeUri(context) ?: error("No backup folder selected. Choose a backup folder first.")
            val tree = DocumentFile.fromTreeUri(context, android.net.Uri.parse(uriString))
                ?: error("Backup folder is no longer available. Select it again in Settings.")
            if (!tree.canWrite()) error("The selected backup folder is not writable. Choose another folder.")

            val json = JsonBackup.create(context, db)
            val bytes = json.toByteArray(StandardCharsets.UTF_8)
            if (bytes.isEmpty()) error("Backup data is empty")

            val stamp = LocalDateTime.now().format(stampFormat)
            created = tree.createFile("application/json", "reflection-backup-$stamp.json")
                ?: error("Android could not create a backup file in this folder. Choose a local folder such as Documents/Reflection Backups.")

            context.contentResolver.openOutputStream(created!!.uri, "wt")?.use { output ->
                output.write(bytes)
                output.flush()
            } ?: error("Could not open the selected backup file for writing. Choose a different folder/provider.")

            // Verify the complete file, not just that a stream opened.
            val written = context.contentResolver.openInputStream(created!!.uri)?.use { input -> input.readBytes() }
                ?: error("The backup was written but could not be read back for verification.")
            require(written.size == bytes.size && written.contentEquals(bytes)) {
                "Backup verification failed: the saved file differs from the data. Try a local folder."
            }

            AutoBackupPrefs.setLastBackup(context, LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, h:mm a")))
            AutoBackupPrefs.clearLastError(context)
            created!!.name ?: "backup"
        } catch (t: Throwable) {
            created?.let { runCatching { it.delete() } }
            AutoBackupPrefs.setLastError(context, t.message ?: t.javaClass.simpleName)
            throw t
        }
    }

}
