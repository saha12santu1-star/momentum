package com.momentum.app

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import java.nio.charset.StandardCharsets
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object BackupEngine {
    private val stampFormat = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")

    suspend fun writeToTree(context: Context, db: MomentumDatabase): String {
        val uriString = AutoBackupPrefs.treeUri(context)
            ?: error("No backup folder selected")
        val tree = DocumentFile.fromTreeUri(context, android.net.Uri.parse(uriString))
            ?: error("Backup folder is no longer available")
        if (!tree.canWrite()) error("Backup folder is not writable")

        val json = JsonBackup.create(context, db)
        val bytes = json.toByteArray(StandardCharsets.UTF_8)
        if (bytes.isEmpty()) error("Backup data is empty")

        val stamp = LocalDateTime.now().format(stampFormat)
        val file = tree.createFile("application/json", "momentum-auto-backup-$stamp.json")
            ?: error("Could not create backup file")

        try {
            context.contentResolver.openOutputStream(file.uri, "wt")?.use { output ->
                output.write(bytes)
                output.flush()
            } ?: error("Could not open backup file for writing")

            // Verify the provider really wrote readable data. Some providers report
            // an unreliable DocumentFile.length(), so verify by reopening the file.
            context.contentResolver.openInputStream(file.uri)?.use { input ->
                val probe = ByteArray(minOf(bytes.size, 128))
                val count = input.read(probe)
                require(count > 0) { "Backup file was created but is empty" }
            } ?: error("Backup file cannot be read back")

            AutoBackupPrefs.setLastBackup(
                context,
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy, h:mm a"))
            )
            AutoBackupPrefs.clearLastError(context)
            return file.name ?: "backup"
        } catch (t: Throwable) {
            runCatching { file.delete() }
            AutoBackupPrefs.setLastError(context, t.message ?: "Unknown backup error")
            throw t
        }
    }
}
