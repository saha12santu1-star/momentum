package com.momentum.app

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.ui.graphics.vector.ImageVector


data class BuiltInHabitTemplate(
    val name: String,
    val description: String,
    val category: String,
    val difficulty: String,
    val frequency: String,
    val iconKey: String,
    val progressType: String = "standard"
)

val BuiltInHabitTemplates = listOf(
    BuiltInHabitTemplate("Reading", "Read a few pages or a chapter.", "Learning", "Easy", "Daily", "book", "pages"),
    BuiltInHabitTemplate("Study", "Study, track pages and use Pomodoro focus sessions for your study time.", "Learning", "Moderate", "Daily", "study", "pages"),
    BuiltInHabitTemplate("Exercise", "Move your body in a way that feels sustainable.", "Health", "Moderate", "Daily", "exercise", "minutes"),
    BuiltInHabitTemplate("Walk", "Take a simple walk and get some movement in.", "Health", "Easy", "Daily", "walk", "steps"),
    BuiltInHabitTemplate("Meditation", "Take a few quiet minutes to reset.", "Mindful", "Easy", "Daily", "meditation"),
    BuiltInHabitTemplate("Sleep routine", "Create a consistent wind-down routine.", "Wellbeing", "Moderate", "Daily", "sleep"),
    BuiltInHabitTemplate("Water", "Remember to drink water regularly.", "Wellbeing", "Easy", "Daily", "water"),
    BuiltInHabitTemplate("Screen Time", "Create a healthier relationship with your screen time.", "Digital Wellbeing", "Easy", "Daily", "screen"),
    BuiltInHabitTemplate("Journal", "Write a few lines about your day, thoughts or feelings.", "Mindful", "Easy", "Daily", "study"),
    BuiltInHabitTemplate("Gratitude", "Notice three things you appreciate today.", "Mindful", "Easy", "Daily", "meditation"),
    BuiltInHabitTemplate("Stretching", "Take a few minutes to stretch comfortably.", "Health", "Easy", "Daily", "exercise", "minutes"),
    BuiltInHabitTemplate("Drink water", "Build a steady hydration routine throughout the day.", "Wellbeing", "Easy", "Daily", "water"),
    BuiltInHabitTemplate("Morning routine", "Start the day with one calm, repeatable action.", "Wellbeing", "Moderate", "Daily", "sleep"),
    BuiltInHabitTemplate("Evening wind-down", "Make space to slow down before bedtime.", "Wellbeing", "Easy", "Daily", "sleep"),
    BuiltInHabitTemplate("Learn a language", "Practise vocabulary or listening for a few minutes.", "Learning", "Moderate", "Daily", "book", "pages"),
    BuiltInHabitTemplate("Plan tomorrow", "Choose your top priorities for the next day.", "Productivity", "Easy", "Daily", "study"),
    BuiltInHabitTemplate("Tidy one space", "Spend a few minutes making one small area calmer.", "Home", "Easy", "Daily", "meditation"),
    BuiltInHabitTemplate("No-phone break", "Take a short break away from your phone.", "Digital Wellbeing", "Easy", "Daily", "screen"),
    BuiltInHabitTemplate("Creative practice", "Draw, write, play music or make something small.", "Creativity", "Moderate", "Daily", "study"),
    BuiltInHabitTemplate("Outdoor time", "Spend a little time outside when practical.", "Health", "Easy", "Daily", "walk", "steps"),
    BuiltInHabitTemplate("Read before bed", "Read a few pages as part of your evening routine.", "Learning", "Easy", "Daily", "book", "pages"),
    BuiltInHabitTemplate("Breathing break", "Pause for a few slow, comfortable breaths.", "Mindful", "Easy", "Daily", "meditation")
)

fun habitIcon(key: String): ImageVector = when (key) {
    "study" -> Icons.Default.EditNote
    "exercise" -> Icons.Default.FitnessCenter
    "walk" -> Icons.Default.DirectionsWalk
    "meditation" -> Icons.Default.SelfImprovement
    "sleep" -> Icons.Default.Bedtime
    "water" -> Icons.Default.WaterDrop
    "screen" -> Icons.Default.PhoneAndroid
    else -> Icons.Default.MenuBook
}
