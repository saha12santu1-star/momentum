package com.momentum.app

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.provider.Settings

object DndController {
    fun manager(context: Context): NotificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun hasAccess(context: Context): Boolean = manager(context).isNotificationPolicyAccessGranted

    fun openAccessSettings(context: Context) {
        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
    }

    fun enable(context: Context, previous: Int?): Int? {
        val nm = manager(context)
        if (!nm.isNotificationPolicyAccessGranted) return null
        val old = previous ?: nm.currentInterruptionFilter
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        return old
    }

    fun disable(context: Context, previous: Int?) {
        val nm = manager(context)
        if (!nm.isNotificationPolicyAccessGranted) return
        nm.setInterruptionFilter(previous ?: NotificationManager.INTERRUPTION_FILTER_ALL)
    }
}
