package com.momentum.app

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/** User-defined action nested under a main habit. IDs remain stable so history survives edits. */
@Entity(tableName = "habit_actions", indices = [Index(value = ["habitId"])])
data class HabitAction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val habitId: Long,
    val name: String,
    /** "boolean" or "numeric" */
    val trackingType: String = "boolean",
    val unit: String = "",
    val target: Double? = null,
    val iconKey: String = "",
    val sortOrder: Int = 0,
    val required: Boolean = true,
    val archived: Boolean = false
)

/** One value per action per local calendar date. */
@Entity(tableName = "habit_action_logs", primaryKeys = ["actionId", "date"], indices = [Index(value = ["date"])])
data class HabitActionLog(
    val actionId: Long,
    val date: String,
    val completed: Boolean = false,
    val amount: Double? = null
)

@Dao
interface HabitActionDao {
    @Query("SELECT * FROM habit_actions WHERE archived = 0 ORDER BY habitId, sortOrder, id")
    fun activeActions(): Flow<List<HabitAction>>
    @Query("SELECT * FROM habit_actions WHERE archived = 0 AND habitId = :habitId ORDER BY sortOrder, id")
    suspend fun forHabit(habitId: Long): List<HabitAction>
    @Query("SELECT * FROM habit_actions ORDER BY habitId, sortOrder, id")
    suspend fun allActionsOnce(): List<HabitAction>
    @Query("SELECT * FROM habit_action_logs ORDER BY date DESC")
    fun allLogs(): Flow<List<HabitActionLog>>
    @Query("SELECT * FROM habit_action_logs ORDER BY date DESC")
    suspend fun allLogsOnce(): List<HabitActionLog>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAction(action: HabitAction): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveActions(actions: List<HabitAction>)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLog(log: HabitActionLog)
    @Query("UPDATE habit_actions SET archived = 1 WHERE id = :id")
    suspend fun archiveAction(id: Long)
    @Query("UPDATE habit_actions SET archived = 1 WHERE habitId = :habitId")
    suspend fun archiveForHabit(habitId: Long)
    @Query("DELETE FROM habit_action_logs WHERE actionId IN (SELECT id FROM habit_actions WHERE habitId = :habitId)")
    suspend fun deleteLogsForHabit(habitId: Long)
    @Query("DELETE FROM habit_action_logs WHERE actionId = :id")
    suspend fun deleteActionLogs(id: Long)
    @Query("DELETE FROM habit_actions")
    suspend fun clearActions()
    @Query("DELETE FROM habit_action_logs")
    suspend fun clearLogs()
}
