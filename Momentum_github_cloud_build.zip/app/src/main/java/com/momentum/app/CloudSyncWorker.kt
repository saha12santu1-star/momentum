package com.momentum.app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class CloudSyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        if (!CloudSyncPrefs.auto(applicationContext) || !CloudSyncPrefs.connected(applicationContext)) return Result.success()
        return runCatching { CloudSync.sync(applicationContext, MomentumDatabase.get(applicationContext)) }
            .fold(onSuccess = { Result.success() }, onFailure = {
                CloudSyncPrefs.setLastError(applicationContext, it.message ?: "Cloud sync failed")
                Result.retry()
            })
    }
}
