package com.momentum.app

import android.content.Context

object CloudSyncPrefs {
    private const val PREFS = "reflection_cloud_sync"
    private const val CONNECTED = "connected"
    private const val LAST_HASH = "last_hash"
    private const val LAST_SYNC = "last_sync"
    private const val LAST_ERROR = "last_error"
    private const val AUTO = "auto"

    fun connected(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(CONNECTED, false)
    fun setConnected(c: Context, value: Boolean) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(CONNECTED, value).apply()
    fun lastHash(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LAST_HASH, null)
    fun setLastHash(c: Context, value: String) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(LAST_HASH, value).apply()
    fun lastSync(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LAST_SYNC, null)
    fun setLastSync(c: Context, value: String) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(LAST_SYNC, value).apply()
    fun lastError(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LAST_ERROR, null)
    fun setLastError(c: Context, value: String?) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().apply { if (value == null) remove(LAST_ERROR) else putString(LAST_ERROR, value) }.apply()
    fun auto(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(AUTO, true)
    fun setAuto(c: Context, value: Boolean) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(AUTO, value).apply()
    fun clear(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
}
