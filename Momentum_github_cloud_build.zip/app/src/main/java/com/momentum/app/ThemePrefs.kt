package com.momentum.app

import android.content.Context
import android.content.SharedPreferences

object ThemePrefs {
    private const val PREFS = "momentum_preferences"
    private const val KEY_THEME = "theme_key"

    fun get(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_THEME, "system") ?: "system"

    fun set(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_THEME, key).apply()
    }

    /** Observe theme preference changes so an already-running Activity updates immediately
     * after a local or cloud restore changes the saved theme. */
    fun observe(context: Context, listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .registerOnSharedPreferenceChangeListener(listener)
    }

    fun stopObserving(context: Context, listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .unregisterOnSharedPreferenceChangeListener(listener)
    }
}
