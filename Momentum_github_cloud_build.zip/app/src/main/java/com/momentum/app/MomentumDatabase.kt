package com.momentum.app

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

private val MIGRATION_3_4: Migration = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE habits ADD COLUMN iconKey TEXT NOT NULL DEFAULT 'book'")
    }
}

private val MIGRATION_4_5: Migration = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE habits ADD COLUMN progressType TEXT NOT NULL DEFAULT 'standard'")
        db.execSQL("CREATE TABLE IF NOT EXISTS reading_goals (habitId INTEGER NOT NULL, totalPages INTEGER NOT NULL, PRIMARY KEY(habitId))")
        db.execSQL("CREATE TABLE IF NOT EXISTS reading_logs (habitId INTEGER NOT NULL, date TEXT NOT NULL, pagesRead INTEGER NOT NULL, PRIMARY KEY(habitId, date))")
    }
}

private val MIGRATION_5_6: Migration = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS activity_progress (habitId INTEGER NOT NULL, date TEXT NOT NULL, amount INTEGER NOT NULL, PRIMARY KEY(habitId, date))")
    }
}


private val MIGRATION_6_7: Migration = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE habits ADD COLUMN goalDays INTEGER")
    }
}

private val MIGRATION_7_8: Migration = object : Migration(7, 8) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS focus_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, habitId INTEGER, date TEXT NOT NULL, minutes INTEGER NOT NULL, completed INTEGER NOT NULL)")
    }
}

@Database(
 entities=[Habit::class,HabitLog::class,TimelineEvent::class,ChallengeProgress::class,
 Achievement::class,AppSetting::class,HabitTemplate::class,ReadingGoal::class,ReadingLog::class,ActivityProgress::class,FocusSession::class],
 version=8, exportSchema=false
)
abstract class MomentumDatabase:RoomDatabase(){
 abstract fun dao():HabitDao
 abstract fun extended():ExtendedDao
 abstract fun settings():SettingsDao
 abstract fun reading():ReadingDao
 abstract fun activity():ActivityProgressDao
 abstract fun focus():FocusDao
 companion object {
  @Volatile private var I:MomentumDatabase?=null
  fun get(c:Context)=I?:synchronized(this){
   I?:Room.databaseBuilder(c.applicationContext,MomentumDatabase::class.java,"momentum.db")
    .addMigrations(MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8)
    .fallbackToDestructiveMigration().build().also{I=it}
  }
 }
}
