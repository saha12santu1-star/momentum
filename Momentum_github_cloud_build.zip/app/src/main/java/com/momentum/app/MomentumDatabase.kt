package com.momentum.app

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

private val MIGRATION_3_4: Migration = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE habits ADD COLUMN iconKey TEXT NOT NULL DEFAULT 'book'")
    }
}

private val MIGRATION_4_5: Migration = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE habits ADD COLUMN progressType TEXT NOT NULL DEFAULT 'standard'")
        db.execSQL("CREATE TABLE IF NOT EXISTS reading_goals (habitId INTEGER NOT NULL, totalPages INTEGER NOT NULL, PRIMARY KEY(habitId))")
        db.execSQL("CREATE TABLE IF NOT EXISTS reading_logs (habitId INTEGER NOT NULL, date TEXT NOT NULL, pagesRead INTEGER NOT NULL, PRIMARY KEY(habitId, date))")
    }
}

private val MIGRATION_5_6: Migration = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS activity_progress (habitId INTEGER NOT NULL, date TEXT NOT NULL, amount INTEGER NOT NULL, PRIMARY KEY(habitId, date))")
    }
}


private val MIGRATION_6_7: Migration = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE habits ADD COLUMN goalDays INTEGER")
    }
}

private val MIGRATION_7_8: Migration = object : Migration(7, 8) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS focus_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, habitId INTEGER, date TEXT NOT NULL, minutes INTEGER NOT NULL, completed INTEGER NOT NULL)")
    }
}


private val MIGRATION_8_9: Migration = object : Migration(8, 9) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS habit_actions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, habitId INTEGER NOT NULL, name TEXT NOT NULL, trackingType TEXT NOT NULL DEFAULT 'boolean', unit TEXT NOT NULL DEFAULT '', target REAL, iconKey TEXT NOT NULL DEFAULT '', sortOrder INTEGER NOT NULL DEFAULT 0, required INTEGER NOT NULL DEFAULT 1, archived INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_habit_actions_habitId ON habit_actions(habitId)")
        db.execSQL("CREATE TABLE IF NOT EXISTS habit_action_logs (actionId INTEGER NOT NULL, date TEXT NOT NULL, completed INTEGER NOT NULL DEFAULT 0, amount REAL, PRIMARY KEY(actionId, date))")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_habit_action_logs_date ON habit_action_logs(date)")
    }
}

private val MIGRATION_9_10: Migration = object : Migration(9, 10) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, title TEXT NOT NULL, markdown TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
    }
}

private val MIGRATION_10_11: Migration = object : Migration(10, 11) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE notes ADD COLUMN folder TEXT NOT NULL DEFAULT ''")
        db.execSQL("CREATE TABLE IF NOT EXISTS note_folders (name TEXT NOT NULL PRIMARY KEY, createdAt INTEGER NOT NULL)")
    }
}

private val MIGRATION_11_12: Migration = object : Migration(11, 12) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS reader_documents (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, fileName TEXT NOT NULL, mimeType TEXT NOT NULL, content BLOB NOT NULL, addedAt INTEGER NOT NULL, lastPosition INTEGER NOT NULL)")
    }
}

private val MIGRATION_12_13: Migration = object : Migration(12, 13) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE reader_documents ADD COLUMN noteId INTEGER")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_reader_documents_noteId ON reader_documents(noteId)")
    }
}

@Database(
 entities=[Habit::class,HabitLog::class,TimelineEvent::class,ChallengeProgress::class,
 Achievement::class,AppSetting::class,HabitTemplate::class,ReadingGoal::class,ReadingLog::class,ActivityProgress::class,FocusSession::class,HabitAction::class,HabitActionLog::class,Note::class,NoteFolder::class,ReaderDocument::class],
 version=13, exportSchema=false
)
abstract class MomentumDatabase:RoomDatabase(){
 abstract fun dao():HabitDao
 abstract fun extended():ExtendedDao
 abstract fun settings():SettingsDao
 abstract fun reading():ReadingDao
 abstract fun activity():ActivityProgressDao
 abstract fun focus():FocusDao
 abstract fun actions():HabitActionDao
 abstract fun notes():NoteDao
 companion object {
  @Volatile private var I:MomentumDatabase?=null
  fun get(c:Context)=I?:synchronized(this){
   I?:Room.databaseBuilder(c.applicationContext,MomentumDatabase::class.java,"momentum.db")
    .addMigrations(MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13)
    .fallbackToDestructiveMigration().build().also{I=it}
  }
 }
}
