plugins {
    id("com.android.application"); id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}
android { namespace="com.momentum.app"; compileSdk=35
    signingConfigs {
        create("reflectionStable") {
            storeFile = file("signing/reflection-debug.jks")
            storePassword = "reflectiondebug"
            keyAlias = "reflection"
            keyPassword = "reflectiondebug"
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    defaultConfig { applicationId="com.momentum.app"; minSdk=26; targetSdk=35; versionCode=53; versionName="3.23" }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("reflectionStable") }
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation(platform("androidx.compose:compose-bom:2025.01.00"))
    implementation("androidx.compose.ui:ui"); implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.room:room-runtime:2.6.1"); implementation("androidx.room:room-ktx:2.6.1")
    implementation("com.google.android.gms:play-services-auth:21.5.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")
    ksp("androidx.room:room-compiler:2.6.1")
}
