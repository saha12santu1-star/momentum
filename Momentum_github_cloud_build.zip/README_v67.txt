# Reflection v67 — Notes integration

This build adds a standalone Notes destination between Insights and Settings.

## Notes
- Create, edit, search, and delete notes.
- Notes store their text as Markdown and support paste-friendly plain text, bold, italic, underline (HTML `<u>`), strikethrough, ordered/unordered lists, checklists, block quotes, links, and undo/redo.
- The editor saves changes automatically and also saves immediately when leaving the editor.
- Notes are included in the full Reflection JSON backup and therefore travel with the existing Google Drive sync/backup flow.

## Separate notes backup
- Settings → Notes backup lets you select a folder and export a dated `Reflection-Notes-*` folder containing one UTF-8 `.md` file per note.
- A front-matter header preserves title, note ID, and timestamps while the note body remains readable Markdown.
- Restore notes from Markdown imports the Markdown files from the selected folder or the latest Reflection-Notes backup subfolder.
- The existing full Reflection JSON backup remains available separately for habits, action logs, settings, and notes.

## Version and migration
- Version name: 3.16
- Version code: 46
- Room database: version 10, with a non-destructive migration from version 9 that creates the notes table.

## Build notes
This source archive has not been compiled or installed on a device in this environment. Build it using the repository's Android Gradle workflow, then test note autosave, Markdown export/restore, legacy JSON restore, and Google Drive sync before relying on it for important notes.
