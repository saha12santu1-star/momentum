Reflection 3.28 (versionCode 58) — Google Drive attachment sync

Changes:
- Full Reflection JSON backups now include the actual bytes for attached PDFs, EPUBs, images, and other supported note documents, rather than device-local file paths alone.
- Google Drive restore recreates attachment files in the receiving device's private storage and reconnects them to their notes.
- Notes and attachments now count as user data when deciding whether an initial Drive sync should download or upload.
- Google Drive JSON uploads use resumable-upload sessions so backups larger than the small multipart-upload limit can be uploaded. Cloud backup history uses the same upload method.
- The existing Markdown notes export with its separate attachments folder remains independent.
- Per-attachment import limit remains 100 MB. Large attachments increase backup size and upload/download time.

Important: this source archive has not been compiled or tested against a live Google Drive account. Run the existing GitHub Actions build and test upload + restore on two devices before relying on it. Older cloud backups made before this change do not contain attachment bytes; upload a fresh backup from the device that still has the original attachments.
