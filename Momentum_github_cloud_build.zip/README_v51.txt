Reflection v51

Theme restore fix.

This build keeps the v50 Google Drive sync and conflict-safe first-connection behavior unchanged.
It adds a SharedPreferences observer for ThemePrefs so that when a local restore, Google Drive restore,
or background cloud sync restores a different selected theme, the already-running Compose UI immediately
recomposes with the restored theme instead of only showing the restored theme as selected in Settings.

Package: com.momentum.app
Stable signing key: app/signing/reflection-debug.jks

Build with the existing GitHub Actions workflow. No Google Cloud changes are required.
