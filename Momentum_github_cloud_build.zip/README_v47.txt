Reflection v47

Changes:
- Added "Restore from Google Drive" under Cloud Sync.
- Restore downloads the Reflection backup from the Google Drive app-data space and restores it locally after confirmation.
- After cloud restore/sync, the app refreshes its theme/settings state so the restored theme is immediately applied on the current device.
- Existing backup/restore, local tracking, and stable signing configuration preserved.

Important:
Restore from Google Drive replaces the current local Reflection data with the cloud backup. The app shows a confirmation dialog before restoring.
