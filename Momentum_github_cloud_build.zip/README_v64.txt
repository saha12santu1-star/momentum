Reflection v64 — Compact Glass UI + Safe Habit Deletion

Based on Reflection v63 source.

Refinements:
- Removed the redundant side-panel entry point from the visible UI; Settings is now a first-class bottom-navigation destination beside Insights.
- Removed the Reflection wordmark text from the top bar and retained a centered app mark.
- Reduced Today's Rhythm to a compact summary row with a small progress indicator.
- Removed motivational status text from each habit card and reduced card height/padding to approximately half the prior presentation.
- Reduced card fill opacity and global outline opacity for a more subtle, rounded glass-inspired appearance.
- Added Settings > Manage habits, with two explicit choices: Keep habit data (archive habit/actions while preserving historical records) or Delete habit and all data (remove check-ins, reading/activity progress, sub-action logs/definitions and habit record).
- Added a DAO operation to hard-delete action definitions when permanent deletion is selected.
- Bumped app version to 3.13 / version code 43.

Important:
- Source ZIP only; no APK was compiled in this environment because Gradle and Android SDK are unavailable.
- Back up Reflection data before installing. Test both delete paths on a test habit before using permanent deletion on important data.
