Reflection / Momentum v57 — Insights focus-time + flexible Pomodoro

Changes:
1. Insights now shows focused minutes (Today, 7 days, This month, This year) for every habit, including Study even when it is a standard check-in habit.
2. Pomodoro durations are customizable: focus 1–180 minutes, short break 1–60 minutes, long break 1–60 minutes, and long-break interval every 2–12 focus sessions.
3. The selected focus duration is saved with a completed session, so Insights reports the configured duration rather than assuming 25 minutes.
4. Pausing and resuming a focus session preserves the original session duration. Reset clears the in-progress session without logging it as completed.
5. The existing deadline-based timer, database schema, and GitHub Actions build workflow are retained.

Build:
- Upload Momentum_v57_build_ready.zip using the same GitHub Actions workflow you already use.
- Keep build.yml unchanged.
- Wait for the workflow to succeed, then install and test the generated APK.

Validation note: ZIP integrity and source changes were checked, but an Android/Gradle build was not run in this environment. Treat this as a candidate build until GitHub Actions succeeds and the APK is tested on-device.
