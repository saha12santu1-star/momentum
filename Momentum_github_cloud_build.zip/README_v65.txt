Reflection v65 — Header and Floating Glass Dock Refinement

Version: 3.14 (versionCode 44)

Changes:
- Removed the standalone leaf-mark top bar, which overlapped the Today heading and caused a visible divider/clip effect.
- Let the screen content begin using Scaffold's safe content insets instead of reserving a separate header surface.
- Replaced the bottom navigation's full-width rectangular surface with one floating, rounded, translucent dock.
- Removed the prominent dock border and reduced the shadow to a subtle lift.
- Set Android's system navigation bar to transparent and disabled its contrast-enforcement rectangle where supported, to avoid a second visible rectangle beneath the dock.

This is a source update, not a compiled or device-tested APK. Build with the existing GitHub Actions workflow and test on the target Android device.
