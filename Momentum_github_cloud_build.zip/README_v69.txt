Reflection v3.18 (versionCode 48) — Notes and reading-library update

Implemented in this source package:
- Notes toolbar has increase-indent (moves selected/current lines right) and decrease-indent (moves selected/current lines left) controls. The actions adjust line indentation and attempt to preserve inline text styling and selection.
- Notes includes a Reading library to import PDF, EPUB and image files.
- PDF reading uses Android PdfRenderer with page navigation. The last page is saved in the document record.
- EPUB reading parses the EPUB ZIP package/spine and renders reflowable chapters in a WebView with chapter navigation, readable typography and basic embedded-image support. The last chapter is saved.
- Imported documents are stored in the app database and included in the normal Reflection JSON backup as Base64 data, so restoring the backup on another tablet also restores the library and reading positions. This relies on the existing JSON/Google Drive backup workflow.
- Individual imported files are limited to 40 MB to avoid excessive memory use and backup size.
- Images can be imported and viewed in the same library.
- Database migration 11 to 12 adds the reader library while preserving existing data.

Limitations:
- This is read-only reading capability; it does not implement PDF/EPUB annotation.
- EPUB rendering is intended for standard reflowable EPUBs. DRM-protected EPUBs, some fixed-layout books, unusual encodings and complex embedded styles may not render correctly.
- The source archive has not been compiled or tested on a physical device in this environment. Build through the existing GitHub Actions workflow and test migration, PDF page navigation, EPUB chapter navigation, import/restore and cross-device backup before relying on it.
