Reflection v62 (versionName 3.11, versionCode 41)

Refinements:
1. Theme now defaults to System and follows Android light/dark mode; users can still select a manual theme in Settings.
2. Bottom navigation is simplified to Today, Pomodoro, and Insights.
3. Calendar is merged into Insights through a Progress / Calendar switcher.
4. Removed My Habits as a primary destination. Create habit is now available directly beside Today's habits; existing habits remain editable from their Today cards.
5. Preserved the existing data model and other features. The new parent-habit / customizable sub-action tracking system is not included in this refinement and should be implemented as a separate data-model phase, including backup and cloud-sync compatibility.

Design direction: retain Reflection's mint accent, dark near-black surfaces, rounded cards, and spacious typography. The future dedicated Notes section is intentionally not added in this refinement so it can be designed as its own feature in the next build.

Validation: source-level edits only; this package has not been compiled or tested on a device in this environment. Use the existing GitHub Actions workflow to build and test the APK.
