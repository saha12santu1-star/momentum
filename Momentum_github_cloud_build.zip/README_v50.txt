Reflection v50 – safe first-device Google Drive connection

Changes from v49:
- First-time Google Drive connection no longer immediately runs a blind sync.
- Reflection inspects both the local device and the existing cloud backup first.
- If the device is empty and a cloud backup exists, the user is offered “Use Google Drive”.
- If the device has data and no cloud backup exists, the user is offered “Upload this device”.
- If both sides contain different data, the user explicitly chooses “Use this device” or “Use Google Drive”.
- If both sides are empty, the user can start with this device.
- Cancel leaves the device disconnected; no automatic sync is scheduled until a choice is completed.
- Existing v49 cloud backup history and v48 empty-device protection are retained.
- Stable signing key from the previous build is retained.
- No Google Cloud/OAuth changes are required.

Build:
1. Upload/replace the outer ZIP as Momentum_github_cloud_build.zip if your workflow expects that filename.
2. Run the existing Build Reflection APK GitHub Actions workflow.
3. Install the resulting APK.
