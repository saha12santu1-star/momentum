Reflection 3.20 — reliability fixes

This source update is based on Reflection 3.19 (v70.2 source archive).

Changes:
- Notes editor now applies IME (keyboard) insets to its root layout so the formatting toolbar stays immediately above the on-screen keyboard instead of being pushed out of view.
- Offline backup now runs as a tracked operation, reports progress/results, stores failures even when the failure happens before file creation, and verifies the saved JSON by reading back and comparing the complete bytes. Backup files use reflection-backup-YYYYMMDD-HHMMSS.json names.
- Google Drive authorization cancellation/failure details are saved in Settings for diagnosis instead of being only transient.
- Version bumped to 3.20 / versionCode 50.

Important:
- This is a source archive, not a compiled APK. The Android build has not been run in this environment. Build with the project's GitHub Actions workflow and install/test on one device before using on both tablets.
- Before testing sync/backup, export a separate JSON backup to a known local folder if the app currently opens. Do not clear app storage or uninstall until data is safely exported.
