Reflection v3.18 (versionCode 48) — source update

Changes in this source package:
- Notes editor now includes increase/decrease indentation controls. Increase adds one indentation level to each selected/current line; decrease removes one level while preserving text styles.
- Added a Reading library to Notes for importing and reading PDF, EPUB, and image files.
- PDF reading uses Android PdfRenderer with page navigation and saves the last page. EPUB files are parsed from their ZIP package and rendered in a WebView with chapter navigation and readable typography. Image files open in an image viewer.
- Imported reading files are stored in the app database and included as Base64 data in the normal Reflection JSON/Google Drive backup so they can be restored on another tablet. For practical sync/backups, each imported file is limited to 40 MB. Android storage permissions are not required after import.
- Database migration 11 to 12 adds the reader library without deleting existing notes or habits.

Important limitations: this is read-only document viewing, not PDF/EPUB annotation. EPUB rendering currently covers standard reflowable EPUB chapters; DRM-protected EPUBs, complex fixed-layout books, and some embedded styles may not render correctly. The source archive has not been compiled or tested on a physical device in this environment. Build via the existing GitHub Actions workflow and test PDF page navigation, EPUB chapters, import/restore, and cross-device sync before relying on it.
