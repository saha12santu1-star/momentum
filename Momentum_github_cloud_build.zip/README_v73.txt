Reflection v73 source (version 3.21, versionCode 51)

Fixes in this iteration:
- Fixes the CursorWindow backup failure caused by selecting entire PDF/EPUB/image BLOB rows from SQLite during backup.
- Local JSON backup and initial Google Drive connection now back up habits, logs, settings, notes, and note folders without querying large document payloads.
- Reader files imported in this version are stored as app-private files; SQLite stores only a small placeholder plus the path. This avoids large-row CursorWindow crashes when opening PDF/EPUB and keeps the Notes screen responsive.
- Reading files are device-local and are not included in JSON/Google Drive backups in this iteration. Existing attachments created by older versions are retained in the database, but opening one will prompt to remove/re-import it because safely reading the old large BLOB is the source of the crash.
- Adds a Room migration from database version 13 to 14 for the reader file path.
- Old JSON backups that contain readerDocuments are imported into app-private files during restore.

Important validation note: source archive integrity is checked, but an Android/Gradle build was not run in this environment. Let GitHub Actions compile this source before installing it. Do not clear app data; it contains your existing habits and notes.
