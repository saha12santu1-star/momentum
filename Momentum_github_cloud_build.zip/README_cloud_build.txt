Momentum native Android build package - PIN version.
The app uses a simple local 4-digit PIN instead of biometric authentication.
Normal habit tracking remains offline-first.
