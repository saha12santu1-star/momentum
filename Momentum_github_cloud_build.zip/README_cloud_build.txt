# Momentum — GitHub cloud build

This package is prepared so GitHub Actions can build the Android APK in the cloud.

Files:
- Momentum_v8_build_ready.zip — Android project
- .github/workflows/build.yml — cloud build workflow

The workflow builds a debug APK and stores it as a downloadable GitHub Actions artifact.
