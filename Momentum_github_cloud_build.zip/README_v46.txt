Reflection v46 — stable signing build

This build keeps the existing Reflection app and Google Drive authorization diagnostic intact.

Important change:
- The debug APK is now signed with the included stable Reflection signing key instead of the ephemeral GitHub Actions debug key.
- This keeps the Android OAuth SHA-1 certificate fingerprint stable across future builds.
- The signing key is included because this is a personal/debug distribution build and is required for reproducible signing in GitHub Actions.

Before testing this build with Google Drive, update the existing "Reflection Android" OAuth client in Google Cloud to use the SHA-1 fingerprint printed by the build workflow (or the fingerprint supplied with this package).

No OAuth client secret is bundled in the APK.
