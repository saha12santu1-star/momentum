Reflection v46 diagnostic build

Change in this version:
- Only the Google Drive authorization diagnostic display was changed.
- When Google returns RESULT_CANCELED or no result, Reflection now shows the complete diagnostic in a dialog instead of a truncated toast.
- The dialog has a Copy button so the diagnostic can be copied and sent back.

No restore, backup, habit, UI theme, or other app functionality was intentionally changed.

GitHub workflow:
1. Replace the existing Momentum_github_cloud_build.zip with this archive's Momentum_v46_build_ready.zip.
2. Run the existing Build Reflection APK workflow.
3. Install the resulting APK.
4. Settings -> Cloud Sync -> Connect Google Drive.
5. Select the Google account.
6. If the diagnostic dialog appears, use Copy and paste the full text back.
