Reflection source update — Notes search and hashtags

Changes in this update:
- Note title matches are highlighted in the result title, not only in the body preview.
- Body matches continue to show a contextual snippet with the matched term highlighted.
- Hashtags such as #reading, #ideas, or #work are recognized in note titles and bodies without a database migration.
- Detected hashtags are displayed as compact chips on note cards.
- Searching for #reading filters to notes carrying that hashtag; ordinary search terms also match title and body.

Build status: source archive only. Run the repository's GitHub Actions workflow to compile and test the APK; this environment has not compiled the Android project.
