Reflection 3.27 (versionCode 57) — PDF rendering and attachment size update

Changes:
- Increased the per-attachment import limit from 15 MB to 100 MB.
- Hardened PDF page rendering by closing PdfRenderer resources reliably, bounding render bitmap height to reduce memory pressure on unusually tall pages, and separating reading-position persistence from page rendering so a position-save failure does not replace a rendered page with an error screen.
- Coroutine cancellation is rethrown instead of being displayed as a document error.

Build and test with the repository's existing GitHub Actions workflow before installing. This source archive has not been compiled or installed in this environment.
