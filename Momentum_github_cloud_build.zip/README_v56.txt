Reflection / Momentum v56 — Pomodoro timer reliability fix

Changes:
- Replaced the coroutine decrement counter with an absolute wall-clock deadline.
- Persisted timer running state, deadline, phase, and remaining seconds in app-private SharedPreferences.
- Timer should retain accurate remaining time across tab navigation, app backgrounding, and process recreation.
- Pause and Reset persist their state. Existing database and GitHub Actions workflow are unchanged.

Build: upload Momentum_v56_build_ready.zip using the existing GitHub Actions workflow.
Test: start Pomodoro, switch tabs, return; then background the app for a few minutes and return.
Expected: the displayed remaining time reflects elapsed real time, not a frozen coroutine counter.

Validation note: source changes and ZIP contents were checked, but no Android/Gradle build was available in this environment. Verify GitHub Actions succeeds before installing.
