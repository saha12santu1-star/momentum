Momentum v36: restore diagnostics and defensive post-restore scheduling. Keep existing build.yml unchanged.
