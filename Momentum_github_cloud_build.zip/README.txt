Reflection v81 source archive. See README_v81.txt for changes and build status.
