Momentum v2.8 package
Includes the v28 build-ready Android project.
Backup now includes app settings (except PIN/system permissions) and Settings/Calendar performance improvements.
