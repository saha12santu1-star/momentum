Momentum v2.6 cloud build package.
Contains Momentum_v26_build_ready.zip.
Use the existing robust GitHub Actions build.yml that finds *_build_ready.zip automatically.
