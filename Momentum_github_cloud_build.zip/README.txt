Reflection v78 — Notes toolbar positioning fix

Version: 3.26 (versionCode 56)

Change: Kept the formatting toolbar and removed the extra IME padding from the note editor container. This avoids applying keyboard insets twice when Android already resizes the app window, which was leaving the toolbar too far above the keyboard.

This source archive has not been compiled or installed on a device. Run the project's GitHub Actions build before installing.


See README_v79.txt for the latest changes in this source archive.
