Momentum v38 / Reflection

Pomodoro focus tracking, Study focus-time Insights, Android DND control, and backup/restore support for focus sessions.
The launcher/app label is Reflection; internal package ID remains com.momentum.app for compatibility.
