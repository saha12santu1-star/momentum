# Reflection v70 — Notes attachments and reading fixes

This source update changes the Notes workflow so imported files are attached to a note instead of being imported into a separate library.

## Changes

- Added an **Attach file** action inside each note. Supported formats: PDF, EPUB, TXT, HTML and common image formats.
- Attachments appear in the note, can be opened in the in-app reader, and can be removed from the note.
- PDFs are checked for a PDF header and EPUBs for a ZIP signature before being stored. Import is bounded to 15 MB per file to reduce memory pressure and force-close risk.
- Added TXT and HTML reading in addition to PDF, EPUB and image viewing.
- Fixed numbered-list insertion so selected lines receive sequential numbering; bullets and quotations toggle their prefixes. Increase/decrease indent remains available.
- Existing documents imported in earlier versions appear under **Older imports**, where they can be moved into a note.
- Attachment-to-note relationships are included in the normal JSON backup/restore, so the file and note association can sync to another tablet.
- Room database migration 12→13 adds the nullable note association and its index without deleting existing data.

## Important testing note

The ZIP archive can be checked for integrity, but this environment does not have the Android Gradle wrapper or a Gradle executable, so a complete Android build and device test were not run. Please run the repository's GitHub Actions build before installing. Verify import, opening PDF/EPUB, backup/restore, and return navigation on-device.

Version: 3.19 (versionCode 49)
