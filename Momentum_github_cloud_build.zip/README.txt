Momentum v0.9 — Replit-style native rebuild

This build keeps the working 4-digit PIN and offline Room database and replaces the placeholder UI with a light, calm, Replit-inspired native interface.

Included:
- Functional Today/Home check-ins
- Functional My habits list, search, edit, archive, delete
- Add/Edit habit screens
- Calendar month navigation and day focus
- Real-data Insights
- Coach, Timeline, Challenges, Achievements
- Settings, PIN change, JSON backup/restore, notifications permission
- App launcher icon/logo
- Offline-first local database
