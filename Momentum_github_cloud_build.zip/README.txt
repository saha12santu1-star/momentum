Reflection v42 - restored Reflection visual theme

Restores the modern dark cyan/violet Reflection theme inspired by the app icon.
Adds a dedicated Reflection theme option under Settings > Appearance > Theme color.
Keeps Google Drive sync, Pomodoro, backup/restore, app name, launcher icon, and all existing features from v41.
No package ID or database changes.
