Reflection v80 — Google Drive attachment sync

See README_v80.txt for the latest changes in this source archive.
