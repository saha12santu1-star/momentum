Momentum v37

Theme consistency fix for bottom navigation/muted UI colors. Retains v36 restore fixes.
