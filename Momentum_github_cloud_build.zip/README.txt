Momentum v34 — restore fix. Replaces Room clearAllTables() inside the restore transaction with explicit DAO DELETE statements, then restores all backed-up records and settings.
