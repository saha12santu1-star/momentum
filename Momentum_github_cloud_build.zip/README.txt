Reflection source update — Cleaner Notes cards

Changes in this update:
- Redesigned note cards as cleaner, rounded cards with more consistent spacing and less visual clutter.
- Note title stays prominent, with attachment types shown only as compact emoji icons (no attachment filenames).
- Body preview is easier to read and allows up to three lines. Search matches still show a contextual snippet and highlight the matched term.
- Hashtags appear as compact rounded chips, with overflow summarized when a note has many tags.
- Folder and last-updated details are separated into a quiet footer.
- App version updated to 3.27 (versionCode 57).

Build status: source archive only. Run the repository's GitHub Actions workflow to compile and test the APK; this environment has not compiled the Android project.
