Reflection v41 - Google Drive Cloud Sync
Replace the ZIP in the GitHub repository and keep the existing build workflow unchanged.
After installing, configure Google Drive OAuth as described in the inner README, then use Settings -> Cloud Sync.
