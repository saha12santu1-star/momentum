Reflection v67 source package. See README_v67.txt for the Notes feature, backup behavior, database migration, and build/testing notes.
