Momentum v0.9. Replace the repository ZIP with this file and replace .github/workflows/build.yml with the included workflow. The workflow extracts the v9 project correctly and builds the debug APK.
