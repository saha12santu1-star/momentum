Momentum v40 / Reflection — app icon only.
Replaces the launcher icon with the new modern Reflection icon. No app features, database, backup/restore, or package ID changes.
Use the existing GitHub Actions build workflow unchanged.
