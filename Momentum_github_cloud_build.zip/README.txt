Reflection v43 - Google authorization diagnostics

Fixes the Google Drive connection flow so failures after account selection are surfaced with the actual authorization status instead of silently stopping.
Keeps the Reflection theme, icon, Pomodoro, backup/restore, and existing sync implementation.
Package ID remains com.momentum.app.
Version code incremented for installation updates.
