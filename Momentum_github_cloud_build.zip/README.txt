Momentum v29 cloud build package.
Fix: Month activity heatmap scope error (mutedFill/accentFill).
Use the existing GitHub Actions workflow that extracts *_build_ready.zip.
