Momentum v39
Fix: drawer content is vertically scrollable so Settings and all lower menu items remain accessible on smaller screens.
No other functionality changed.
