Reflection theme update
Adds a new Reflection theme inspired by the app icon: deep navy surfaces with cyan, blue and violet accents. Theme colors are applied throughout Material UI, selected controls, cards, progress indicators, navigation, and Android system bars. Existing features, database, backup/restore, package ID, and launcher icon are unchanged.
Use the existing GitHub Actions build workflow unchanged.
