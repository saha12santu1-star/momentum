Momentum v2.8 build package — compile fix for the activity calendar.
The MonthActivityGrid now defines its theme accent fill locally, matching the YearActivityGrid.
