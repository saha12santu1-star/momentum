Reflection v63 (versionName 3.12, versionCode 42)

Includes v62 refinements plus the customizable nested habit-action system and glass-inspired UI treatment. See README_v63.txt for details and build/testing notes.

Build using the existing GitHub Actions workflow or Android Studio. This source package was not fully compiled in this environment because Gradle and the Android SDK were unavailable. Back up existing data before testing the v9 database migration.
