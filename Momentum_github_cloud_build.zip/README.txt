Momentum v33 - robust backup/restore
- Full local data backup including habits, logs, reading, movement, timeline, challenges, achievements, templates and app settings.
- Manual export verifies that the selected file can be read back.
- Automatic backup uses a shared backup engine and reports errors.
- Android storage-folder permissions are persisted; device-specific folder URI is not imported from portable backups.
- Restore keeps the current device's backup folder, restores the selected frequency/settings, and reschedules automatic backup.
- PIN is intentionally excluded from backups.
