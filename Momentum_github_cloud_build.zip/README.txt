Momentum v35 — Restore compile fix

Fixes the v34 build error by adding the missing ReadingDao clearGoals() and clearAllLogs() methods used by JsonRestore.kt. Restore logic remains transaction-safe (DAO DELETEs instead of Room clearAllTables()).

Upload Momentum_v35_build_ready.zip to the GitHub repo and run the existing workflow.
