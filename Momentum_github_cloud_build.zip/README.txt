Reflection v74 source (version 3.22, versionCode 52)

Fixes in this iteration:
- Fixes the Kotlin compilation error in the Google Drive first-connect callback: SettingsScreen now registers/clears the pending authorization handler through MainActivity instead of referring to an activity field from a separate composable scope.
- Keeps the v73 backup safeguards for avoiding large PDF/EPUB/image BLOB reads during JSON backup and Notes loading.

Validation: ZIP integrity is checked. An Android/Gradle build was not run in this environment, so GitHub Actions must confirm compilation. Do not clear app data.
