Reflection v77 — Notes screen layout and icon-only attachments

Version: 3.25 (versionCode 55)

Changes from v76:
- Removed the explanatory subtitle and paragraph from the Notes list header to reduce wasted vertical space.
- Moved note creation to a floating + button in the bottom-right corner.
- Combined the folder filter, compact search field, and +Folder action into one row, with search between the other controls.
- Made note cards more compact in a simple list layout, with shorter previews and timestamps.
- Removed attachment filenames from the note editor. Attachments are represented by their type emoji/icons only; tap an icon to open the attachment and use the delete icon to remove it.
- Kept the existing note folder move action, Markdown export, and backup/sync implementation unchanged.

Validation:
- ZIP integrity is checked after packaging.
- Android compilation and device testing were not available in this environment. Run GitHub Actions before installing.
