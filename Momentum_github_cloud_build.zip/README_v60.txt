Reflection v60 (versionName 3.9, versionCode 39)

Refinements based on user screenshots:
1. Removed the non-interactive OFFLINE-FIRST / Local device and APP LOCK / 4-digit PIN summary cards from Settings. The actual app-lock functionality and settings remain unchanged.
2. Insights CONSISTENCY and TOTAL CHECK-INS cards now appear side-by-side.
3. Insights YOUR STEADY STEPS habit streak cards now appear two per row; an odd final card occupies the left column.

Build process: use the existing GitHub Actions workflow. No workflow files were changed.

Validation: archive integrity can be checked with unzip -t. This source package has not been compiled or tested on a device in this environment.
