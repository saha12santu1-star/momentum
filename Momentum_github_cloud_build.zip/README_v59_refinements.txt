Reflection v59 refinements

Changes based on user feedback:
- N73 Blue-Green now uses a lighter deep-teal background and blue-green surfaces instead of near-black backgrounds.
- Removed the border around the Reflection top header.
- Removed Adaptive Coach cards from Today and Insights.
- Added Pomodoro to the bottom navigation between Today and My habits.
- Tightened five-item bottom navigation spacing for small screens.
- Added stable item keys to Today, My habits, and Insights habit lists to reduce list churn and improve scroll stability.
- Bumped Android versionCode to 38 and versionName to 3.8.

Existing project structure, Room data, signing configuration, and GitHub Actions workflow are retained. No changes to build.yml were made intentionally.

Build with the existing GitHub Actions workflow and test the APK before replacing your current working installation. This environment did not have Gradle available, so the Android project was not compiled here.
