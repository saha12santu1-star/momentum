Reflection v66 — Archived Habit History Fix

Version: 3.15 (versionCode 45)

Bug addressed:
When choosing “Keep habit data” during habit deletion, the app archived the habit and its sub-actions, but Insights and Calendar queried only active habits/actions. The records remained in the database but disappeared from the visible history.

Changes:
- Added observable queries for all habits and all sub-actions, including archived entries.
- Calendar now includes archived habit history and archived action definitions when showing a selected date.
- Insights keeps its current active-habit summary metrics focused on active habits, while the per-habit history section includes archived habits and marks them as “Archived · historical data retained”.
- Action history includes archived sub-actions and preserves their recorded values and units.
- Permanent deletion remains separate and continues to remove the associated records.
- Today’s active habit list still excludes archived habits.

Data safety:
This change does not intentionally erase or migrate existing records. If a habit was deleted using “Keep habit data” in v65, its database records should still be present and should become visible in Insights/Calendar after installing this build. If “Delete habit and all data” was selected, those records were permanently deleted and this fix cannot recover them; restore a prior backup if available.

Validation: source-level changes and ZIP integrity checked. A complete Android/Compose build was not run in this environment; compile with the existing GitHub Actions workflow and test against a backup first.
