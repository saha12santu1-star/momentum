Reflection v52

Fix: hardened the Android "Choose backup folder" flow so unsupported/non-writable storage providers or scheduling errors cannot crash the Settings screen. Invalid selections are rejected cleanly and partial backup configuration is rolled back.

Build with the existing GitHub Actions workflow.
