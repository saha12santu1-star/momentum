Reflection v52

Google Drive auto-sync initialization fix.

Important fix: Google authorization resolution is now handled through the Compose Activity Result launcher,
so the authorization callback can no longer bypass the first-connection safety screen. The app no longer marks
Google Drive as connected or schedules background auto-sync immediately after account authorization.

After authorization, Reflection inspects local and cloud data first and asks the user to choose:
- Use Google Drive
- Use this device
- Start with this device
- Cancel

Only after that explicit first-connection choice is completed is the device marked connected and automatic sync scheduled.
This prevents a newly installed empty device from auto-uploading an empty database and overwriting the cloud copy.

The v51 theme-restore fix and stable signing key are retained.

Package: com.momentum.app
Stable signing key: app/signing/reflection-debug.jks

Build with the existing GitHub Actions workflow. No Google Cloud changes are required.
