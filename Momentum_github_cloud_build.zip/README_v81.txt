Reflection v81 — Selective Google Drive backup cleanup
Version: 3.29 (versionCode 59)

Changes:
- Cloud backup history now offers Delete for each previous backup snapshot.
- Added Delete all previous backups, which removes history snapshots while preserving the current cloud backup.
- The current backup is protected from individual deletion by both the UI and CloudSync validation.
- Deletion confirmations explain that this action cannot be undone and does not delete local app data.

Build status:
- Source archive only; not compiled or device-tested in this environment.
- Build with the existing GitHub Actions workflow before installing.
