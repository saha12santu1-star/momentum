Reflection v53
Base: v52

Changes:
- Added optional Android biometric authentication using BiometricPrompt.
- Existing 4-digit PIN remains the fallback.
- Biometric authentication is device-local and is not included in backup/cloud sync.
- Added biometric setting in Settings.
- Auto-prompts biometric authentication when the app lock screen appears if enabled.
- No changes to Google Drive sync, backup/restore, or folder selection logic.
- Version code 34, version name 3.4.

Build with the existing GitHub Actions workflow.
