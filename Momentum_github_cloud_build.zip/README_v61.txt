Reflection v61 (versionName 3.10, versionCode 40)

Refinements based on the latest user screenshots:
1. Removed Pomodoro from the navigation drawer because it has its own dedicated bottom navigation tab.
2. Removed the Recent Activity date/value list from Today movement progress cards. Movement totals and the Update today's steps/time action remain.
3. Insights displays FOCUSED TIME only for habits with at least one completed Pomodoro session explicitly linked to that habit. Focus sessions remain filtered by the selected habit and date range; unrelated habits no longer display a zero-focused-time section.

Build process: use the existing GitHub Actions workflow. No workflow files were changed. Existing app data, focus session associations, and other features are preserved.

Validation: ZIP integrity can be checked with unzip -t. This source package has not been compiled or tested on a device in this environment.
